
import React, { useState, useEffect, useMemo } from 'react';
import { Card } from './Card';
import { useData } from '../../hooks/useData';
import { useAuth } from '../../hooks/useAuth'; // Import useAuth

export const DailyQuoteDisplay: React.FC = () => {
  const [quote, setQuote] = useState<string>('');
  const { getEffectiveDailyQuotes } = useData();
  const { currentUser } = useAuth(); // Get currentUser

  const effectiveQuotes = useMemo(() => getEffectiveDailyQuotes(currentUser), [getEffectiveDailyQuotes, currentUser]);

  useEffect(() => {
    if (effectiveQuotes.length > 0) {
      const randomIndex = Math.floor(Math.random() * effectiveQuotes.length);
      setQuote(effectiveQuotes[randomIndex]);
    } else {
      setQuote("Hãy thêm những châm ngôn hay vào mục Tùy Chỉnh Chung nhé!");
    }
  }, [effectiveQuotes]);

  return (
    <Card className="my-4">
      <h3 className="text-md font-semibold app-text-accent mb-2">Châm ngôn mỗi ngày</h3>
      {quote ? (
        <p className="italic text-gray-700 dark:text-gray-300">"{quote}"</p>
      ) : (
        <p className="italic text-gray-500 dark:text-gray-400">Đang tải châm ngôn...</p> 
      )}
    </Card>
  );
};

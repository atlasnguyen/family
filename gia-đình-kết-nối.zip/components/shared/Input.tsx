import React from 'react';
import { useTheme } from '../../hooks/useTheme';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  icon?: React.ReactNode;
  containerClassName?: string;
}

export const Input: React.FC<InputProps> = ({ label, id, error, icon, className, containerClassName, ...props }) => {
  const { themeName } = useTheme();
  const isGameTheme = themeName === 'game';

  const baseClasses = `mt-1 block w-full px-4 py-2.5 
    ${isGameTheme ? 'bg-white border-2 border-gamePrimary/30 rounded-xl focus:border-gamePrimary focus:ring-gamePrimary/50 text-gameTextPrimary placeholder-gameTextSecondary/70' 
                   : 'bg-white border border-gray-300 rounded-md shadow-sm focus:border-primary-DEFAULT focus:ring-primary-DEFAULT dark:bg-gray-700 dark:border-gray-600 dark:text-white'}
    focus:outline-none focus:ring-2 sm:text-sm`;
  
  const errorClasses = isGameTheme ? "border-red-400 focus:border-red-500 focus:ring-red-500/50" : "border-red-500 focus:ring-red-500 focus:border-red-500";
  
  return (
    <div className={`w-full ${containerClassName}`}>
      {label && (
        <label htmlFor={id} className={`block text-sm font-bold ${isGameTheme ? 'text-gameTextPrimary/80' : 'text-gray-700 dark:text-gray-300'}`}>
          {label}
        </label>
      )}
      <div className="relative">
        {icon && <div className={`absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none ${isGameTheme ? 'text-gamePrimary' : 'text-gray-400'}`}>{icon}</div>}
        <input
          id={id}
          className={`${baseClasses} ${error ? errorClasses : ''} ${icon ? 'pl-10' : ''} ${className}`}
          {...props}
        />
      </div>
      {error && <p className="mt-1 text-xs text-red-500">{error}</p>}
    </div>
  );
};

interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  error?: string;
  containerClassName?: string;
}

export const Textarea: React.FC<TextareaProps> = ({ label, id, error, className, containerClassName, ...props }) => {
  const { themeName } = useTheme();
  const isGameTheme = themeName === 'game';
  
  const baseClasses = `mt-1 block w-full px-4 py-2.5 
    ${isGameTheme ? 'bg-white border-2 border-gamePrimary/30 rounded-xl focus:border-gamePrimary focus:ring-gamePrimary/50 text-gameTextPrimary placeholder-gameTextSecondary/70' 
                   : 'bg-white border border-gray-300 rounded-md shadow-sm focus:border-primary-DEFAULT focus:ring-primary-DEFAULT dark:bg-gray-700 dark:border-gray-600 dark:text-white'}
    focus:outline-none focus:ring-2 sm:text-sm`;
  const errorClasses = isGameTheme ? "border-red-400 focus:border-red-500 focus:ring-red-500/50" : "border-red-500 focus:ring-red-500 focus:border-red-500";
  
  return (
    <div className={`w-full ${containerClassName}`}>
      {label && (
        <label htmlFor={id} className={`block text-sm font-bold ${isGameTheme ? 'text-gameTextPrimary/80' : 'text-gray-700 dark:text-gray-300'}`}>
          {label}
        </label>
      )}
      <textarea
        id={id}
        className={`${baseClasses} ${error ? errorClasses : ''} ${className}`}
        {...props}
      />
      {error && <p className="mt-1 text-xs text-red-500">{error}</p>}
    </div>
  );
};
import React, { ReactNode } from 'react';
import { useTheme } from '../../hooks/useTheme';

interface CardProps {
  children: ReactNode;
  className?: string;
  title?: string;
  titleAction?: ReactNode;
  titleIcon?: ReactNode;
}

export const Card: React.FC<CardProps> = ({ children, className = '', title, titleAction, titleIcon }) => {
  const { themeName } = useTheme();
  const isGameTheme = themeName === 'game';

  return (
    <div 
      className={`app-card-bg shadow-lg 
        ${isGameTheme ? 'rounded-2xl border-2 border-gamePrimary/30 p-5' : 'rounded-xl p-4 sm:p-6'} 
        ${className}`}
    >
      {title && (
        <div className={`flex justify-between items-center ${isGameTheme ? 'pb-3 mb-3 border-b-2 border-gamePrimary/10' : 'mb-4'}`}>
          <h3 className={`text-xl font-bold flex items-center ${isGameTheme ? 'text-gameTextPrimary' : 'app-text-accent'}`}>
            {titleIcon && <span className="mr-2 text-2xl">{titleIcon}</span>}
            {title}
          </h3>
          {titleAction}
        </div>
      )}
      {children}
    </div>
  );
};
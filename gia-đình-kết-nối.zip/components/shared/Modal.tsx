
import React, { ReactNode } from 'react';
import { useTheme } from '../../hooks/useTheme';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  footer?: ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

export const Modal: React.FC<ModalProps> = ({ isOpen, onClose, title, children, footer, size = 'md' }) => {
  const { themeName, theme } = useTheme(); // Use theme for specific colors
  const isGameTheme = themeName === 'game';
  const isCartoonTheme = themeName === 'cartoon';

  if (!isOpen) return null;

  let sizeClass = 'max-w-md';
  switch(size) {
    case 'sm': sizeClass = 'max-w-sm'; break;
    case 'lg': sizeClass = 'max-w-lg'; break;
    case 'xl': sizeClass = 'max-w-xl'; break;
  }

  const animationClass = "animate-fadeIn"; 

  // Determine modal background and text color based on theme
  let modalBgClass = 'app-card-bg'; // Default
  let modalTextClass = isGameTheme ? 'text-gameTextPrimary' : isCartoonTheme ? 'text-cartoonTextPrimary' : 'text-textPrimary';
  let titleTextClass = isGameTheme ? 'text-gamePrimary' : isCartoonTheme ? 'text-cartoonPrimary font-bold' : 'app-text-accent';
  let closeButtonClass = 'text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200';

  if (isGameTheme) {
    modalBgClass = 'bg-gameCard border-4 border-gamePrimary/60';
    closeButtonClass = 'text-gameTextPrimary hover:text-gamePrimary';
  } else if (isCartoonTheme) {
    modalBgClass = 'bg-cartoonCard border-4 border-cartoonPrimary/50';
    closeButtonClass = 'text-cartoonTextPrimary hover:text-cartoonAccent';
  }


  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-70 backdrop-blur-sm p-4 ${isGameTheme ? 'game-font' : (isCartoonTheme ? 'cartoon-font' : '')} ${animationClass}`}>
      <div 
        className={`${modalBgClass} shadow-2xl w-full ${sizeClass} transform transition-all 
          ${isGameTheme || isCartoonTheme ? 'rounded-3xl p-6 sm:p-8' : 'rounded-xl p-6'}`}
      >
        <div className="flex justify-between items-center mb-4 sm:mb-6">
          <h3 className={`text-xl sm:text-2xl font-bold ${titleTextClass}`}>{title}</h3>
          <button
            onClick={onClose}
            className={`${closeButtonClass} rounded-full p-1 focus:outline-none focus:ring-2 focus:ring-current`}
            aria-label="Close modal"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <div className={`mb-6 text-sm sm:text-base ${modalTextClass}`}>{children}</div>
        {footer && <div className="flex justify-end space-x-3 pt-3 border-t border-gray-200 dark:border-gray-700/50">{footer}</div>}
      </div>
    </div>
  );
};


import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { useTheme } from '../../hooks/useTheme';
import { useData } from '../../hooks/useData'; // Added useData
import { APP_NAME, Icons, THEMES } from '../../constants';
import { UserRole, ThemeName, Badge, EarnedBadge } from '../../types';

export const Navbar: React.FC = () => {
  const { currentUser, logout } = useAuth();
  const { themeName, setThemeName } = useTheme();
  const { getEarnedBadges, getBadges } = useData(); // Get badge data functions
  const navigate = useNavigate();
  const isGameTheme = themeName === 'game';
  const isCartoonTheme = themeName === 'cartoon';

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const handleThemeChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setThemeName(event.target.value as ThemeName);
  };
  
  let navClasses = 'app-button';
  let textClasses = 'text-white hover:opacity-90';
  let userPillClasses = 'text-white';
  let selectClasses = 'bg-transparent border-white/50 text-white focus:border-white';
  let logoutButtonClasses = 'text-white';
  let loginLinkClasses = '';

  if (isGameTheme) {
    navClasses = 'bg-gamePrimary';
    userPillClasses = 'bg-white/20 text-white';
    selectClasses = 'bg-white/90 text-gameTextPrimary border-white/50 focus:border-gameAccent';
    logoutButtonClasses = 'bg-white/25 text-white hover:bg-white/40';
    loginLinkClasses = 'text-white';
  } else if (isCartoonTheme) {
    navClasses = 'bg-cartoonPrimary'; 
    textClasses = 'text-white hover:opacity-90';
    userPillClasses = 'bg-cartoonSecondary/80 text-cartoonTextPrimary font-semibold'; 
    selectClasses = 'bg-white/90 text-cartoonTextPrimary border-cartoonAccent/50 focus:border-cartoonAccent';
    logoutButtonClasses = 'bg-cartoonSecondary/80 text-cartoonTextPrimary hover:bg-cartoonSecondary';
    loginLinkClasses = 'text-white';
  }

  const childEarnedBadges: EarnedBadge[] = currentUser?.role === UserRole.CHILD ? getEarnedBadges(currentUser.id) : [];
  const allParentBadges: Badge[] = currentUser?.parentId ? getBadges(currentUser.parentId) : [];
  
  const displayedBadges = childEarnedBadges.slice(0, 5).map(eb => {
    const badgeDetails = allParentBadges.find(b => b.id === eb.badgeId);
    return badgeDetails ? badgeDetails.icon : null;
  }).filter(icon => icon !== null);

  return (
    <nav className={`shadow-lg p-3 sm:p-4 ${navClasses}`}>
      <div className="container mx-auto flex justify-between items-center">
        <Link to="/" className={`text-2xl sm:text-3xl font-extrabold flex items-center ${textClasses}`}>
          <span className="text-3xl sm:text-4xl transform group-hover:rotate-12 transition-transform duration-200">{isGameTheme ? Icons.Home : (isCartoonTheme ? '🎨' : Icons.Family) }</span>
          <span className="ml-2 drop-shadow-sm">{APP_NAME}</span>
        </Link>
        <div className="flex items-center space-x-2 sm:space-x-4">
          {currentUser && (
            <div className={`flex items-center space-x-2 p-1.5 sm:p-2 rounded-xl ${userPillClasses}`}>
               <span className="text-xl sm:text-2xl">{currentUser.avatarIcon}</span>
               <div className="flex flex-col items-start">
                  <span className="text-xs sm:text-sm font-semibold hidden md:inline">
                    {currentUser.name} 
                  </span>
                  {currentUser.role === UserRole.CHILD && (
                    <div className="flex items-center">
                      <span className={`text-xs sm:text-sm font-bold flex items-center ${isGameTheme ? 'text-yellow-300' : (isCartoonTheme ? 'text-red-600': '')}`}>
                          <span className="text-sm mr-0.5">{Icons.Points}</span> {currentUser.points || 0}
                      </span>
                      {displayedBadges.length > 0 && (
                        <div className="ml-1 sm:ml-2 flex space-x-0.5 sm:space-x-1">
                          {displayedBadges.map((icon, index) => (
                            <span key={index} className="text-sm sm:text-base" title={allParentBadges.find(b=>b.icon === icon)?.name || 'Huy hiệu'}>{icon}</span>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
               </div>
            </div>
          )}
           <select 
            value={themeName} 
            onChange={handleThemeChange} 
            className={`text-xs sm:text-sm rounded-lg p-1.5 sm:p-2 border-2 focus:ring-0 focus:outline-none ${selectClasses}`}
          >
            {Object.keys(THEMES).map(name => (
              <option key={name} value={name} className={isGameTheme || isCartoonTheme ? 'text-gray-800 bg-white' : 'text-gray-800'}>
                {name.charAt(0).toUpperCase() + name.slice(1)}
              </option>
            ))}
          </select>
          {currentUser ? (
            <button 
              onClick={handleLogout} 
              className={`p-2 rounded-lg hover:opacity-80 flex items-center text-xs sm:text-sm ${logoutButtonClasses}`}
            >
              <span className="text-lg">{Icons.Logout}</span> 
              <span className="ml-1 hidden sm:inline font-semibold">Thoát</span>
            </button>
          ) : (
            <Link to="/login" className={`hover:opacity-80 font-semibold ${loginLinkClasses}`}>Đăng nhập</Link>
          )}
        </div>
      </div>
    </nav>
  );
};

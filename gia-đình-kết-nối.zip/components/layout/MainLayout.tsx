
import React, { ReactNode } from 'react';
import { Navigate } from 'react-router-dom';
import { Navbar } from './Navbar';
import { useAuth } from '../../hooks/useAuth';
import { useTheme } from '../../hooks/useTheme';
import { APP_NAME } from '../../constants'; 

interface MainLayoutProps {
  children: ReactNode;
}

export const MainLayout: React.FC<MainLayoutProps> = ({ children }) => {
  const { currentUser } = useAuth();
  const { theme, themeName } = useTheme(); 
  const isGameTheme = themeName === 'game';
  const isCartoonTheme = themeName === 'cartoon';

  if (!currentUser) {
    return <Navigate to="/login" replace />;
  }

  return (
    <div className={`min-h-screen flex flex-col app-bg ${isGameTheme ? 'game-font' : ''} ${isCartoonTheme ? 'cartoon-font' : ''}`}>
      <Navbar />
      <main className="flex-grow container mx-auto p-3 sm:p-4 md:p-6">
        {children}
      </main>
      <footer className={`text-center p-4 text-xs sm:text-sm border-t border-opacity-20
        ${isGameTheme ? 'text-gameTextPrimary/70 border-gamePrimary/20' : 
          (isCartoonTheme ? 'text-cartoonTextSecondary border-cartoonPrimary/20' : 'app-text-accent border-[var(--theme-text-accent)]')}`}
        >
        © {new Date().getFullYear()} {APP_NAME}. All rights reserved. Vui vẻ học tập!
      </footer>
    </div>
  );
};

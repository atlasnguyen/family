
import React, { useState } from 'react';
import { Game } from '../../types';
import { useAuth } from '../../hooks/useAuth';
import { useData } from '../../hooks/useData';
import { Button } from '../shared/Button';
import { Card } from '../shared/Card';
import { Icons } from '../../constants';
import { Modal } from '../shared/Modal';
import { useTheme } from '../../hooks/useTheme';

export const GameCenter: React.FC = () => {
  const { currentUser } = useAuth();
  const { getGames, spendPointsForGamePlay, getGameById } = useData(); // getGameById might be useful if needed
  const { themeName } = useTheme();
  const isGameTheme = themeName === 'game';

  const [showConfirmationModal, setShowConfirmationModal] = useState(false);
  const [showGamePlayModal, setShowGamePlayModal] = useState(false);
  const [selectedGame, setSelectedGame] = useState<Game | null>(null);

  if (!currentUser || !currentUser.parentId) return <p>Không thể tải danh sách trò chơi.</p>;

  const availableGames = getGames(currentUser.parentId);

  const handlePlayClick = (game: Game) => {
    if ((currentUser.points || 0) < game.pointCostToPlay) {
      alert("Con chưa đủ điểm để chơi trò này! Cố gắng hoàn thành thêm nhiệm vụ nhé!");
      return;
    }
    setSelectedGame(game);
    setShowConfirmationModal(true);
  };

  const confirmPlayGame = () => {
    if (selectedGame && currentUser) {
      const success = spendPointsForGamePlay(currentUser.id, selectedGame.id);
      if (success) {
        setShowConfirmationModal(false);
        setShowGamePlayModal(true);
        // In a real app, you might navigate to a game screen or start a timer.
        // For this demo, we just show the gameplay modal.
      } else {
        // This case should ideally be caught by the initial points check, but as a fallback:
        alert("Rất tiếc, không thể bắt đầu trò chơi. Có thể điểm của con đã thay đổi. Vui lòng thử lại.");
        setShowConfirmationModal(false);
        setSelectedGame(null);
      }
    }
  };

  const closeGamePlayModal = () => {
    setShowGamePlayModal(false);
    setSelectedGame(null);
  };
  
  const GameCard: React.FC<{game: Game}> = ({ game }) => {
    const canPlay = (currentUser.points || 0) >= game.pointCostToPlay;
    return (
        <div 
            className={`
              ${isGameTheme ? 'bg-white rounded-2xl shadow-xl border-2 border-gameSecondary/50 hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1.5' 
                           : 'app-card-bg rounded-lg shadow-md'} 
              p-4 sm:p-5 flex flex-col justify-between items-center text-center
            `}
          >
            <div className="w-full">
              <span className={`text-5xl sm:text-6xl mb-3 block filter ${isGameTheme ? 'drop-shadow-lg' : ''}`}>{game.icon}</span>
              <h4 className={`font-bold text-lg sm:text-xl mb-1 ${isGameTheme ? 'text-gameTextPrimary' : ''}`}>{game.name}</h4>
              <p className={`text-xs sm:text-sm h-14 overflow-hidden mb-2 ${isGameTheme ? 'text-gameTextSecondary/90' : 'text-gray-600 dark:text-gray-400'}`}>
                {game.description}
              </p>
              <div className="my-2 space-y-0.5">
                <p className={`text-sm font-semibold flex items-center justify-center
                    ${isGameTheme ? (canPlay ? 'text-gamePrimary' : 'text-red-500') : (canPlay ? 'app-text-accent': 'text-red-500') }`}
                  >
                  <span className="text-lg mr-1">{Icons.Points}</span> {game.pointCostToPlay} điểm
                </p>
                <p className={`text-xs ${isGameTheme ? 'text-gameTextSecondary/80' : 'text-gray-500 dark:text-gray-500'}`}>
                    <span className="mr-1">{Icons.Clock}</span> {game.timeLimitMinutes} phút chơi
                </p>
              </div>
            </div>
            <Button 
              onClick={() => handlePlayClick(game)} 
              size={isGameTheme ? "lg" : "md"}
              className="w-full mt-3"
              disabled={!canPlay}
              variant={isGameTheme ? (canPlay ? 'primary' : 'secondary') : (canPlay ? 'primary' : 'secondary')}
            >
              {!canPlay ? "Chưa đủ điểm" : "Chơi ngay!"}
            </Button>
        </div>
    );
  };

  return (
    <div className="space-y-8">
      <Card title="Trung Tâm Trò Chơi" titleIcon={isGameTheme ? Icons.Game : undefined}>
        {availableGames.length === 0 ? (
          <p className={isGameTheme ? 'text-gameTextSecondary text-center py-5' : "text-gray-500 dark:text-gray-400 text-center py-3"}>
            {isGameTheme ? "Hiện chưa có trò chơi nào. Chờ bố mẹ thêm nhé! 🤩" : "Hiện chưa có trò chơi nào."}
          </p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {availableGames.map(game => <GameCard key={game.id} game={game} />)}
          </div>
        )}
      </Card>

      {selectedGame && showConfirmationModal && (
        <Modal 
            isOpen={showConfirmationModal} 
            onClose={() => { setShowConfirmationModal(false); setSelectedGame(null);}} 
            title="Xác nhận chơi game"
        >
            <div className="text-center">
              <span className="text-7xl block mb-4 filter drop-shadow-md">{selectedGame.icon}</span>
              <p className={`text-lg mb-2 ${isGameTheme ? 'text-gameTextPrimary' : ''}`}>Con có chắc muốn dùng 
                <span className={`font-bold mx-1.5 ${isGameTheme ? 'text-gameAccent' : 'app-text-accent'}`}>{selectedGame.pointCostToPlay} {Icons.Points}</span> 
                để chơi <span className={`font-bold ${isGameTheme ? 'text-gamePrimary' : ''}`}>{selectedGame.name}</span> không?
              </p>
              <p className={`text-sm ${isGameTheme ? 'text-gameTextSecondary' : 'text-gray-600'}`}>Thời gian chơi sẽ là {selectedGame.timeLimitMinutes} phút.</p>
            </div>
            <div className="mt-8 flex justify-center space-x-4">
                <Button variant="secondary" onClick={() => { setShowConfirmationModal(false); setSelectedGame(null);}} size="lg">Để sau</Button>
                <Button onClick={confirmPlayGame} size="lg">Chơi thôi!</Button>
            </div>
        </Modal>
      )}
      
      {selectedGame && showGamePlayModal && (
         <Modal
            isOpen={showGamePlayModal}
            onClose={closeGamePlayModal}
            title={`🎮 ${selectedGame.name} 🎮`}
            size="lg"
          >
            <div className={`text-center p-6 rounded-2xl ${isGameTheme ? 'bg-gamePrimary/10 border-2 border-gamePrimary' : 'bg-primary-light/20'}`}>
                <span className="text-8xl block mb-6 filter drop-shadow-xl">{selectedGame.icon}</span>
                <h3 className={`text-3xl font-bold mb-3 ${isGameTheme ? 'text-gamePrimary' : 'app-text-accent'}`}>Bắt đầu chơi!</h3>
                <p className={`text-lg mb-2 ${isGameTheme ? 'text-gameTextPrimary' : ''}`}>
                    Con đang chơi: <span className="font-semibold">{selectedGame.name}</span>
                </p>
                <p className={`text-md mb-6 ${isGameTheme ? 'text-gameTextSecondary' : 'text-gray-700'}`}>
                    Thời gian chơi tối đa: {selectedGame.timeLimitMinutes} phút.
                </p>
                <p className={`text-sm italic p-3 rounded-lg ${isGameTheme ? 'bg-gameSecondary/20 text-gameTextSecondary' : 'bg-gray-100 dark:bg-gray-700'}`}>
                    (Đây là phần mô phỏng. Trong ứng dụng thực tế, trò chơi sẽ được hiển thị ở đây. Hãy tưởng tượng con đang chơi rất vui nhé!)
                </p>
            </div>
             <div className="mt-8 flex justify-center">
                <Button onClick={closeGamePlayModal} size="lg" variant={isGameTheme ? "secondary" : "primary"}>Kết thúc chơi</Button>
            </div>
          </Modal>
      )}
    </div>
  );
};


import React from 'react';
import { JournalEntry, MoodOption } from '../../types';
import { Button } from '../shared/Button';
import { Icons, MOOD_OPTIONS } from '../../constants';
import { useTheme } from '../../hooks/useTheme';

interface JournalEntryCardProps {
  entry: JournalEntry;
  onEdit: (entry: JournalEntry) => void;
  onDelete: (entryId: string) => void;
}

export const JournalEntryCard: React.FC<JournalEntryCardProps> = ({ entry, onEdit, onDelete }) => {
  const { themeName } = useTheme();
  const isGameTheme = themeName === 'game';
  
  const moodLabel = MOOD_OPTIONS.find(m => m.emoji === entry.mood)?.label || '';
  const displayDate = new Date(entry.date + 'T00:00:00'); // Ensure correct date parsing for local time display

  const cardStyle = isGameTheme 
    ? 'bg-white border-2 border-gameAccent/50 shadow-xl rounded-2xl p-5 hover:shadow-2xl transform hover:-translate-y-1 transition-all'
    : 'app-card-bg shadow-lg rounded-xl p-4';
  
  const titleStyle = `font-bold text-lg mb-1 truncate ${isGameTheme ? 'text-gamePrimary' : 'app-text-accent'}`;
  const contentSnippetStyle = `text-sm h-16 overflow-hidden text-ellipsis mb-3 ${isGameTheme ? 'text-gameTextSecondary' : 'text-gray-600 dark:text-gray-400'}`;
  const moodStyle = `text-3xl filter drop-shadow-sm ${isGameTheme ? '' : ''}`;
  const dateStyle = `text-xs font-medium ${isGameTheme ? 'text-gameTextSecondary/80' : 'text-gray-500 dark:text-gray-400'}`;

  return (
    <div className={cardStyle}>
      <div className="flex justify-between items-start mb-2">
        <div>
          <p className={dateStyle}>
            {displayDate.toLocaleDateString('vi-VN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
          </p>
          <h3 className={titleStyle}>{entry.title || "Nhật ký ngày " + displayDate.toLocaleDateString('vi-VN', {day:'2-digit', month:'2-digit'})}</h3>
        </div>
        <span className={moodStyle} title={moodLabel}>{entry.mood}</span>
      </div>
      <p className={contentSnippetStyle}>
        {entry.content}
      </p>
      <div className="flex justify-end space-x-2 mt-auto">
        <Button onClick={() => onEdit(entry)} variant="ghost" size="sm" leftIcon={Icons.Edit}>
          {isGameTheme ? "Xem & Sửa" : "Sửa"}
        </Button>
        <Button onClick={() => onDelete(entry.id)} variant="danger" size="sm" leftIcon={Icons.Delete}>
          {isGameTheme ? "Xóa Bỏ" : "Xóa"}
        </Button>
      </div>
    </div>
  );
};


import React, { useState, useMemo } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { useData } from '../../hooks/useData';
import { JournalEntry } from '../../types';
import { Button } from '../shared/Button';
import { Card } from '../shared/Card';
import { JournalEntryCard } from './JournalEntryCard';
import { JournalEditorModal } from './JournalEditorModal';
import { Icons, MOOD_OPTIONS } from '../../constants';
import { useTheme } from '../../hooks/useTheme';

export const JournalTabContent: React.FC = () => {
  const { currentUser } = useAuth();
  const { getJournalEntriesByChild, addJournalEntry, updateJournalEntry, deleteJournalEntry } = useData();
  const { themeName } = useTheme();
  const isGameTheme = themeName === 'game';
  
  const { journalEntries: allJournalEntries } = useData(); 

  const [isEditorModalOpen, setIsEditorModalOpen] = useState(false);
  const [editingEntry, setEditingEntry] = useState<JournalEntry | undefined>(undefined);
  const [formError, setFormError] = useState<string|null>(null);

  const childEntries = useMemo(() => {
    return currentUser ? getJournalEntriesByChild(currentUser.id) : [];
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentUser, allJournalEntries]);

  const handleOpenNewEntryModal = () => {
    setEditingEntry(undefined);
    setIsEditorModalOpen(true);
    setFormError(null);
  };

  const handleEditEntry = (entry: JournalEntry) => {
    setEditingEntry(entry);
    setIsEditorModalOpen(true);
    setFormError(null);
  };

  const handleDeleteEntry = async (entryId: string) => {
    if (window.confirm("Con có chắc muốn xóa nhật ký này không? Sau khi xóa sẽ không lấy lại được đâu.")) {
      try {
        await deleteJournalEntry(entryId);
      } catch (err) {
        alert(err instanceof Error ? err.message : "Không thể xóa nhật ký.");
      }
    }
  };

  const handleSaveEntry = async (entryData: Omit<JournalEntry, 'childId' | 'createdAt' | 'updatedAt' | 'date'> & { id?: string }) => {
    setFormError(null);
    if (!currentUser) {
        setFormError("Không tìm thấy thông tin người dùng. Vui lòng thử đăng nhập lại.");
        return;
    }
    try {
      if (entryData.id) { 
        await updateJournalEntry(entryData.id, { 
          title: entryData.title, 
          content: entryData.content, 
          mood: entryData.mood 
        });
      } else { 
        await addJournalEntry({ 
          title: entryData.title, 
          content: entryData.content, 
          mood: entryData.mood 
        }, currentUser); // Pass currentUser
      }
      setIsEditorModalOpen(false);
      setEditingEntry(undefined);
    } catch (err) {
      setFormError(err instanceof Error ? err.message : "Không thể lưu nhật ký.");
    }
  };

  return (
    <div className="space-y-6">
      <Card 
        title="Nhật Ký Của Con" 
        titleIcon={isGameTheme ? '📖': Icons.Journal}
        titleAction={
          <Button onClick={handleOpenNewEntryModal} size="md" leftIcon={Icons.Add}>
            {isGameTheme ? "Viết Điều Mới Lạ!" : "Viết Nhật Ký Mới"}
          </Button>
        }
      >
        {childEntries.length === 0 ? (
          <p className={`text-center py-6 ${isGameTheme ? 'text-gameTextSecondary' : 'text-gray-500 dark:text-gray-400'}`}>
            {isGameTheme ? "Hôm nay con cảm thấy thế nào? Kể cho nhật ký nghe nhé! 🥳" : "Con chưa viết nhật ký nào cả. Hãy bắt đầu ghi lại những cảm xúc và kỷ niệm của mình nào!"}
          </p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {childEntries.map(entry => (
              <JournalEntryCard 
                key={entry.id} 
                entry={entry} 
                onEdit={handleEditEntry} 
                onDelete={handleDeleteEntry} 
              />
            ))}
          </div>
        )}
      </Card>

      <JournalEditorModal
        isOpen={isEditorModalOpen}
        onClose={() => {setIsEditorModalOpen(false); setEditingEntry(undefined); setFormError(null);}}
        entryToEdit={editingEntry}
        onSave={handleSaveEntry}
        formError={formError}
      />
    </div>
  );
};


import React from 'react';
import { useAuth } from '../../hooks/useAuth';
import { useData } from '../../hooks/useData';
import { Card } from '../shared/Card';

export const FamilyIntroDisplay: React.FC = () => {
  const { currentUser } = useAuth();
  const { getFamilyIntro } = useData();

  // currentUser from useAuth() will be used inside getFamilyIntro if needed
  const familyIntro = getFamilyIntro(currentUser); 

  if (!familyIntro || !familyIntro.text) {
    return null; // Don't display if no intro
  }

  return (
    <Card className="my-4">
      <h3 className="text-md font-semibold app-text-accent mb-2">Về gia đình mình</h3>
      <p className="whitespace-pre-wrap text-gray-700 dark:text-gray-300">{familyIntro.text}</p>
    </Card>
  );
};

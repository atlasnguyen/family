
import React, { useState, useEffect, FormEvent } from 'react';
import { JournalEntry, MoodOption } from '../../types';
import { Modal } from '../shared/Modal';
import { Button } from '../shared/Button';
import { Input, Textarea } from '../shared/Input';
import { MOOD_OPTIONS, Icons } from '../../constants';
import { useTheme } from '../../hooks/useTheme';

interface JournalEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  entryToEdit?: JournalEntry;
  onSave: (entryData: Omit<JournalEntry, 'childId' | 'createdAt' | 'updatedAt' | 'date'> & { id?: string }) => void;
  formError?: string | null; // Added to display errors
}

export const JournalEditorModal: React.FC<JournalEditorModalProps> = ({ isOpen, onClose, entryToEdit, onSave, formError }) => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [selectedMood, setSelectedMood] = useState<string>(MOOD_OPTIONS[0].emoji);
  const [currentDate, setCurrentDate] = useState<string>('');
  
  const { themeName } = useTheme();
  const isGameTheme = themeName === 'game';

  useEffect(() => {
    if (entryToEdit) {
      setTitle(entryToEdit.title || '');
      setContent(entryToEdit.content);
      setSelectedMood(entryToEdit.mood);
      setCurrentDate(new Date(entryToEdit.date + 'T00:00:00').toLocaleDateString('vi-VN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }));
    } else {
      // For new entry
      setTitle('');
      setContent('');
      setSelectedMood(MOOD_OPTIONS[0].emoji);
      setCurrentDate(new Date().toLocaleDateString('vi-VN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }));
    }
  }, [entryToEdit, isOpen]);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!content.trim()) {
        alert("Con ơi, hãy viết gì đó vào nhật ký nhé!");
        return;
    }
    onSave({
      id: entryToEdit?.id,
      title: title.trim(),
      content: content.trim(),
      mood: selectedMood,
    });
  };
  
  const modalTitle = entryToEdit ? "Sửa Lại Cảm Xúc Nào" : "Hôm Nay Con Thấy Sao?";
  const titleLabel = isGameTheme ? "Con đặt tên cho ngày hôm nay là gì?" : "Tiêu đề (nếu có)";
  const contentLabel = isGameTheme ? "Kể cho nhật ký nghe chuyện của con nhé..." : "Nội dung nhật ký";
  const moodLabel = isGameTheme ? "Con chọn một cảm xúc nhé:" : "Cảm xúc hôm nay của con:";


  return (
    <Modal isOpen={isOpen} onClose={onClose} title={modalTitle} size="lg">
      <form onSubmit={handleSubmit} className="space-y-5">
        <p className={`text-center font-semibold ${isGameTheme ? 'text-gameAccent text-lg' : 'app-text-accent'}`}>
          {Icons.Calendar} {currentDate}
        </p>
        
        <Input 
          id="journalTitle"
          label={titleLabel}
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder={isGameTheme ? "Ví dụ: Ngày vui ở công viên..." : "Để trống nếu con muốn"}
        />
        
        <Textarea 
          id="journalContent"
          label={contentLabel}
          value={content}
          onChange={(e) => setContent(e.target.value)}
          rows={isGameTheme ? 6 : 8}
          required
          placeholder={isGameTheme ? "Hôm nay có chuyện gì vui, buồn, hay đáng nhớ không con?..." : "Viết những điều con muốn ghi nhớ..."}
        />

        <div>
          <label className={`block text-sm font-bold mb-2 ${isGameTheme ? 'text-gameTextPrimary/90' : 'text-gray-700 dark:text-gray-300'}`}>{moodLabel}</label>
          <div className={`flex flex-wrap gap-2 p-3 rounded-lg ${isGameTheme ? 'bg-gamePrimary/10' : 'bg-gray-100 dark:bg-gray-700/50'}`}>
            {MOOD_OPTIONS.map((mood) => {
              const isActive = selectedMood === mood.emoji;
              let moodButtonClass = 'px-3 py-2 rounded-lg text-2xl transition-all duration-150 transform hover:scale-110';
              if (isActive) {
                moodButtonClass += isGameTheme 
                  ? ' bg-gameSecondary text-gameButtonText ring-2 ring-gameAccent shadow-md' 
                  : ' bg-primary-DEFAULT text-white ring-2 ring-primary-dark';
              } else {
                moodButtonClass += isGameTheme 
                  ? ' bg-white hover:bg-gameAccent/20' 
                  : ' bg-gray-200 dark:bg-gray-600 hover:bg-gray-300 dark:hover:bg-gray-500';
              }
              return (
                <button
                  type="button"
                  key={mood.emoji}
                  onClick={() => setSelectedMood(mood.emoji)}
                  className={moodButtonClass}
                  title={mood.label}
                >
                  {mood.emoji}
                </button>
              );
            })}
          </div>
        </div>
        {formError && <p className="text-red-500 text-sm">{formError}</p>}
        <div className="flex justify-end space-x-3 pt-4">
          <Button type="button" variant="secondary" onClick={onClose} size={isGameTheme ? "lg" : "md"}>
            {isGameTheme ? "Để Sau Nha" : "Hủy"}
          </Button>
          <Button type="submit" size={isGameTheme ? "lg" : "md"}>
            {isGameTheme ? (entryToEdit ? "Lưu Lại Thôi!" : "Xong Rồi Đấy!") : (entryToEdit ? 'Lưu Thay Đổi' : 'Lưu Nhật Ký')}
          </Button>
        </div>
      </form>
    </Modal>
  );
};

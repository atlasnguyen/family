
import React, { useState, useEffect } from 'react';
import { Task, TaskStatus, ChildTaskInstance } from '../../types';
import { useAuth } from '../../hooks/useAuth';
import { useData } from '../../hooks/useData';
import { Button } from '../shared/Button';
import { Modal } from '../shared/Modal';
import { Card } from '../shared/Card';
import { Icons } from '../../constants';

// Helper to get week dates
const getWeekDates = (date: Date): Date[] => {
    const startOfWeek = new Date(date);
    const day = startOfWeek.getDay();
    const diff = startOfWeek.getDate() - day + (day === 0 ? -6 : 1); // adjust when day is sunday
    startOfWeek.setDate(diff);
    
    return Array.from({length: 7}).map((_, i) => {
        const d = new Date(startOfWeek);
        d.setDate(startOfWeek.getDate() + i);
        return d;
    });
};

const formatDateISO = (date: Date): string => date.toISOString().split('T')[0];

export const WeeklyPlanner: React.FC = () => {
  const { currentUser } = useAuth();
  const { getTasks, getChildTaskInstances, addChildTaskInstance, getTaskById, deleteTask, updateChildTaskInstance } = useData(); 
  
  const [currentWeek, setCurrentWeek] = useState<Date[]>(getWeekDates(new Date()));
  const [childTasksForWeek, setChildTasksForWeek] = useState<{[date: string]: ChildTaskInstance[]}>({});
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedDateForTaskAdd, setSelectedDateForTaskAdd] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  const parentTasks = currentUser?.parentId ? getTasks(currentUser.parentId).filter(t => t.status === TaskStatus.TODO) : [];
  const { childTaskInstances: allChildInstances } = useData(); // Listen to all instances for reactivity


  useEffect(() => {
    if (currentUser) {
      const instancesByDate: {[date: string]: ChildTaskInstance[]} = {};
      currentWeek.forEach(day => {
        const dateStr = formatDateISO(day);
        instancesByDate[dateStr] = getChildTaskInstances(currentUser.id, dateStr);
      });
      setChildTasksForWeek(instancesByDate);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentUser, currentWeek, allChildInstances]); // Use allChildInstances for reactivity

  const handleAddTaskToDay = async (taskId: string) => {
    if (currentUser && selectedDateForTaskAdd) {
      setFormError(null);
      const existing = childTasksForWeek[selectedDateForTaskAdd]?.find(cti => cti.taskId === taskId);
      if (existing) {
        setFormError("Thử thách này đã có trong kế hoạch của con rồi.");
        return;
      }
      try {
        const newInstance = await addChildTaskInstance({
          taskId,
          childId: currentUser.id,
          date: selectedDateForTaskAdd,
          status: TaskStatus.PLANNED,
        });
        // State will update via useEffect listening to allChildInstances
        // setChildTasksForWeek(prev => ({
        //   ...prev,
        //   [selectedDateForTaskAdd]: [...(prev[selectedDateForTaskAdd] || []), newInstance]
        // }));
        setIsModalOpen(false);
      } catch(err) {
        setFormError(err instanceof Error ? err.message : "Không thể thêm thử thách.");
      }
    }
  };
  
  const handleRemoveTaskFromDay = async (instanceId: string, date: string) => {
     if (window.confirm("Con có chắc muốn bỏ thử thách này khỏi kế hoạch không?")) {
        try {
            // Assuming PLANNED tasks can be "deleted" or "un-planned"
            // This might need a specific backend endpoint or updating status to something else
            // For now, let's assume we update its status or remove it if DataContext supports it.
            // A simple approach if backend doesn't have "deleteChildTaskInstance" could be to update status to TODO
            // but this requires the task to be removed from the view.
            // If DataContext had `deleteChildTaskInstance`, it would be:
            // await deleteChildTaskInstance(instanceId);
            
            // For now, let's assume we update status to TODO, effectively un-planning it
            // This is a placeholder, as removing requires a specific action on instances
             const instanceToUpdate = childTasksForWeek[date]?.find(cti => cti.id === instanceId);
             if(instanceToUpdate) {
                await updateChildTaskInstance(instanceId, { status: TaskStatus.TODO });
             } else {
                alert("Không tìm thấy thử thách để bỏ.");
             }
        } catch (err) {
             alert(err instanceof Error ? err.message : "Không thể bỏ thử thách khỏi kế hoạch.");
        }
     }
  };


  const openModalForDate = (date: string) => {
    setSelectedDateForTaskAdd(date);
    setIsModalOpen(true);
    setFormError(null);
  };
  
  const changeWeek = (direction: 'prev' | 'next') => {
    const newDate = new Date(currentWeek[0]);
    newDate.setDate(newDate.getDate() + (direction === 'prev' ? -7 : 7));
    setCurrentWeek(getWeekDates(newDate));
  };
  
  const dayNames = ["Chủ Nhật", "Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy"];

  return (
    <Card title="Cùng Lên Lịch Tuần Nào!">
        <div className="flex justify-between items-center mb-4">
            <Button onClick={() => changeWeek('prev')} size="sm">&lt; Tuần Trước</Button>
            <h3 className="text-lg font-semibold app-text-accent">
                {currentWeek[0].toLocaleDateString('vi-VN', {day:'2-digit', month:'2-digit'})} - {currentWeek[6].toLocaleDateString('vi-VN', {day:'2-digit', month:'2-digit', year:'numeric'})}
            </h3>
            <Button onClick={() => changeWeek('next')} size="sm">Tuần Tới &gt;</Button>
        </div>
      <div className="grid grid-cols-1 md:grid-cols-7 gap-2">
        {currentWeek.map((day, index) => {
          const dateStr = formatDateISO(day);
          const tasksForDay = childTasksForWeek[dateStr] || [];
          const isToday = formatDateISO(new Date()) === dateStr;
          return (
            <div key={dateStr} className={`p-2 rounded-lg ${isToday ? 'ring-2 ring-primary-DEFAULT app-card-bg' : 'bg-gray-100 dark:bg-gray-700'}`}>
              <p className={`font-semibold text-center mb-2 ${isToday ? 'app-text-accent' : ''}`}>
                {dayNames[(day.getDay() % 7)]} <span className="block text-xs">{day.toLocaleDateString('vi-VN', {day:'2-digit', month:'2-digit'})}</span>
              </p>
              <ul className="space-y-1 min-h-[50px]">
                {tasksForDay.map(ctInstance => {
                  const taskDetail = getTaskById(ctInstance.taskId);
                  return (
                    <li key={ctInstance.id} className="text-xs p-1.5 bg-white dark:bg-gray-600 rounded shadow-sm flex justify-between items-center">
                      <span>{taskDetail?.title || 'N/A'}</span>
                      <button onClick={() => handleRemoveTaskFromDay(ctInstance.id, dateStr)} className="text-red-500 opacity-50 hover:opacity-100 p-0.5" title="Bỏ khỏi kế hoạch">×</button>
                    </li>
                  );
                })}
              </ul>
              <Button onClick={() => openModalForDate(dateStr)} size="sm" variant="ghost" className="w-full mt-2 text-xs">Thêm Thử Thách Vui</Button>
            </div>
          );
        })}
      </div>

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title={`Thêm niềm vui cho ngày ${selectedDateForTaskAdd ? new Date(selectedDateForTaskAdd + 'T00:00:00').toLocaleDateString('vi-VN', {weekday:'long', day:'numeric', month:'numeric'}) : ''}`}>
        {parentTasks.length === 0 ? <p>Bố mẹ chưa giao thử thách nào cả. Con có thể nhắc bố mẹ nhé!</p> : (
            <ul className="space-y-2 max-h-60 overflow-y-auto">
                {parentTasks.map(task => (
                    <li key={task.id} className="flex justify-between items-center p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded">
                        <div>
                            <p>{task.title} ({task.rewardPoints} {Icons.Points})</p>
                            <p className="text-xs text-gray-500">{task.description}</p>
                        </div>
                        <Button onClick={() => handleAddTaskToDay(task.id)} size="sm" leftIcon={Icons.Add}>Con chọn</Button>
                    </li>
                ))}
            </ul>
        )}
        {formError && <p className="text-red-500 text-sm mt-2">{formError}</p>}
      </Modal>
    </Card>
  );
};

import React from 'react';
import { useAuth } from '../../hooks/useAuth';
import { useData } from '../../hooks/useData';
import { Card } from '../shared/Card';
import { Icons } from '../../constants';
import { useTheme } from '../../hooks/useTheme';

export const PointHistory: React.FC = () => {
  const { currentUser } = useAuth();
  const { getPointHistory } = useData();
  const { themeName } = useTheme();
  const isGameTheme = themeName === 'game';

  if (!currentUser) return null;

  const history = getPointHistory(currentUser.id);

  return (
    <Card title="Kho Báu Điểm Thưởng" titleIcon={isGameTheme ? '💰' : undefined}>
      <div className={`mb-6 p-4 rounded-xl text-center
        ${isGameTheme ? 'bg-gradient-to-r from-gamePrimary to-cyan-500 text-white shadow-lg' 
                       : 'app-button'}`}>
        <p className={`text-sm font-semibold ${isGameTheme ? 'opacity-80' : ''}`}>Tổng điểm của con</p>
        <p className={`text-4xl sm:text-5xl font-extrabold flex items-center justify-center
          ${isGameTheme ? 'drop-shadow-md' : ''}`}
        >
          <span className="text-4xl sm:text-5xl mr-2">{Icons.Points}</span> 
          {currentUser.points || 0}
        </p>
      </div>
      {history.length === 0 ? (
        <p className={isGameTheme ? 'text-gameTextSecondary text-center py-3' : "text-gray-500 dark:text-gray-400"}>
            {isGameTheme ? "Chưa có điểm nào được ghi lại. Bắt đầu làm nhiệm vụ thôi!" : "Chưa có giao dịch điểm nào."}
        </p>
      ) : (
        <ul className="space-y-2.5 max-h-96 overflow-y-auto pr-2">
          {history.map(transaction => (
            <li 
              key={transaction.id} 
              className={`flex justify-between items-center p-3 rounded-xl shadow-sm
                ${isGameTheme ? 'bg-white border border-gamePrimary/20' : 'app-card-bg'}`}
            >
              <div>
                <p className={`text-sm font-semibold ${isGameTheme ? 'text-gameTextPrimary' : ''}`}>{transaction.reason}</p>
                <p className={`text-xs ${isGameTheme ? 'text-gameTextSecondary/80' : 'text-gray-500 dark:text-gray-400'}`}>
                    {new Date(transaction.date).toLocaleString('vi-VN', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit'})}
                </p>
              </div>
              <span 
                className={`font-bold text-base sm:text-lg px-2 py-1 rounded-lg flex items-center
                  ${transaction.amount >= 0 
                    ? (isGameTheme ? 'bg-green-400/20 text-green-600' : 'text-green-600') 
                    : (isGameTheme ? 'bg-red-400/20 text-red-600' : 'text-red-600')}`}
                >
                {transaction.amount >= 0 ? '+' : ''}{transaction.amount} 
                <span className="ml-1 text-xl">{Icons.Points}</span>
              </span>
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
};
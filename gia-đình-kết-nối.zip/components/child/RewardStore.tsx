
import React, { useState } from 'react';
import { Reward, RedeemedRewardStatus } from '../../types';
import { useAuth } from '../../hooks/useAuth';
import { useData } from '../../hooks/useData';
import { Button } from '../shared/Button';
import { Card } from '../shared/Card';
import { Icons } from '../../constants';
import { Modal } from '../shared/Modal';
import { useTheme } from '../../hooks/useTheme';


export const RewardStore: React.FC = () => {
  const { currentUser } = useAuth();
  const { getRewards, redeemReward, getRedeemedRewardsByChild, getRewardById } = useData();
  const { themeName } = useTheme();
  const isGameTheme = themeName === 'game';
  
  const [showConfirmationModal, setShowConfirmationModal] = useState(false);
  const [selectedRewardToRedeem, setSelectedRewardToRedeem] = useState<Reward | null>(null);

  if (!currentUser || !currentUser.parentId) return <p>Không thể tải quà tặng.</p>;

  const availableRewards = getRewards(currentUser.parentId).filter(r => r.quantity > 0);
  const myRedeemedRewards = getRedeemedRewardsByChild(currentUser.id);

  const handleRedeemClick = (reward: Reward) => {
    if ((currentUser.points || 0) < reward.pointCost) {
      alert("Ôi, mình cần thêm chút điểm nữa mới đủ đổi quà này! Cố lên con nhé!");
      return;
    }
    if (reward.quantity <= 0) {
      alert("Ối! Quà này vừa có bạn khác nhanh tay hơn rồi! Con chọn quà khác nha.");
      return;
    }
    setSelectedRewardToRedeem(reward);
    setShowConfirmationModal(true);
  };

  const confirmRedeem = () => {
    if (selectedRewardToRedeem && currentUser) {
      const result = redeemReward(currentUser.id, selectedRewardToRedeem.id);
      if (result) {
        alert(`Tuyệt vời! Con đã chọn quà "${selectedRewardToRedeem.name}". Bố mẹ sẽ sớm xem và tặng con nhé!`);
      } else {
        alert("Hmm, có chút trục trặc rồi. Con thử lại hoặc nói bố mẹ xem giúp nhé.");
      }
    }
    setShowConfirmationModal(false);
    setSelectedRewardToRedeem(null);
  };
  
  const getStatusText = (status: RedeemedRewardStatus) => {
    switch(status) {
        case RedeemedRewardStatus.PENDING_APPROVAL: return "Chờ bố mẹ duyệt";
        case RedeemedRewardStatus.APPROVED_BY_PARENT: return "Bố mẹ đã duyệt!";
        case RedeemedRewardStatus.DELIVERED: return "Con đã nhận!";
        case RedeemedRewardStatus.REJECTED_BY_PARENT: return "Xem lại với bố mẹ";
        default: return "";
    }
  };
  
  const getStatusStyle = (status: RedeemedRewardStatus): string => {
    const baseStyle = "text-xs px-2.5 py-1 rounded-full font-semibold";
    if (isGameTheme) {
        switch(status) {
            case RedeemedRewardStatus.PENDING_APPROVAL: return `${baseStyle} bg-yellow-400 text-yellow-800`;
            case RedeemedRewardStatus.APPROVED_BY_PARENT: return `${baseStyle} bg-blue-400 text-blue-800`;
            case RedeemedRewardStatus.DELIVERED: return `${baseStyle} bg-green-400 text-green-800`;
            case RedeemedRewardStatus.REJECTED_BY_PARENT: return `${baseStyle} bg-red-400 text-red-800`;
            default: return `${baseStyle} bg-gray-300 text-gray-700`;
        }
    }
    // Fallback for non-game themes
    switch(status) {
        case RedeemedRewardStatus.PENDING_APPROVAL: return `${baseStyle} bg-yellow-100 text-yellow-600`;
        case RedeemedRewardStatus.APPROVED_BY_PARENT: return `${baseStyle} bg-blue-100 text-blue-600`;
        case RedeemedRewardStatus.DELIVERED: return `${baseStyle} bg-green-100 text-green-600`;
        case RedeemedRewardStatus.REJECTED_BY_PARENT: return `${baseStyle} bg-red-100 text-red-600`;
        default: return `${baseStyle} bg-gray-100 text-gray-600`;
    }
  };


  return (
    <div className="space-y-8">
      <Card title="Cửa Hàng Diệu Kỳ" titleIcon={isGameTheme ? '🛍️' : undefined}>
        {availableRewards.length === 0 ? (
          <p className={isGameTheme ? 'text-gameTextSecondary text-center py-4' : "text-gray-500 dark:text-gray-400"}>
            {isGameTheme ? "Cửa hàng đang chờ bố mẹ thêm quà mới! Con nhắc bố mẹ nhé." : "Cửa hàng đang tạm đóng cửa chờ quà mới. Con quay lại sau nha!"}
          </p>
        ) : (
          <div className={`grid grid-cols-1 gap-5 
            ${isGameTheme ? 'md:grid-cols-2 lg:grid-cols-3' : 'sm:grid-cols-2 lg:grid-cols-3'}`}>
            {availableRewards.map(reward => (
              <div 
                key={reward.id} 
                className={`
                  ${isGameTheme ? 'bg-white rounded-2xl shadow-xl border-2 border-gameSecondary/50 hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1' 
                               : 'app-card-bg rounded-lg shadow'} 
                  p-4 flex flex-col justify-between items-center text-center
                `}
              >
                <div>
                  <span className={`text-5xl sm:text-6xl mb-3 block ${isGameTheme ? 'filter drop-shadow-lg' : ''}`}>{reward.icon}</span>
                  <h4 className={`font-bold text-lg sm:text-xl mb-1 ${isGameTheme ? 'text-gameTextPrimary' : ''}`}>{reward.name}</h4>
                  <p className={`text-xs sm:text-sm h-12 overflow-hidden mb-2 ${isGameTheme ? 'text-gameTextSecondary/90' : 'text-gray-600 dark:text-gray-400'}`}>
                    {reward.description}
                  </p>
                  <p className={`text-sm font-bold my-2 flex items-center justify-center
                    ${isGameTheme ? 'text-gamePrimary' : 'app-text-accent'}`}
                  >
                    <span className="text-xl mr-1">{Icons.Points}</span> {reward.pointCost} điểm
                  </p>
                  <p className={`text-xs ${isGameTheme ? 'text-gameTextSecondary/70' : 'text-gray-500 dark:text-gray-500'}`}>
                    Còn lại: {reward.quantity}
                  </p>
                </div>
                <Button 
                  onClick={() => handleRedeemClick(reward)} 
                  size={isGameTheme ? "lg" : "sm"}
                  className="w-full mt-4"
                  disabled={(currentUser.points || 0) < reward.pointCost || reward.quantity <= 0}
                  variant={isGameTheme ? ((currentUser.points || 0) < reward.pointCost ? 'secondary' : 'primary') : 'primary'}
                >
                  {(currentUser.points || 0) < reward.pointCost ? "Thêm điểm nào!" : "Con chọn quà này!"}
                </Button>
              </div>
            ))}
          </div>
        )}
      </Card>
      
      <Card title="Quà Con Đã Chọn" titleIcon={isGameTheme ? '📜' : undefined}>
          {myRedeemedRewards.length === 0 ? (
            <p className={isGameTheme ? 'text-gameTextSecondary text-center py-3' : "text-gray-500 dark:text-gray-400"}>Con chưa chọn quà nào cả. Vào cửa hàng xem nhé!</p>
            ) : (
            <ul className="space-y-3">
                {myRedeemedRewards.sort((a,b) => new Date(b.dateRedeemed).getTime() - new Date(a.dateRedeemed).getTime()).map(rr => {
                    const rewardDetails = getRewardById(rr.rewardId);
                    return (
                        <li 
                          key={rr.id} 
                          className={`p-3 rounded-xl shadow-sm flex justify-between items-center
                            ${isGameTheme ? 'bg-white border border-gamePrimary/20' : 'app-card-bg'}`}
                        >
                            <div className="flex items-center">
                                <span className="text-3xl mr-3">{rewardDetails?.icon}</span>
                                <div>
                                  <span className={`font-semibold ${isGameTheme ? 'text-gameTextPrimary' : ''}`}>{rewardDetails?.name}</span>
                                  <p className={`text-xs ${isGameTheme ? 'text-gameTextSecondary/80' : 'text-gray-500'}`}>
                                    (Ngày {new Date(rr.dateRedeemed).toLocaleDateString()})
                                  </p>
                                </div>
                            </div>
                            <span className={getStatusStyle(rr.status)}>{getStatusText(rr.status)}</span>
                        </li>
                    );
                })}

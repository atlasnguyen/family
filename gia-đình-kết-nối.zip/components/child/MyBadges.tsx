import React from 'react';
import { useAuth } from '../../hooks/useAuth';
import { useData } from '../../hooks/useData';
import { Card } from '../shared/Card';
import { useTheme } from '../../hooks/useTheme';

export const MyBadges: React.FC = () => {
  const { currentUser } = useAuth();
  const { getEarnedBadges, getBadges } = useData();
  const { themeName } = useTheme();
  const isGameTheme = themeName === 'game';

  if (!currentUser || !currentUser.parentId) return <p>Không thể tải huy hiệu.</p>;

  const earnedBadges = getEarnedBadges(currentUser.id);
  const allBadges = getBadges(currentUser.parentId); 

  const badgeDetailsMap = new Map(allBadges.map(b => [b.id, b]));

  return (
    <Card title="Bộ Sưu Tập Huy Hiệu" titleIcon={isGameTheme ? '🎖️' : undefined}>
      {earnedBadges.length === 0 ? (
        <p className={isGameTheme ? 'text-gameTextSecondary text-center py-4' : "text-gray-500 dark:text-gray-400"}>
          {isGameTheme ? "Hộp huy hiệu còn trống! Hoàn thành nhiệm vụ để sưu tập nha!" : "Con chưa nhận được huy hiệu nào. Cố gắng lên nhé!"}
        </p>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 sm:gap-5">
          {earnedBadges.sort((a,b) => new Date(b.dateEarned).getTime() - new Date(a.dateEarned).getTime()).map(earned => {
            const badgeInfo = badgeDetailsMap.get(earned.badgeId);
            if (!badgeInfo) return null;
            return (
              <div 
                key={earned.id} 
                className={`
                  ${isGameTheme ? 'bg-gradient-to-br from-yellow-300 via-yellow-400 to-amber-500 text-amber-900 rounded-2xl shadow-xl border-2 border-yellow-500/50 hover:shadow-2xl' 
                               : 'app-card-bg rounded-lg shadow'} 
                  p-4 text-center flex flex-col items-center justify-start aspect-square transition-all duration-300 transform hover:scale-105
                `}
              >
                <span className={`text-5xl sm:text-6xl mb-2 block ${isGameTheme ? 'filter drop-shadow-lg' : ''}`}>{badgeInfo.icon}</span>
                <h4 className={`font-extrabold text-sm sm:text-base ${isGameTheme ? '' : ''}`}>{badgeInfo.name}</h4>
                {earned.reason && 
                  <p className={`text-xs italic mt-1 ${isGameTheme ? 'text-amber-800/80' : 'text-gray-500 dark:text-gray-400'}`}>
                    "{earned.reason}"
                  </p>
                }
                <p className={`text-xs mt-auto pt-1 ${isGameTheme ? 'text-amber-900/70' : 'text-gray-400 dark:text-gray-500'}`}>
                  Nhận ngày: {new Date(earned.dateEarned).toLocaleDateString()}
                </p>
              </div>
            );
          })}
        </div>
      )}
      {/* TODO: Section for "Thành tích sắp đạt được" - requires more complex logic for automated badges */}
    </Card>
  );
};

import React, { useState, useEffect } from 'react';
import { ChildTaskInstance, TaskStatus } from '../../types';
import { useAuth } from '../../hooks/useAuth';
import { useData } from '../../hooks/useData';
import { Button } from '../shared/Button';
import { Modal } from '../shared/Modal';
import { Textarea } from '../shared/Input';
import { Card } from '../shared/Card';
import { Icons } from '../../constants';
import { useTheme } from '../../hooks/useTheme';

const formatDateISO = (date: Date): string => date.toISOString().split('T')[0];

export const DailyTasks: React.FC = () => {
  const { currentUser } = useAuth();
  const { getChildTaskInstances, updateChildTaskInstance, getTaskById, getEffectivePraiseMessages } = useData();
  const { themeName } = useTheme();
  const isGameTheme = themeName === 'game';
  
  const [todayDateStr] = useState(formatDateISO(new Date()));
  const [tasksForToday, setTasksForToday] = useState<(ChildTaskInstance & {taskTitle?: string, taskDescription?: string, rewardPoints?: number})[]>([]);
  
  const [completingTask, setCompletingTask] = useState<(ChildTaskInstance & {taskTitle?: string}) | null>(null);
  const [submissionNotes, setSubmissionNotes] = useState('');
  const [formError, setFormError] = useState<string|null>(null);
  
  const praiseMessages = getEffectivePraiseMessages(currentUser); // Pass currentUser
  const getRandomPraise = () => praiseMessages[Math.floor(Math.random() * praiseMessages.length)];

  const { childTaskInstances: allChildTaskInstances } = useData(); 

  useEffect(() => {
    if (currentUser) {
      const instances = getChildTaskInstances(currentUser.id, todayDateStr)
        .map(instance => {
            const taskDetails = getTaskById(instance.taskId);
            return {
                ...instance,
                taskTitle: taskDetails?.title || "Thử thách bí ẩn",
                taskDescription: taskDetails?.description,
                rewardPoints: taskDetails?.rewardPoints
            };
        });
      setTasksForToday(instances);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentUser, todayDateStr, allChildTaskInstances, getTaskById]); 


  const handleOpenCompleteModal = (instance: ChildTaskInstance & {taskTitle?: string}) => {
    setCompletingTask(instance);
    setSubmissionNotes('');
    setFormError(null);
  };

  const handleCloseCompleteModal = () => {
    setCompletingTask(null);
    setSubmissionNotes('');
    setFormError(null);
  };

  const handleSubmitCompletion = async () => {
    if (completingTask && currentUser) {
      setFormError(null);
      try {
        await updateChildTaskInstance(completingTask.id, {
          status: TaskStatus.PENDING_APPROVAL,
          submissionNotes: submissionNotes,
        });
        handleCloseCompleteModal();
      } catch (err) {
        setFormError(err instanceof Error ? err.message : "Không thể gửi báo cáo hoàn thành.");
      }
    }
  };

  const todoTasks = tasksForToday.filter(t => t.status === TaskStatus.TODO || t.status === TaskStatus.PLANNED || t.status === TaskStatus.REJECTED);
  const pendingTasks = tasksForToday.filter(t => t.status === TaskStatus.PENDING_APPROVAL);
  const completedTasks = tasksForToday.filter(t => t.status === TaskStatus.APPROVED);

  const getStatusIconAndText = (status: TaskStatus): {icon: React.ReactNode, text: string, style: string} => {
    const baseIconStyle = "text-2xl mr-2";
    const baseTextStyle = `text-xs px-3 py-1.5 rounded-full font-semibold flex items-center`;
    if (isGameTheme) {
        switch(status) {
            case TaskStatus.TODO:
            case TaskStatus.PLANNED:
                return { icon: <span className={baseIconStyle}>{Icons.TaskStatusTodo}</span>, text: "Sẵn sàng chinh phục!", style: `${baseTextStyle} bg-blue-400/20 text-blue-700` };
            case TaskStatus.PENDING_APPROVAL:
                return { icon: <span className={baseIconStyle}>{Icons.TaskStatusPending}</span>, text: "Bố mẹ xem nhé...", style: `${baseTextStyle} bg-yellow-400 text-yellow-800 animate-pulse` };
            case TaskStatus.APPROVED:
                return { icon: <span className={baseIconStyle}>{Icons.TaskStatusApproved}</span>, text: getRandomPraise(), style: `${baseTextStyle} bg-green-500 text-white` };
            case TaskStatus.REJECTED:
                return { icon: <span className={baseIconStyle}>{Icons.TaskStatusRejected}</span>, text: "Thử lại chút nữa nhé!", style: `${baseTextStyle} bg-red-400/30 text-red-700` };
            default:
                return { icon: <span className={baseIconStyle}>{Icons.Task}</span>, text: "Chờ chút...", style: `${baseTextStyle} bg-gray-300 text-gray-700` };
        }
    }
    // Fallback for non-game themes
    switch(status) {
        case TaskStatus.TODO:
        case TaskStatus.PLANNED:
            return { icon: <span className={baseIconStyle}>{Icons.TaskStatusTodo}</span>, text: "Đang chờ con khám phá!", style: `${baseTextStyle} bg-blue-100 text-blue-600` };
        case TaskStatus.PENDING_APPROVAL:
            return { icon: <span className={baseIconStyle}>{Icons.TaskStatusPending}</span>, text: "Chờ bố mẹ duyệt...", style: `${baseTextStyle} bg-yellow-100 text-yellow-600` };
        case TaskStatus.APPROVED:
            return { icon: <span className={baseIconStyle}>{Icons.TaskStatusApproved}</span>, text: getRandomPraise(), style: `${baseTextStyle} bg-green-100 text-green-600` };
        case TaskStatus.REJECTED:
            return { icon: <span className={baseIconStyle}>{Icons.TaskStatusRejected}</span>, text: "Cố lên, xem lại chút nhé!", style: `${baseTextStyle} bg-red-100 text-red-600` };
        default:
            return { icon: <span className={baseIconStyle}>{Icons.Task}</span>, text: "...", style: `${baseTextStyle} bg-gray-100 text-gray-600` };
    }
  };

  const TaskItem: React.FC<{task: ChildTaskInstance & {taskTitle?: string, taskDescription?: string, rewardPoints?: number}}> = ({task}) => {
    const statusInfo = getStatusIconAndText(task.status);
    return (
    <li className={`p-3.5 sm:p-4 rounded-xl shadow-lg transition-all duration-200 hover:shadow-xl
        ${isGameTheme ? (task.status === TaskStatus.APPROVED ? 'bg-green-600/10 border-2 border-green-500/40' : (task.status === TaskStatus.REJECTED ? 'bg-red-500/10 border-2 border-red-500/40' : 'bg-white border-2 border-gamePrimary/30')) 
                       : 'app-card-bg' }`}
    >
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
        <div className="flex-grow mb-2 sm:mb-0">
          <h4 className={`font-bold text-base sm:text-lg flex items-center ${isGameTheme ? 'text-gameTextPrimary' : ''}`}>
            {statusInfo.icon}
            {task.taskTitle} 
            <span className={`ml-2 text-sm font-semibold flex items-center ${isGameTheme ? 'text-yellow-500' : 'app-text-accent'}`}>
              ({Icons.Points} {task.rewardPoints})
            </span>
          </h4>
          <p className={`text-xs sm:text-sm ml-1 sm:ml-9 ${isGameTheme ? 'text-gameTextSecondary/90' : 'text-gray-600 dark:text-gray-400'}`}>
            {task.taskDescription}
          </p>
          {task.status === TaskStatus.REJECTED && task.parentFeedback && (
            <p className={`text-xs mt-1 ml-9 italic ${isGameTheme ? 'text-red-600 bg-red-100 dark:bg-red-500/20 p-1.5 rounded-md' : 'text-red-500'}`}>
              Bố mẹ góp ý: "{task.parentFeedback}"
            </p>
          )}
           {task.status === TaskStatus.APPROVED && task.parentFeedback && (
            <p className={`text-xs mt-1 ml-9 italic ${isGameTheme ? 'text-green-700 bg-green-100 dark:bg-green-500/20 p-1.5 rounded-md' : 'text-green-600'}`}>
              Bố mẹ khen: "{task.parentFeedback}"
            </p>
          )}
        </div>
        <div className="flex-shrink-0 self-end sm:self-center">
        {(task.status === TaskStatus.TODO || task.status === TaskStatus.PLANNED || task.status === TaskStatus.REJECTED) && (
          <Button onClick={() => handleOpenCompleteModal(task)} size={isGameTheme ? "md" : "sm"} variant={isGameTheme ? "primary" : "primary"}>
            {isGameTheme ? "Con Xong Rồi!" : "Con làm xong!"}
          </Button>
        )}
        {task.status !== TaskStatus.TODO && task.status !== TaskStatus.PLANNED && task.status !== TaskStatus.REJECTED && (
          <span className={statusInfo.style}>
             {task.status !== TaskStatus.APPROVED && <span className="text-base mr-1">{statusInfo.icon}</span>} 
             {statusInfo.text}
          </span>
        )}
        </div>
      </div>
    </li>
  )};

  return (
    <div className="space-y-6">
      <Card title={`Khám Phá Hôm Nay (${new Date(todayDateStr  + 'T00:00:00').toLocaleDateString('vi-VN', {weekday: 'long', day: 'numeric', month: 'long'})})`} titleIcon={isGameTheme ? '🌟' : undefined}>
        {todoTasks.length === 0 && pendingTasks.length === 0 && completedTasks.length === 0 && (
          <p className={isGameTheme ? 'text-gameTextSecondary text-center py-4' : "text-gray-500 dark:text-gray-400"}>
            {isGameTheme ? "Hôm nay thật thảnh thơi! Con muốn tự mình tìm thử thách nào không? 🎉" : "Hôm nay không có thử thách nào. Con nghỉ ngơi thật vui nhé!"}
          </p>
        )}
        {todoTasks.length > 0 && (
            <>
                {isGameTheme && <h3 className="text-sm font-semibold text-gameTextSecondary mb-2 ml-1">CON SẴN SÀNG CHƯA NÀO:</h3>}
                <ul className="space-y-3 sm:space-y-4">{todoTasks.map(task => <TaskItem key={task.id} task={task} />)}</ul>
            </>
        )}
      </Card>
      
      {pendingTasks.length > 0 && (
        <Card title="Đang Chờ Bố Mẹ Khen" titleIcon={isGameTheme ? '⏳' : undefined}>
            {isGameTheme && <h3 className="text-sm font-semibold text-gameTextSecondary mb-2 ml-1">NHẮN BỐ MẸ XEM GIÚP CON:</h3>}
            <ul className="space-y-3 sm:space-y-4">{pendingTasks.map(task => <TaskItem key={task.id} task={task} />)}</ul>
        </Card>
      )}

      {completedTasks.length > 0 && (
        <Card title="Con Giỏi Lắm Luôn!" titleIcon={isGameTheme ? '🥳' : undefined}>
             {isGameTheme && <h3 className="text-sm font-semibold text-gameTextSecondary mb-2 ml-1">THÀNH TÍCH CỦA CON:</h3>}
            <ul className="space-y-3 sm:space-y-4">{completedTasks.map(task => <TaskItem key={task.id} task={task} />)}</ul>
        </Card>
      )}

      {completingTask && (
        <Modal 
            isOpen={!!completingTask} 
            onClose={handleCloseCompleteModal} 
            title={`Con kể bố mẹ nghe: ${completingTask.taskTitle}`}
        >
          <Textarea 
            label="Con đã hoàn thành thử thách này như thế nào? Có điều gì con muốn chia sẻ không?"
            value={submissionNotes}
            onChange={e => setSubmissionNotes(e.target.value)}
            rows={4}
            placeholder="Ví dụ: Con đã tự mình dọn dẹp bàn học gọn gàng. Con thấy rất vui và tự hào!"
          />
          {formError && <p className="text-red-500 text-sm mt-2">{formError}</p>}
          <div className="flex justify-end pt-5">
            <Button onClick={handleSubmitCompletion} size="lg">Gửi cho bố mẹ xem!</Button>
          </div>
        </Modal>
      )}
    </div>
  );
};

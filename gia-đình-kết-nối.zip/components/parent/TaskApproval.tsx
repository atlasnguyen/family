
import React, { useState } from 'react';
import { ChildTaskInstance, TaskStatus, User, UserRole } from '../../types';
import { useAuth } from '../../hooks/useAuth';
import { useData } from '../../hooks/useData';
import { Button } from '../shared/Button';
import { Card } from '../shared/Card';
import { Icons } from '../../constants';
import { Textarea } from '../shared/Input';
import { Modal } from '../shared/Modal';

export const TaskApproval: React.FC = () => {
  const { currentUser } = useAuth();
  const { getChildTaskInstances, updateChildTaskInstance, getTaskById, users } = useData();
  
  const [selectedInstance, setSelectedInstance] = useState<ChildTaskInstance | null>(null);
  const [feedback, setFeedback] = useState('');
  const [formError, setFormError] = useState<string|null>(null);

  if (!currentUser || currentUser.role !== UserRole.PARENT) return null;

  const childrenOfParent = users.filter(u => u.parentId === currentUser.id && u.role === UserRole.CHILD);
  let pendingApprovalInstances: (ChildTaskInstance & { taskTitle?: string, childName?: string })[] = [];

  childrenOfParent.forEach(child => {
    const childInstances = getChildTaskInstances(child.id)
      .filter(instance => instance.status === TaskStatus.PENDING_APPROVAL)
      .map(instance => {
        const taskDetails = getTaskById(instance.taskId);
        return {
            ...instance,
            taskTitle: taskDetails?.title || "Nhiệm vụ không xác định",
            childName: child.name
        };
      });
    pendingApprovalInstances = pendingApprovalInstances.concat(childInstances);
  });
  
  pendingApprovalInstances.sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime());


  const handleOpenModal = (instance: ChildTaskInstance) => {
    setSelectedInstance(instance);
    setFeedback(instance.parentFeedback || '');
    setFormError(null);
  };

  const handleCloseModal = () => {
    setSelectedInstance(null);
    setFeedback('');
    setFormError(null);
  };

  const handleApproval = async (approve: boolean) => {
    if (selectedInstance) {
      setFormError(null);
      try {
        await updateChildTaskInstance(selectedInstance.id, {
          status: approve ? TaskStatus.APPROVED : TaskStatus.REJECTED,
          parentFeedback: feedback,
        });
        handleCloseModal();
      } catch (err) {
        setFormError(err instanceof Error ? err.message : "Không thể cập nhật trạng thái nhiệm vụ.");
      }
    }
  };

  return (
    <Card title="Phê duyệt nhiệm vụ của con">
      {pendingApprovalInstances.length === 0 ? (
        <p className="text-gray-500 dark:text-gray-400">Không có nhiệm vụ nào chờ phê duyệt.</p>
      ) : (
        <ul className="space-y-3">
          {pendingApprovalInstances.map(instance => (
            <li key={instance.id} className="p-3 app-card-bg rounded-lg shadow">
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="font-semibold">{instance.taskTitle} - <span className="font-normal text-sm">{instance.childName}</span></h4>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Ngày thực hiện: {new Date(instance.date + 'T00:00:00').toLocaleDateString()}</p>
                  {instance.submissionNotes && <p className="text-sm mt-1 italic">"{instance.submissionNotes}"</p>}
                </div>
                <Button onClick={() => handleOpenModal(instance)} size="sm" variant="secondary">Xem & Duyệt</Button>
              </div>
            </li>
          ))}
        </ul>
      )}

      {selectedInstance && (
        <Modal isOpen={!!selectedInstance} onClose={handleCloseModal} title={`Duyệt nhiệm vụ: ${getTaskById(selectedInstance.taskId)?.title}`}>
            <div className="space-y-3">
                <p><span className="font-semibold">Con:</span> {users.find(u=>u.id === selectedInstance.childId)?.name}</p>
                <p><span className="font-semibold">Ngày làm:</span> {new Date(selectedInstance.date + 'T00:00:00').toLocaleDateString()}</p>
                {selectedInstance.submissionNotes && <p><span className="font-semibold">Ghi chú của con:</span> {selectedInstance.submissionNotes}</p>}
                <Textarea 
                    label="Nhận xét của bố mẹ (tùy chọn)" 
                    value={feedback} 
                    onChange={e => setFeedback(e.target.value)} 
                    rows={3}
                />
            </div>
            {formError && <p className="text-red-500 text-sm mt-2">{formError}</p>}
            <div className="flex justify-end space-x-3 mt-4 pt-2">
                <Button onClick={() => handleApproval(false)} variant="danger" leftIcon={Icons.Reject}>Từ chối</Button>
                <Button onClick={() => handleApproval(true)} variant="primary" leftIcon={Icons.Approve}>Phê duyệt</Button>
            </div>
        </Modal>
      )}
    </Card>
  );
};

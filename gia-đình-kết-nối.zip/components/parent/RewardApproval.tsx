
import React from 'react';
import { RedeemedReward, RedeemedRewardStatus, User, UserRole } from '../../types';
import { useAuth } from '../../hooks/useAuth';
import { useData } from '../../hooks/useData';
import { Button } from '../shared/Button';
import { Card } from '../shared/Card';
import { Icons } from '../../constants';

export const RewardApproval: React.FC = () => {
  const { currentUser } = useAuth();
  const { getRedeemedRewardsByParent, approveRedeemedReward, deliverRedeemedReward, getRewardById, users } = useData();

  if (!currentUser || currentUser.role !== UserRole.PARENT) return null;

  const allRedeemed = getRedeemedRewardsByParent(currentUser.id);
  
  const pendingApprovalRewards = allRedeemed
    .filter(rr => rr.status === RedeemedRewardStatus.PENDING_APPROVAL)
    .map(rr => ({...rr, rewardDetails: getRewardById(rr.rewardId), childDetails: users.find(u => u.id === rr.childId)}))
    .sort((a,b) => new Date(a.dateRedeemed).getTime() - new Date(b.dateRedeemed).getTime());

  const approvedNotDeliveredRewards = allRedeemed
    .filter(rr => rr.status === RedeemedRewardStatus.APPROVED_BY_PARENT)
    .map(rr => ({...rr, rewardDetails: getRewardById(rr.rewardId), childDetails: users.find(u => u.id === rr.childId)}))
    .sort((a,b) => new Date(a.dateRedeemed).getTime() - new Date(b.dateRedeemed).getTime());

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <Card title="Phê duyệt đổi quà">
        {pendingApprovalRewards.length === 0 ? (
          <p className="text-gray-500 dark:text-gray-400">Không có yêu cầu đổi quà nào.</p>
        ) : (
          <ul className="space-y-3">
            {pendingApprovalRewards.map(rr => (
              <li key={rr.id} className="p-3 app-card-bg rounded-lg shadow">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-semibold">{rr.rewardDetails?.icon} {rr.rewardDetails?.name} - <span className="font-normal text-sm">{rr.childDetails?.name}</span></h4>
                    <p className="text-xs text-gray-500 dark:text-gray-400">Ngày đổi: {new Date(rr.dateRedeemed).toLocaleDateString()}</p>
                    <p className="text-sm">{Icons.Points} {rr.rewardDetails?.pointCost} điểm</p>
                  </div>
                  <div className="flex flex-col sm:flex-row space-y-1 sm:space-y-0 sm:space-x-2">
                    <Button onClick={() => approveRedeemedReward(rr.id, true)} size="sm" variant="primary" leftIcon={Icons.Approve}>Duyệt</Button>
                    <Button onClick={() => approveRedeemedReward(rr.id, false)} size="sm" variant="danger" leftIcon={Icons.Reject}>Từ chối</Button>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </Card>
      
      <Card title="Quà đã duyệt (chưa trao)">
        {approvedNotDeliveredRewards.length === 0 ? (
          <p className="text-gray-500 dark:text-gray-400">Không có quà nào chờ trao.</p>
        ) : (
          <ul className="space-y-3">
            {approvedNotDeliveredRewards.map(rr => (
              <li key={rr.id} className="p-3 app-card-bg rounded-lg shadow">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-semibold">{rr.rewardDetails?.icon} {rr.rewardDetails?.name} - <span className="font-normal text-sm">{rr.childDetails?.name}</span></h4>
                     <p className="text-xs text-gray-500 dark:text-gray-400">Ngày duyệt: {new Date(rr.dateRedeemed).toLocaleDateString()}</p>
                  </div>
                  <Button onClick={() => deliverRedeemedReward(rr.id)} size="sm" variant="secondary" leftIcon={Icons.CheckCircle}>Đã trao</Button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
};

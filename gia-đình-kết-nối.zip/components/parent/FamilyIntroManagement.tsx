
import React, { useState, FormEvent, useEffect } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { useData } from '../../hooks/useData';
import { Button } from '../shared/Button';
import { Textarea } from '../shared/Input';
import { Card } from '../shared/Card';

export const FamilyIntroManagement: React.FC = () => {
  const { currentUser } = useAuth();
  const { getFamilyIntro, updateFamilyIntro } = useData();
  
  const [introText, setIntroText] = useState('');
  const [isEditing, setIsEditing] = useState(false);

  const familyIntro = getFamilyIntro(currentUser);

  useEffect(() => {
    if (familyIntro) {
      setIntroText(familyIntro.text);
    } else {
      setIntroText('');
    }
  }, [familyIntro]);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    updateFamilyIntro({ text: introText }, currentUser); // Pass currentUser
    setIsEditing(false);
  };

  if (!currentUser) return null;

  return (
    <Card title="Giới thiệu gia đình">
      {isEditing ? (
        <form onSubmit={handleSubmit} className="space-y-3">
          <Textarea 
            value={introText} 
            onChange={e => setIntroText(e.target.value)} 
            rows={4}
            placeholder="Viết một vài điều về gia đình bạn..."
          />
          <div className="flex space-x-2">
            <Button type="submit">Lưu</Button>
            <Button type="button" variant="secondary" onClick={() => { setIsEditing(false); setIntroText(familyIntro?.text || '');}}>Hủy</Button>
          </div>
        </form>
      ) : (
        <div>
          {familyIntro?.text ? (
            <p className="whitespace-pre-wrap text-gray-700 dark:text-gray-300">{familyIntro.text}</p>
          ) : (
            <p className="text-gray-500 dark:text-gray-400">Chưa có giới thiệu nào. Hãy thêm một vài lời để làm trang chủ thêm ấm cúng!</p>
          )}
          <Button onClick={() => setIsEditing(true)} size="sm" variant="secondary" className="mt-3">
            {familyIntro?.text ? 'Chỉnh sửa' : 'Thêm giới thiệu'}
          </Button>
        </div>
      )}
    </Card>
  );
};

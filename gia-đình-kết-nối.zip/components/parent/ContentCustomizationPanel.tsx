
import React, { useState, useEffect, FormEvent } from 'react';
import { useAuth } from '../../hooks/useAuth'; // Import useAuth
import { useData } from '../../hooks/useData';
import { ParentCustomSettings } from '../../types';
import { Card } from '../shared/Card';
import { Button } from '../shared/Button';
import { Textarea } from '../shared/Input';
import { Icons, DEFAULT_DAILY_QUOTES, PRAISE_MESSAGES, DEFAULT_AVATARS, GAME_ICONS } from '../../constants';
import { useTheme } from '../../hooks/useTheme';

export const ContentCustomizationPanel: React.FC = () => {
  const { currentUser } = useAuth(); // Get currentUser
  const { 
    getParentCustomSettings, 
    updateParentCustomSettings,
    getEffectiveDailyQuotes,
    getEffectivePraiseMessages,
    getEffectiveAvatars,
    getEffectiveGameIcons,
    getEffectiveRewardIcons,
    getEffectiveBadgeIcons
  } = useData();
  const { themeName } = useTheme();
  const isGameTheme = themeName === 'game';

  const [dailyQuotes, setDailyQuotes] = useState('');
  const [praiseMessages, setPraiseMessages] = useState('');
  const [avatars, setAvatars] = useState('');
  const [gameIcons, setGameIcons] = useState('');
  const [rewardIcons, setRewardIcons] = useState('');
  const [badgeIcons, setBadgeIcons] = useState('');

  useEffect(() => {
    const currentSettings = getParentCustomSettings(currentUser);
    // Pass currentUser to effective getters
    setDailyQuotes((currentSettings?.dailyQuotes || getEffectiveDailyQuotes(currentUser)).join('\\n'));
    setPraiseMessages((currentSettings?.praiseMessages || getEffectivePraiseMessages(currentUser)).join('\\n'));
    setAvatars((currentSettings?.avatars || getEffectiveAvatars(currentUser)).join('\\n'));
    setGameIcons((currentSettings?.gameIcons || getEffectiveGameIcons(currentUser)).join('\\n'));
    setRewardIcons((currentSettings?.rewardIcons || getEffectiveRewardIcons(currentUser)).join('\\n'));
    setBadgeIcons((currentSettings?.badgeIcons || getEffectiveBadgeIcons(currentUser)).join('\\n'));
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentUser]); // Re-fetch if currentUser changes

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const newSettings: ParentCustomSettings = {
      dailyQuotes: dailyQuotes.split('\\n').map(s => s.trim()).filter(Boolean),
      praiseMessages: praiseMessages.split('\\n').map(s => s.trim()).filter(Boolean),
      avatars: avatars.split('\\n').map(s => s.trim()).filter(Boolean),
      gameIcons: gameIcons.split('\\n').map(s => s.trim()).filter(Boolean),
      rewardIcons: rewardIcons.split('\\n').map(s => s.trim()).filter(Boolean),
      badgeIcons: badgeIcons.split('\\n').map(s => s.trim()).filter(Boolean),
    };
    updateParentCustomSettings(currentUser, newSettings); // Pass currentUser
    alert('Cài đặt đã được lưu!');
  };
  
  const resetToDefaults = (fieldKey: keyof ParentCustomSettings) => {
    let updatedSettingsPart: Partial<ParentCustomSettings> = {};
    const currentFullSettings = getParentCustomSettings(currentUser) || {};

    switch(fieldKey) {
        case 'dailyQuotes': 
            setDailyQuotes(DEFAULT_DAILY_QUOTES.join('\\n'));
            updatedSettingsPart.dailyQuotes = DEFAULT_DAILY_QUOTES;
            break;
        case 'praiseMessages': 
            setPraiseMessages(PRAISE_MESSAGES.join('\\n')); 
            updatedSettingsPart.praiseMessages = PRAISE_MESSAGES;
             break;
        case 'avatars': 
            setAvatars(DEFAULT_AVATARS.join('\\n')); 
            updatedSettingsPart.avatars = DEFAULT_AVATARS;
            break;
        case 'gameIcons': 
            setGameIcons(GAME_ICONS.join('\\n')); 
            updatedSettingsPart.gameIcons = GAME_ICONS;
            break;
        case 'rewardIcons': 
            // For these, we get the "effective" default which might depend on other settings (like avatars)
            // So, we pass null to get the true default from constants.
            const defaultRewardIcons = getEffectiveRewardIcons(null); // Get true defaults
            setRewardIcons(defaultRewardIcons.join('\\n')); 
            updatedSettingsPart.rewardIcons = defaultRewardIcons;
            break;
        case 'badgeIcons': 
            const defaultBadgeIcons = getEffectiveBadgeIcons(null); // Get true defaults
            setBadgeIcons(defaultBadgeIcons.join('\\n')); 
            updatedSettingsPart.badgeIcons = defaultBadgeIcons;
            break;
    }
    
    updateParentCustomSettings(currentUser, { ...currentFullSettings, ...updatedSettingsPart }); // Pass currentUser
    alert(`${fieldKey === 'dailyQuotes' ? 'Danh sách châm ngôn' : fieldKey} đã được khôi phục về mặc định!`);
  };

  const fieldStyle = `p-3 rounded-lg shadow ${isGameTheme ? 'bg-white/80 border border-gamePrimary/20' : 'app-card-bg'}`;
  const labelStyle = `block text-sm font-bold mb-1 ${isGameTheme ? 'text-gameTextPrimary/90' : 'text-gray-700 dark:text-gray-300'}`;
  const hintStyle = `text-xs mt-1 ${isGameTheme ? 'text-gameTextSecondary' : 'text-gray-500 dark:text-gray-400'}`;

  return (
    <Card title="Tùy chỉnh nội dung gia đình" titleIcon={Icons.Settings}>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className={fieldStyle}>
          <label htmlFor="dailyQuotes" className={labelStyle}>Danh Sách Châm Ngôn Hàng Ngày</label>
          <Textarea id="dailyQuotes" value={dailyQuotes} onChange={e => setDailyQuotes(e.target.value)} rows={5} />
          <p className={hintStyle}>Mỗi châm ngôn trên một dòng. Ứng dụng sẽ chọn ngẫu nhiên một câu để hiển thị mỗi ngày.</p>
          <Button type="button" onClick={() => resetToDefaults('dailyQuotes')} variant="ghost" size="sm" className="mt-1">Khôi phục mặc định</Button>
        </div>

        <div className={fieldStyle}>
          <label htmlFor="praiseMessages" className={labelStyle}>Lời Khen Khi Hoàn Thành Nhiệm Vụ</label>
          <Textarea id="praiseMessages" value={praiseMessages} onChange={e => setPraiseMessages(e.target.value)} rows={5} />
          <p className={hintStyle}>Mỗi lời khen trên một dòng. Ứng dụng sẽ chọn ngẫu nhiên một lời khen.</p>
           <Button type="button" onClick={() => resetToDefaults('praiseMessages')} variant="ghost" size="sm" className="mt-1">Khôi phục mặc định</Button>
        </div>

        <div className={fieldStyle}>
          <label htmlFor="avatars" className={labelStyle}>Biểu Tượng Đại Diện (Avatars)</label>
          <Textarea id="avatars" value={avatars} onChange={e => setAvatars(e.target.value)} rows={5} />
          <p className={hintStyle}>Mỗi biểu tượng (emoji) trên một dòng.</p>
          <Button type="button" onClick={() => resetToDefaults('avatars')} variant="ghost" size="sm" className="mt-1">Khôi phục mặc định</Button>
        </div>
        
        <div className={fieldStyle}>
          <label htmlFor="gameIcons" className={labelStyle}>Biểu Tượng Trò Chơi</label>
          <Textarea id="gameIcons" value={gameIcons} onChange={e => setGameIcons(e.target.value)} rows={5} />
          <p className={hintStyle}>Mỗi biểu tượng (emoji) trên một dòng cho lựa chọn khi tạo trò chơi.</p>
          <Button type="button" onClick={() => resetToDefaults('gameIcons')} variant="ghost" size="sm" className="mt-1">Khôi phục mặc định</Button>
        </div>

        <div className={fieldStyle}>
          <label htmlFor="rewardIcons" className={labelStyle}>Biểu Tượng Phần Thưởng</label>
          <Textarea id="rewardIcons" value={rewardIcons} onChange={e => setRewardIcons(e.target.value)} rows={5} />
          <p className={hintStyle}>Mỗi biểu tượng (emoji) trên một dòng cho lựa chọn khi tạo phần thưởng.</p>
          <Button type="button" onClick={() => resetToDefaults('rewardIcons')} variant="ghost" size="sm" className="mt-1">Khôi phục mặc định</Button>
        </div>

        <div className={fieldStyle}>
          <label htmlFor="badgeIcons" className={labelStyle}>Biểu Tượng Huy Hiệu</label>
          <Textarea id="badgeIcons" value={badgeIcons} onChange={e => setBadgeIcons(e.target.value)} rows={5} />
          <p className={hintStyle}>Mỗi biểu tượng (emoji) trên một dòng cho lựa chọn khi tạo huy hiệu.</p>
          <Button type="button" onClick={() => resetToDefaults('badgeIcons')} variant="ghost" size="sm" className="mt-1">Khôi phục mặc định</Button>
        </div>

        <Button type="submit" size="lg" className="w-full">Lưu tất cả thay đổi</Button>
      </form>
    </Card>
  );
};


import React, { useState, FormEvent, useEffect } from 'react';
import { User, UserRole, Gender } from '../../types';
import { useAuth } from '../../hooks/useAuth';
import { useData } from '../../hooks/useData';
import { Button } from '../shared/Button';
import { Input } from '../shared/Input';
import { Modal } from '../shared/Modal';
import { Card } from '../shared/Card';
import { Icons } from '../../constants';

export const ChildAccountManagement: React.FC = () => {
  const { currentUser } = useAuth();
  const { users, addUser, updateUser, getChildren, getEffectiveAvatars } = useData();
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingChild, setEditingChild] = useState<User | null>(null);
  
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [dob, setDob] = useState('');
  const [gender, setGender] = useState<Gender>(Gender.OTHER);
  const [avatarIcon, setAvatarIcon] = useState('');
  const [formError, setFormError] = useState<string | null>(null);

  const parentChildren = currentUser ? getChildren(currentUser.id) : [];
  const availableAvatars = getEffectiveAvatars(currentUser);

  useEffect(() => {
    if (!avatarIcon && availableAvatars.length > 0) {
      setAvatarIcon(availableAvatars[0]);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [availableAvatars]);


  useEffect(() => {
    if (editingChild) {
      setName(editingChild.name);
      setUsername(editingChild.username);
      setDob(editingChild.dob || '');
      setGender(editingChild.gender || Gender.OTHER);
      setAvatarIcon(editingChild.avatarIcon || (availableAvatars.length > 0 ? availableAvatars[0] : ''));
    } else {
      resetForm();
    }
    setFormError(null);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editingChild, availableAvatars, isModalOpen]);

  const resetForm = () => {
    setName('');
    setUsername('');
    setDob('');
    setGender(Gender.OTHER);
    setAvatarIcon(availableAvatars.length > 0 ? availableAvatars[0] : '');
    setFormError(null);
  };

  const handleOpenModal = (child?: User) => {
    setEditingChild(child || null);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingChild(null);
    resetForm();
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    setFormError(null);

    if (editingChild && editingChild.username !== username && users.find(u => u.username === username && u.id !== editingChild.id)) {
        setFormError("Tên đăng nhập này đã được sử dụng. Vui lòng chọn tên khác.");
        return;
    }
    if (!editingChild && users.find(u => u.username === username)) {
        setFormError("Tên đăng nhập này đã được sử dụng. Vui lòng chọn tên khác.");
        return;
    }

    const childDataPayload = {
      name,
      username,
      dob: dob || undefined, 
      gender,
      avatarIcon,
    };

    try {
        if (editingChild) {
          await updateUser(editingChild.id, childDataPayload);
        } else {
          await addUser({
              name,
              username,
              dob: dob || undefined,
              gender,
              avatarIcon,
          }, currentUser); // Pass currentUser as currentParentUser
        }
        handleCloseModal();
    } catch (err) {
        setFormError(err instanceof Error ? err.message : "Có lỗi xảy ra khi lưu thông tin.");
    }
  };

  return (
    <Card title="Quản lý tài khoản con" titleAction={<Button onClick={() => handleOpenModal()} size="sm" leftIcon={Icons.Add}>Thêm con</Button>}>
      {parentChildren.length === 0 ? (
        <p className="text-gray-500 dark:text-gray-400">Chưa có tài khoản nào của con.</p>
      ) : (
        <ul className="space-y-3">
          {parentChildren.map(child => (
            <li key={child.id} className="flex justify-between items-center p-3 app-card-bg rounded-lg shadow">
              <div className="flex items-center">
                <span className="text-2xl mr-3">{child.avatarIcon}</span>
                <div>
                  <p className="font-semibold">{child.name} (@{child.username})</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Điểm: {child.points || 0}</p>
                </div>
              </div>
              <Button onClick={() => handleOpenModal(child)} variant="ghost" size="sm" leftIcon={Icons.Edit}>Sửa</Button>
            </li>
          ))}
        </ul>
      )}

      <Modal isOpen={isModalOpen} onClose={handleCloseModal} title={editingChild ? 'Chỉnh sửa tài khoản con' : 'Thêm tài khoản con'}>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input label="Họ và tên" value={name} onChange={e => setName(e.target.value)} required />
          <Input label="Tên đăng nhập" value={username} onChange={e => setUsername(e.target.value)} required />
          <Input label="Ngày sinh" type="date" value={dob} onChange={e => setDob(e.target.value)} />
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Giới tính</label>
            <select value={gender} onChange={e => setGender(e.target.value as Gender)} className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-DEFAULT focus:border-primary-DEFAULT sm:text-sm rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-white">
              <option value={Gender.MALE}>Nam</option>
              <option value={Gender.FEMALE}>Nữ</option>
              <option value={Gender.OTHER}>Khác</option>
            </select>
          </div>
           <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Biểu tượng đại diện</label>
            <div className="mt-1 flex space-x-2 flex-wrap max-h-32 overflow-y-auto bg-gray-50 dark:bg-gray-800 p-2 rounded-md">
                {availableAvatars.map(iconString => (
                    <button type="button" key={iconString} onClick={() => setAvatarIcon(iconString)} className={`p-2 rounded-full text-2xl transition-transform hover:scale-110 ${avatarIcon === iconString ? 'ring-2 ring-primary-DEFAULT bg-primary-light/30' : 'hover:bg-gray-200 dark:hover:bg-gray-600'}`}>
                        {iconString}
                    </button>
                ))}
            </div>
          </div>
          {formError && <p className="text-red-500 text-sm">{formError}</p>}
          <div className="flex justify-end pt-2">
            <Button type="button" variant="secondary" onClick={handleCloseModal} className="mr-2">Hủy</Button>
            <Button type="submit">{editingChild ? 'Lưu thay đổi' : 'Thêm con'}</Button>
          </div>
        </form>
      </Modal>
    </Card>
  );
};

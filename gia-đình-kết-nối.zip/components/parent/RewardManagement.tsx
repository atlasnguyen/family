
import React, { useState, FormEvent, useEffect } from 'react';
import { Reward } from '../../types';
import { useAuth } from '../../hooks/useAuth';
import { useData } from '../../hooks/useData';
import { Button } from '../shared/Button';
import { Input, Textarea } from '../shared/Input';
import { Modal } from '../shared/Modal';
import { Card } from '../shared/Card';
import { Icons } from '../../constants';

export const RewardManagement: React.FC = () => {
  const { currentUser } = useAuth();
  const { getRewards, addReward, updateReward, deleteReward, getEffectiveRewardIcons } = useData();
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingReward, setEditingReward] = useState<Reward | null>(null);
  
  const [name, setName] = useState('');
  const [icon, setIcon] = useState('');
  const [pointCost, setPointCost] = useState<number>(50);
  const [category, setCategory] = useState('');
  const [description, setDescription] = useState('');
  const [quantity, setQuantity] = useState<number>(1);
  const [formError, setFormError] = useState<string | null>(null);

  const parentRewards = currentUser ? getRewards(currentUser.id) : [];
  const availableRewardIcons = getEffectiveRewardIcons(currentUser);

  useEffect(() => {
    if (!icon && availableRewardIcons.length > 0) {
      setIcon(availableRewardIcons[0]);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [availableRewardIcons]);

  useEffect(() => {
    if (editingReward) {
      setName(editingReward.name);
      setIcon(editingReward.icon);
      setPointCost(editingReward.pointCost);
      setCategory(editingReward.category);
      setDescription(editingReward.description);
      setQuantity(editingReward.quantity);
    } else {
      resetForm();
    }
    setFormError(null);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editingReward, availableRewardIcons, isModalOpen]);

  const resetForm = () => {
    setName('');
    setIcon(availableRewardIcons.length > 0 ? availableRewardIcons[0] : Icons.Reward);
    setPointCost(50);
    setCategory('');
    setDescription('');
    setQuantity(1);
    setFormError(null);
  };

  const handleOpenModal = (reward?: Reward) => {
    setEditingReward(reward || null);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingReward(null);
    resetForm();
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    setFormError(null);

    const rewardData = {
      name,
      icon,
      pointCost: Number(pointCost),
      category,
      description,
      quantity: Number(quantity),
    };

    try {
        if (editingReward) {
          await updateReward(editingReward.id, rewardData);
        } else {
          await addReward(rewardData, currentUser); // Pass currentUser
        }
        handleCloseModal();
    } catch (err) {
        setFormError(err instanceof Error ? err.message : "Có lỗi xảy ra khi lưu phần thưởng.");
    }
  };
  
  const handleDeleteReward = async (rewardId: string) => {
    if (window.confirm("Bạn có chắc muốn xóa phần quà này?")) {
        try {
            await deleteReward(rewardId);
        } catch (err) {
            alert(err instanceof Error ? err.message : "Không thể xóa phần thưởng.");
        }
    }
  };


  return (
    <Card title="Thư viện quà tặng" titleAction={<Button onClick={() => handleOpenModal()} size="sm" leftIcon={Icons.Add}>Tạo quà tặng</Button>}>
      {parentRewards.length === 0 ? (
        <p className="text-gray-500 dark:text-gray-400">Chưa có quà tặng nào được tạo.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {parentRewards.map(reward => (
            <div key={reward.id} className="p-4 app-card-bg rounded-lg shadow flex flex-col justify-between">
              <div>
                <div className="flex items-center mb-2">
                    <span className="text-3xl mr-3">{reward.icon}</span>
                    <h4 className="font-semibold text-lg">{reward.name}</h4>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">{reward.description}</p>
                <p className="text-xs text-gray-500 dark:text-gray-500 mb-1">Loại: {reward.category || 'Chung'}</p>
                <p className="text-sm font-medium app-text-accent mb-1">{Icons.Points} {reward.pointCost} điểm</p>
                <p className="text-xs text-gray-500 dark:text-gray-500">Số lượng còn: {reward.quantity}</p>
              </div>
              <div className="flex space-x-2 mt-3">
                  <Button onClick={() => handleOpenModal(reward)} variant="ghost" size="sm" className="flex-grow">{Icons.Edit} Sửa</Button>
                  <Button onClick={() => handleDeleteReward(reward.id)} variant="ghost" size="sm" className="text-red-500 hover:text-red-700 flex-grow">{Icons.Delete} Xóa</Button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal isOpen={isModalOpen} onClose={handleCloseModal} title={editingReward ? 'Chỉnh sửa quà tặng' : 'Tạo quà tặng mới'}>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input label="Tên quà tặng" value={name} onChange={e => setName(e.target.value)} required />
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Biểu tượng</label>
            <div className="mt-1 flex space-x-2 flex-wrap bg-gray-50 dark:bg-gray-800 p-2 rounded-md max-h-32 overflow-y-auto">
                {availableRewardIcons.map(icString => (
                    <button type="button" key={icString} onClick={() => setIcon(icString)} className={`p-2 rounded-full text-2xl transition-transform hover:scale-110 ${icon === icString ? 'ring-2 ring-primary-DEFAULT bg-primary-light/30' : 'hover:bg-gray-200 dark:hover:bg-gray-600'}`}>
                        {icString}
                    </button>
                ))}
            </div>
          </div>
          <Input label="Số điểm đổi quà" type="number" value={pointCost} onChange={e => setPointCost(Math.max(0, parseInt(e.target.value)))} required min="0" />
          <Input label="Nhóm quà tặng (VD: Đồ chơi, Sách)" value={category} onChange={e => setCategory(e.target.value)} />
          <Textarea label="Mô tả quà tặng" value={description} onChange={e => setDescription(e.target.value)} rows={3} />
          <Input label="Số lượng hiện có" type="number" value={quantity} onChange={e => setQuantity(Math.max(0, parseInt(e.target.value)))} required min="0" />
          {formError && <p className="text-red-500 text-sm">{formError}</p>}
          <div className="flex justify-end pt-2">
            <Button type="button" variant="secondary" onClick={handleCloseModal} className="mr-2">Hủy</Button>
            <Button type="submit">{editingReward ? 'Lưu thay đổi' : 'Tạo quà tặng'}</Button>
          </div>
        </form>
      </Modal>
    </Card>
  );
};

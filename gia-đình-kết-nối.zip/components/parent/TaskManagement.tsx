
import React, { useState, FormEvent, useEffect } from 'react';
import { Task, TaskStatus } from '../../types';
import { useAuth } from '../../hooks/useAuth';
import { useData } from '../../hooks/useData';
import { Button } from '../shared/Button';
import { Input, Textarea } from '../shared/Input';
import { Modal } from '../shared/Modal';
import { Card } from '../shared/Card';
import { Icons } from '../../constants';
import { useTheme } from '../../hooks/useTheme';


export const TaskManagement: React.FC = () => {
  const { currentUser } = useAuth();
  const { getTasks, addTask, updateTask, deleteTask } = useData(); 
  const { themeName } = useTheme();
  const isGameTheme = themeName === 'game';
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [rewardPoints, setRewardPoints] = useState<number>(10);
  const [penaltyPoints, setPenaltyPoints] = useState<number>(0);
  const [deadline, setDeadline] = useState('');
  const [formError, setFormError] = useState<string | null>(null);


  const parentTasks = currentUser ? getTasks(currentUser.id) : [];

  useEffect(() => {
    if (editingTask) {
      setTitle(editingTask.title);
      setDescription(editingTask.description);
      setRewardPoints(editingTask.rewardPoints);
      setPenaltyPoints(editingTask.penaltyPoints || 0);
      setDeadline(editingTask.deadline ? editingTask.deadline.split('T')[0] : '');
    } else {
      resetForm();
    }
  }, [editingTask]);

  const resetForm = () => {
    setTitle('');
    setDescription('');
    setRewardPoints(10);
    setPenaltyPoints(0);
    setDeadline('');
    setFormError(null);
  };

  const handleOpenModal = (task?: Task) => {
    setEditingTask(task || null);
    setIsModalOpen(true);
    setFormError(null);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingTask(null);
    resetForm();
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    setFormError(null);
    setIsSubmitting(true);

    const taskData = {
      title,
      description,
      rewardPoints: Number(rewardPoints),
      penaltyPoints: Number(penaltyPoints),
      deadline: deadline ? new Date(deadline).toISOString() : undefined,
    };

    try {
      if (editingTask) {
        updateTask(editingTask.id, taskData);
      } else {
        addTask(taskData, currentUser); // Pass currentUser
      }
      handleCloseModal();
    } catch (err) {
      setFormError(err instanceof Error ? err.message : "Không thể lưu nhiệm vụ. Vui lòng thử lại.");
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleDeleteTask = (taskId: string) => {
    if (window.confirm("Bạn có chắc muốn xóa nhiệm vụ này?")) {
        try {
            deleteTask(taskId);
        } catch (err) {
            alert(err instanceof Error ? err.message : "Không thể xóa nhiệm vụ.");
        }
    }
  };


  return (
    <Card title="Thư viện nhiệm vụ" titleAction={<Button onClick={() => handleOpenModal()} size="sm" leftIcon={Icons.Add}>Tạo nhiệm vụ</Button>}>
      {parentTasks.length === 0 && (
        <p className={`text-gray-500 dark:text-gray-400 ${isGameTheme ? 'text-gameTextSecondary' : ''}`}>Chưa có nhiệm vụ nào được tạo.</p>
      )}
      {parentTasks.length > 0 && (
        <div className="space-y-3">
          {parentTasks.map(task => (
            <div key={task.id} className={`p-3 rounded-lg shadow ${isGameTheme ? 'bg-white border border-gamePrimary/20' : 'app-card-bg'}`}>
              <div className="flex justify-between items-start">
                <div>
                  <h4 className={`font-semibold ${isGameTheme ? 'text-gameTextPrimary' : ''}`}>{task.title}</h4>
                  <p className={`text-sm ${isGameTheme ? 'text-gameTextSecondary/90' : 'text-gray-600 dark:text-gray-400'}`}>{task.description}</p>
                  <p className="text-xs mt-1">
                    <span className={`font-medium ${isGameTheme ? 'text-yellow-500' : 'app-text-accent'}`}>{Icons.Points} {task.rewardPoints} điểm</span>
                    {task.penaltyPoints && task.penaltyPoints > 0 ? ` / -${task.penaltyPoints} điểm phạt` : ''}
                    {task.deadline && ` | ${Icons.Clock} Hạn: ${new Date(task.deadline).toLocaleDateString()}`}
                  </p>
                </div>
                <div className="flex space-x-2 flex-shrink-0">
                    <Button onClick={() => handleOpenModal(task)} variant="ghost" size="sm" aria-label="Sửa">{Icons.Edit}</Button>
                    <Button onClick={() => handleDeleteTask(task.id)} variant="ghost" size="sm" className="text-red-500 hover:text-red-700" aria-label="Xóa">{Icons.Delete}</Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal isOpen={isModalOpen} onClose={handleCloseModal} title={editingTask ? 'Chỉnh sửa nhiệm vụ' : 'Tạo nhiệm vụ mới'}>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input label="Tiêu đề" value={title} onChange={e => setTitle(e.target.value)} required disabled={isSubmitting} />
          <Textarea label="Mô tả" value={description} onChange={e => setDescription(e.target.value)} rows={3} disabled={isSubmitting} />
          <Input label="Điểm thưởng" type="number" value={rewardPoints} onChange={e => setRewardPoints(Math.max(0, parseInt(e.target.value)))} required min="0" disabled={isSubmitting} />
          <Input label="Điểm phạt (nếu không hoàn thành)" type="number" value={penaltyPoints} onChange={e => setPenaltyPoints(Math.max(0, parseInt(e.target.value)))} min="0" disabled={isSubmitting} />
          <Input label="Thời hạn (tùy chọn)" type="date" value={deadline} onChange={e => setDeadline(e.target.value)} disabled={isSubmitting} />
          {formError && <p className="text-red-500 text-sm">{formError}</p>}
          <div className="flex justify-end pt-2">
            <Button type="button" variant="secondary" onClick={handleCloseModal} className="mr-2" disabled={isSubmitting}>Hủy</Button>
            <Button type="submit" isLoading={isSubmitting} disabled={isSubmitting}>
              {editingTask ? 'Lưu thay đổi' : 'Tạo nhiệm vụ'}
            </Button>
          </div>
        </form>
      </Modal>
    </Card>
  );
};

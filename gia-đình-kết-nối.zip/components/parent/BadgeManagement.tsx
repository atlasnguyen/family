
import React, { useState, FormEvent, useEffect } from 'react';
import { Badge, User } from '../../types';
import { useAuth } from '../../hooks/useAuth';
import { useData } from '../../hooks/useData';
import { Button } from '../shared/Button';
import { Input, Textarea } from '../shared/Input';
import { Modal } from '../shared/Modal';
import { Card } from '../shared/Card';
import { Icons } from '../../constants';

export const BadgeManagement: React.FC = () => {
  const { currentUser } = useAuth();
  const { getBadges, addBadge, awardBadge, getChildren, getEffectiveBadgeIcons } = useData();
  
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isAwardModalOpen, setIsAwardModalOpen] = useState(false);
  
  const [editingBadge, setEditingBadge] = useState<Badge | null>(null);
  const [badgeToAward, setBadgeToAward] = useState<Badge | null>(null);
  const [childToReceive, setChildToReceive] = useState<string>('');
  const [awardReason, setAwardReason] = useState('');

  const [name, setName] = useState('');
  const [icon, setIcon] = useState('');
  const [description, setDescription] = useState('');
  
  const parentBadges = currentUser ? getBadges(currentUser.id) : [];
  const children = currentUser ? getChildren(currentUser.id) : [];
  const availableBadgeIcons = getEffectiveBadgeIcons(currentUser);

  useEffect(() => {
    if (!icon && availableBadgeIcons.length > 0) {
      setIcon(availableBadgeIcons[0]);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [availableBadgeIcons]);

  useEffect(() => {
    if (editingBadge) { 
        setName(editingBadge.name);
        setIcon(editingBadge.icon);
        setDescription(editingBadge.description);
    } else {
        resetCreateForm();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editingBadge, availableBadgeIcons]);


  const resetCreateForm = () => {
    setName('');
    setIcon(availableBadgeIcons.length > 0 ? availableBadgeIcons[0] : Icons.Badge);
    setDescription('');
    setEditingBadge(null);
  };
  
  const resetAwardForm = () => {
    setBadgeToAward(null);
    setChildToReceive('');
    setAwardReason('');
  };

  const handleOpenCreateModal = (badge?: Badge) => {
    setIsCreateModalOpen(true);
  };
  
  const handleOpenAwardModal = (badge: Badge) => {
    setBadgeToAward(badge);
    setIsAwardModalOpen(true);
  };

  const handleCloseCreateModal = () => {
    setIsCreateModalOpen(false);
    resetCreateForm();
  };
  
  const handleCloseAwardModal = () => {
    setIsAwardModalOpen(false);
    resetAwardForm();
  };

  const handleCreateSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    const badgeData = { name, icon, description };
    addBadge(badgeData, currentUser); // Pass currentUser
    handleCloseCreateModal();
  };
  
  const handleAwardSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!badgeToAward || !childToReceive) return;
    awardBadge(childToReceive, badgeToAward.id, awardReason);
    handleCloseAwardModal();
  };

  return (
    <Card title="Quản lý huy hiệu" titleAction={<Button onClick={() => handleOpenCreateModal()} size="sm" leftIcon={Icons.Add}>Tạo huy hiệu</Button>}>
      {parentBadges.length === 0 ? (
        <p className="text-gray-500 dark:text-gray-400">Chưa có huy hiệu nào được tạo.</p>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {parentBadges.map(badge => (
            <div key={badge.id} className="p-4 app-card-bg rounded-lg shadow text-center">
              <span className="text-5xl">{badge.icon}</span>
              <h4 className="font-semibold text-lg mt-2">{badge.name}</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400 h-10 overflow-hidden">{badge.description}</p>
              <Button onClick={() => handleOpenAwardModal(badge)} size="sm" variant="secondary" className="mt-3 w-full">Trao huy hiệu</Button>
            </div>
          ))}
        </div>
      )}

      <Modal isOpen={isCreateModalOpen} onClose={handleCloseCreateModal} title={editingBadge ? 'Chỉnh sửa huy hiệu' : 'Tạo huy hiệu mới'}>
        <form onSubmit={handleCreateSubmit} className="space-y-4">
          <Input label="Tên huy hiệu" value={name} onChange={e => setName(e.target.value)} required />
           <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Biểu tượng</label>
            <div className="mt-1 flex space-x-2 flex-wrap bg-gray-50 dark:bg-gray-800 p-2 rounded-md max-h-32 overflow-y-auto">
                {availableBadgeIcons.map(icString => (
                    <button type="button" key={icString} onClick={() => setIcon(icString)} className={`p-2 rounded-full text-2xl transition-transform hover:scale-110 ${icon === icString ? 'ring-2 ring-primary-DEFAULT bg-primary-light/30' : 'hover:bg-gray-200 dark:hover:bg-gray-600'}`}>
                        {icString}
                    </button>
                ))}
            </div>
          </div>
          <Textarea label="Mô tả" value={description} onChange={e => setDescription(e.target.value)} rows={3} />
          <div className="flex justify-end pt-2">
            <Button type="button" variant="secondary" onClick={handleCloseCreateModal} className="mr-2">Hủy</Button>
            <Button type="submit">{editingBadge ? 'Lưu thay đổi' : 'Tạo huy hiệu'}</Button>
          </div>
        </form>
      </Modal>
      
      <Modal isOpen={isAwardModalOpen} onClose={handleCloseAwardModal} title={`Trao huy hiệu: ${badgeToAward?.name}`}>
        {badgeToAward && (
            <form onSubmit={handleAwardSubmit} className="space-y-4">
                <div>
                    <label htmlFor="childSelect" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Chọn con</label>
                    <select id="childSelect" value={childToReceive} onChange={e => setChildToReceive(e.target.value)} required className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-DEFAULT focus:border-primary-DEFAULT sm:text-sm rounded-md dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                        <option value="" disabled>-- Chọn một bé --</option>
                        {children.map(child => (
                            <option key={child.id} value={child.id}>{child.name}</option>
                        ))}
                    </select>
                </div>
                <Textarea label="Lý do trao tặng (tùy chọn)" value={awardReason} onChange={e => setAwardReason(e.target.value)} rows={2} />
                <div className="flex justify-end pt-2">
                    <Button type="button" variant="secondary" onClick={handleCloseAwardModal} className="mr-2">Hủy</Button>
                    <Button type="submit">Trao huy hiệu</Button>
                </div>
            </form>
        )}
      </Modal>
    </Card>
  );
};


import React, { useState, useEffect, useMemo } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { useData } from '../../hooks/useData';
import { User, ChildTaskStats, TaskStatus, ChildTaskInstance } from '../../types';
import { Card } from '../shared/Card';
import { Button } from '../shared/Button';
import { Input } from '../shared/Input';
import { Icons } from '../../constants';
import { useTheme } from '../../hooks/useTheme';

const formatDateISO = (date: Date): string => date.toISOString().split('T')[0];

const getWeekRange = (date: Date = new Date()): { start: string, end: string } => {
    const d = new Date(date);
    const day = d.getDay();
    const diffToMonday = d.getDate() - day + (day === 0 ? -6 : 1); // adjust when day is sunday
    const monday = new Date(d.setDate(diffToMonday));
    const sunday = new Date(monday);
    sunday.setDate(monday.getDate() + 6);
    return { start: formatDateISO(monday), end: formatDateISO(sunday) };
};

const getMonthRange = (date: Date = new Date()): { start: string, end: string } => {
    const d = new Date(date);
    const firstDay = new Date(d.getFullYear(), d.getMonth(), 1);
    const lastDay = new Date(d.getFullYear(), d.getMonth() + 1, 0);
    return { start: formatDateISO(firstDay), end: formatDateISO(lastDay) };
};


export const StatisticsView: React.FC = () => {
  const { currentUser } = useAuth();
  const { getChildren, getChildTaskInstancesByDateRange, getTaskById } = useData();
  const { themeName } = useTheme();
  const isGameTheme = themeName === 'game';
  
  const parentChildren = useMemo(() => currentUser ? getChildren(currentUser.id) : [], [currentUser, getChildren]);
  
  const [selectedChildId, setSelectedChildId] = useState<string | null>(parentChildren.length > 0 ? parentChildren[0].id : null);
  const [timeRangeType, setTimeRangeType] = useState<'today' | 'week' | 'month' | 'custom'>('week');
  const [customStartDate, setCustomStartDate] = useState<string>(formatDateISO(new Date()));
  const [customEndDate, setCustomEndDate] = useState<string>(formatDateISO(new Date()));
  const [statsData, setStatsData] = useState<ChildTaskStats | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  useEffect(() => {
    // Auto-select first child if child list changes and current selection is invalid
    if (parentChildren.length > 0 && !parentChildren.find(c => c.id === selectedChildId)) {
      setSelectedChildId(parentChildren[0].id);
    } else if (parentChildren.length === 0) {
      setSelectedChildId(null);
    }
  }, [parentChildren, selectedChildId]);


  useEffect(() => {
    if (!selectedChildId) {
      setStatsData(null);
      return;
    }

    setIsLoading(true);
    let startDate: string, endDate: string;

    switch (timeRangeType) {
      case 'today':
        startDate = endDate = formatDateISO(new Date());
        break;
      case 'week':
        const week = getWeekRange();
        startDate = week.start;
        endDate = week.end;
        break;
      case 'month':
        const month = getMonthRange();
        startDate = month.start;
        endDate = month.end;
        break;
      case 'custom':
        startDate = customStartDate;
        endDate = customEndDate;
        break;
      default:
        setIsLoading(false);
        return;
    }

    const instances = getChildTaskInstancesByDateRange(selectedChildId, startDate, endDate);
    
    let approved = 0;
    let rejected = 0;
    let pendingApproval = 0;
    let planned = 0;
    let pointsEarned = 0;

    instances.forEach(instance => {
      switch (instance.status) {
        case TaskStatus.APPROVED:
          approved++;
          const taskDetails = getTaskById(instance.taskId);
          if (taskDetails) pointsEarned += taskDetails.rewardPoints;
          break;
        case TaskStatus.REJECTED:
          rejected++;
          break;
        case TaskStatus.PENDING_APPROVAL:
          pendingApproval++;
          break;
        case TaskStatus.PLANNED:
        case TaskStatus.TODO: // Consider TODO if it appears in childTaskInstances for some reason
          planned++;
          break;
      }
    });
    
    setStatsData({
      totalTasksInteracted: instances.length,
      approved,
      rejected,
      pendingApproval,
      planned,
      pointsEarned,
    });
    setIsLoading(false);
  }, [selectedChildId, timeRangeType, customStartDate, customEndDate, getChildTaskInstancesByDateRange, getTaskById]);

  const StatItem: React.FC<{ label: string; value: number | string, barValue?: number, barMax?: number, barColorClass?: string }> = 
    ({ label, value, barValue, barMax, barColorClass }) => (
    <div className={`p-3 rounded-lg shadow ${isGameTheme ? 'bg-white/80 border border-gamePrimary/20' : 'app-card-bg'}`}>
      <p className={`text-sm font-semibold ${isGameTheme ? 'text-gameTextSecondary' : 'text-gray-500'}`}>{label}</p>
      <p className={`text-2xl font-bold ${isGameTheme ? 'text-gamePrimary' : 'app-text-accent'}`}>{value}</p>
      {barValue !== undefined && barMax !== undefined && barMax > 0 && (
        <div className="mt-1 h-3 bg-gray-200 dark:bg-gray-600 rounded-full overflow-hidden">
          <div 
            className={`${barColorClass || 'bg-blue-500'} h-full rounded-full`}
            style={{ width: `${(barValue / barMax) * 100}%` }}
          ></div>
        </div>
      )}
    </div>
  );

  if (!currentUser) return null;

  return (
    <Card title="Thống kê hiệu suất của con" titleIcon={Icons.Statistics}>
      <div className="mb-6 space-y-4 md:space-y-0 md:flex md:items-end md:space-x-4">
        <div>
          <label htmlFor="child-select" className={`block text-sm font-medium ${isGameTheme ? 'text-gameTextPrimary' : 'text-gray-700'}`}>Chọn con:</label>
          <select 
            id="child-select" 
            value={selectedChildId || ''} 
            onChange={e => setSelectedChildId(e.target.value)}
            className={`mt-1 block w-full md:w-auto pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-DEFAULT focus:border-primary-DEFAULT sm:text-sm rounded-md ${isGameTheme ? 'bg-white text-gameTextPrimary border-gamePrimary/30' : 'dark:bg-gray-700 dark:border-gray-600 dark:text-white'}`}
            disabled={parentChildren.length === 0}
          >
            {parentChildren.length === 0 ? (
                <option value="">Không có con nào</option>
            ) : (
                parentChildren.map(child => <option key={child.id} value={child.id}>{child.name}</option>)
            )}
          </select>
        </div>
        <div className="flex flex-wrap gap-2">
          {(['today', 'week', 'month', 'custom'] as const).map(range => (
            <Button 
              key={range} 
              onClick={() => setTimeRangeType(range)}
              variant={timeRangeType === range ? 'primary' : 'secondary'}
              size="sm"
            >
              {range === 'today' ? 'Hôm nay' : range === 'week' ? 'Tuần này' : range === 'month' ? 'Tháng này' : 'Tùy chọn'}
            </Button>
          ))}
        </div>
      </div>

      {timeRangeType === 'custom' && (
        <div className="mb-6 grid grid-cols-1 md:grid-cols-2 gap-4 p-3 border rounded-lg dark:border-gray-600">
          <Input type="date" label="Từ ngày" value={customStartDate} onChange={e => setCustomStartDate(e.target.value)} />
          <Input type="date" label="Đến ngày" value={customEndDate} onChange={e => setCustomEndDate(e.target.value)} />
        </div>
      )}

      {isLoading && <p className="text-center py-4">Đang tải dữ liệu thống kê...</p>}
      
      {!isLoading && !selectedChildId && parentChildren.length > 0 && (
          <p className="text-center py-4 text-gray-500">Vui lòng chọn một bé để xem thống kê.</p>
      )}
       {!isLoading && parentChildren.length === 0 && (
          <p className="text-center py-4 text-gray-500">Bạn chưa thêm tài khoản nào cho con. Hãy thêm con ở mục "Quản lý con".</p>
      )}


      {!isLoading && selectedChildId && !statsData && (
          <p className="text-center py-4 text-gray-500">Không có dữ liệu cho lựa chọn này.</p>
      )}

      {!isLoading && statsData && (
        <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <StatItem label="Tổng nhiệm vụ tương tác" value={statsData.totalTasksInteracted} />
                <StatItem 
                    label="Đã phê duyệt" 
                    value={statsData.approved}
                    barValue={statsData.approved}
                    barMax={statsData.totalTasksInteracted}
                    barColorClass={isGameTheme ? 'bg-green-500' : 'bg-green-500'}
                />
                <StatItem 
                    label="Bị từ chối" 
                    value={statsData.rejected} 
                    barValue={statsData.rejected}
                    barMax={statsData.totalTasksInteracted}
                    barColorClass={isGameTheme ? 'bg-red-500' : 'bg-red-500'}
                />
                 <StatItem 
                    label="Chờ phê duyệt" 
                    value={statsData.pendingApproval} 
                    barValue={statsData.pendingApproval}
                    barMax={statsData.totalTasksInteracted}
                    barColorClass={isGameTheme ? 'bg-yellow-500' : 'bg-yellow-400'}
                />
                <StatItem 
                    label="Đang kế hoạch" 
                    value={statsData.planned} 
                    barValue={statsData.planned}
                    barMax={statsData.totalTasksInteracted}
                    barColorClass={isGameTheme ? 'bg-blue-500' : 'bg-blue-400'}
                />
                <StatItem label="Tổng điểm kiếm được" value={`${statsData.pointsEarned} ${Icons.Points}`} />
            </div>
            {statsData.totalTasksInteracted > 0 && (
                 <div className={`mt-4 p-4 rounded-lg shadow ${isGameTheme ? 'bg-white/80' : 'app-card-bg'}`}>
                    <h4 className={`text-md font-semibold mb-2 ${isGameTheme ? 'text-gameTextPrimary' : 'app-text-accent'}`}>Phân bổ nhiệm vụ</h4>
                    <div className="space-y-2 text-sm">
                        {Object.entries({
                            "Đã phê duyệt": {value: statsData.approved, color: isGameTheme? "bg-green-500" : "bg-green-500"},
                            "Bị từ chối": {value: statsData.rejected, color: isGameTheme ? "bg-red-500" : "bg-red-500"},
                            "Chờ duyệt": {value: statsData.pendingApproval, color: isGameTheme ? "bg-yellow-500" : "bg-yellow-400"},
                            "Kế hoạch": {value: statsData.planned, color: isGameTheme ? "bg-blue-500" : "bg-blue-400"},
                        }).map(([key, data]) => (
                            data.value > 0 && (
                            <div key={key}>
                                <div className="flex justify-between mb-0.5">
                                    <span>{key}</span>
                                    <span>{data.value} ({((data.value / statsData.totalTasksInteracted) * 100).toFixed(0)}%)</span>
                                </div>
                                <div className="h-4 bg-gray-200 dark:bg-gray-600 rounded-full overflow-hidden">
                                    <div 
                                        className={`${data.color} h-full rounded-full transition-all duration-500 ease-out`}
                                        style={{ width: `${(data.value / statsData.totalTasksInteracted) * 100}%`}}
                                    ></div>
                                </div>
                            </div>
                            )
                        ))}
                    </div>
                 </div>
            )}
        </div>
      )}
    </Card>
  );
};


import React, { useState, FormEvent, useEffect } from 'react';
import { Game } from '../../types';
import { useAuth } from '../../hooks/useAuth';
import { useData } from '../../hooks/useData';
import { Button } from '../shared/Button';
import { Input, Textarea } from '../shared/Input';
import { Modal } from '../shared/Modal';
import { Card } from '../shared/Card';
import { Icons } from '../../constants';
import { useTheme } from '../../hooks/useTheme';

export const GameManagement: React.FC = () => {
  const { currentUser } = useAuth();
  const { getGames, addGame, updateGame, deleteGame, getEffectiveGameIcons } = useData();
  const { themeName } = useTheme();
  const isGameTheme = themeName === 'game';
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingGame, setEditingGame] = useState<Game | null>(null);
  
  const [name, setName] = useState('');
  const [icon, setIcon] = useState('');
  const [description, setDescription] = useState('');
  const [pointCostToPlay, setPointCostToPlay] = useState<number>(10);
  const [timeLimitMinutes, setTimeLimitMinutes] = useState<number>(15);
  const [formError, setFormError] = useState<string|null>(null);

  const parentGames = currentUser ? getGames(currentUser.id) : [];
  const availableGameIcons = getEffectiveGameIcons(currentUser);

  useEffect(() => {
    if (!icon && availableGameIcons.length > 0) {
      setIcon(availableGameIcons[0]);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [availableGameIcons]);

  useEffect(() => {
    if (editingGame) {
      setName(editingGame.name);
      setIcon(editingGame.icon);
      setDescription(editingGame.description);
      setPointCostToPlay(editingGame.pointCostToPlay);
      setTimeLimitMinutes(editingGame.timeLimitMinutes);
    } else {
      resetForm();
    }
    setFormError(null);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editingGame, availableGameIcons, isModalOpen]);

  const resetForm = () => {
    setName('');
    setIcon(availableGameIcons.length > 0 ? availableGameIcons[0] : '');
    setDescription('');
    setPointCostToPlay(10);
    setTimeLimitMinutes(15);
    setFormError(null);
  };

  const handleOpenModal = (game?: Game) => {
    setEditingGame(game || null);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingGame(null);
    resetForm();
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    setFormError(null);

    const gameData = {
      name,
      icon,
      description,
      pointCostToPlay: Number(pointCostToPlay),
      timeLimitMinutes: Number(timeLimitMinutes),
    };

    try {
        if (editingGame) {
         await updateGame(editingGame.id, gameData);
        } else {
         await addGame(gameData, currentUser); // Pass currentUser
        }
        handleCloseModal();
    } catch(err) {
        setFormError(err instanceof Error ? err.message : "Không thể lưu trò chơi.");
    }
  };
  
  const handleDeleteGame = async (gameId: string) => {
    if (window.confirm("Bạn có chắc muốn xóa trò chơi này?")) {
        try {
            await deleteGame(gameId);
        } catch (err) {
             alert(err instanceof Error ? err.message : "Không thể xóa trò chơi.");
        }
    }
  };

  return (
    <Card title="Quản lý Trò Chơi Giáo Dục" titleIcon={Icons.Game} titleAction={<Button onClick={() => handleOpenModal()} size="sm" leftIcon={Icons.Add}>Thêm trò chơi</Button>}>
      {parentGames.length === 0 ? (
        <p className={`text-center py-4 ${isGameTheme ? 'text-gameTextSecondary' : 'text-gray-500 dark:text-gray-400'}`}>Chưa có trò chơi nào được tạo. Hãy thêm trò chơi để các con giải trí và học hỏi!</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {parentGames.map(game => (
            <div key={game.id} className={`p-4 rounded-xl shadow-lg flex flex-col justify-between ${isGameTheme ? 'bg-white border-2 border-gameSecondary/40' : 'app-card-bg'}`}>
              <div>
                <div className="flex items-center mb-2">
                    <span className="text-4xl mr-3 filter drop-shadow-sm">{game.icon}</span>
                    <h4 className={`font-bold text-lg ${isGameTheme ? 'text-gameTextPrimary' : ''}`}>{game.name}</h4>
                </div>
                <p className={`text-sm h-16 overflow-y-auto mb-2 ${isGameTheme ? 'text-gameTextSecondary/90' : 'text-gray-600 dark:text-gray-400'}`}>{game.description}</p>
                <p className={`text-sm font-semibold flex items-center mb-1 ${isGameTheme ? 'text-gamePrimary' : 'app-text-accent'}`}>{Icons.Points} {game.pointCostToPlay} điểm / lần chơi</p>
                <p className={`text-sm flex items-center ${isGameTheme ? 'text-gameTextSecondary' : 'text-gray-500 dark:text-gray-500'}`}>{Icons.Clock} {game.timeLimitMinutes} phút / lần chơi</p>
              </div>
              <div className="flex space-x-2 mt-4">
                  <Button onClick={() => handleOpenModal(game)} variant="ghost" size="sm" className="flex-grow">{Icons.Edit} Sửa</Button>
                  <Button onClick={() => handleDeleteGame(game.id)} variant="ghost" size="sm" className="text-red-500 hover:text-red-700 flex-grow">{Icons.Delete} Xóa</Button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal isOpen={isModalOpen} onClose={handleCloseModal} title={editingGame ? 'Chỉnh sửa trò chơi' : 'Thêm trò chơi mới'}>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input label="Tên trò chơi" value={name} onChange={e => setName(e.target.value)} required />
          <div>
            <label className={`block text-sm font-medium ${isGameTheme ? 'text-gameTextPrimary/80' : 'text-gray-700 dark:text-gray-300'}`}>Biểu tượng trò chơi</label>
            <div className="mt-2 flex space-x-2 flex-wrap bg-gray-100 dark:bg-gray-700 p-2 rounded-lg max-h-32 overflow-y-auto">
                {availableGameIcons.map(ic => (
                    <button type="button" key={ic} onClick={() => setIcon(ic)} className={`p-2 rounded-full text-3xl transition-transform duration-150 hover:scale-110 ${icon === ic ? 'ring-2 ring-offset-1 ring-primary-DEFAULT bg-primary-light/30' : 'hover:bg-gray-200 dark:hover:bg-gray-600'}`}>
                        {ic}
                    </button>
                ))}
            </div>
          </div>
          <Textarea label="Mô tả trò chơi" value={description} onChange={e => setDescription(e.target.value)} rows={3} placeholder="Mô tả ngắn về trò chơi, luật chơi cơ bản..." />
          <Input label="Điểm để chơi (Point Cost)" type="number" value={pointCostToPlay} onChange={e => setPointCostToPlay(Math.max(0, parseInt(e.target.value)))} required min="0" />
          <Input label="Thời gian chơi mỗi lần (phút)" type="number" value={timeLimitMinutes} onChange={e => setTimeLimitMinutes(Math.max(1, parseInt(e.target.value)))} required min="1" />
          {formError && <p className="text-red-500 text-sm">{formError}</p>}
          <div className="flex justify-end pt-3">
            <Button type="button" variant="secondary" onClick={handleCloseModal} className="mr-3">Hủy</Button>
            <Button type="submit">{editingGame ? 'Lưu thay đổi' : 'Thêm trò chơi'}</Button>
          </div>
        </form>
      </Modal>
    </Card>
  );
};

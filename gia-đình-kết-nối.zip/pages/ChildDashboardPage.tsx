
import React, { useState } from 'react';
import { MainLayout } from '../components/layout/MainLayout';
import { WeeklyPlanner } from '../components/child/WeeklyPlanner';
import { DailyTasks } from '../components/child/DailyTasks';
import { RewardStore } from '../components/child/RewardStore';
import { MyBadges } from '../components/child/MyBadges';
import { PointHistory } from '../components/child/PointHistory';
import { DailyQuoteDisplay } from '../components/shared/DailyQuoteDisplay';
import { FamilyIntroDisplay } from '../components/child/FamilyIntroDisplay';
import { GameCenter } from '../components/child/GameCenter'; 
import { JournalTabContent } from '../components/child/JournalTabContent'; // New import
import { Card } from '../components/shared/Card';
import { useTheme } from '../hooks/useTheme';
import { Icons } from '../constants';

enum ChildTab {
  DAILY = "DAILY",
  WEEKLY = "WEEKLY",
  REWARDS = "REWARDS",
  BADGES = "BADGES",
  POINTS = "POINTS",
  GAMES = "GAMES", 
  JOURNAL = "JOURNAL", // New tab
}

const tabConfig = {
    [ChildTab.DAILY]: { label: "Hôm Nay Con Vui", icon: Icons.Task },
    [ChildTab.WEEKLY]: { label: "Lịch Tuần Của Con", icon: Icons.Calendar },
    [ChildTab.JOURNAL]: { label: "Nhật Ký Của Con", icon: Icons.Journal }, // Config for new tab
    [ChildTab.REWARDS]: { label: "Cửa Hàng Diệu Kỳ", icon: Icons.Reward },
    [ChildTab.BADGES]: { label: "Bộ Sưu Tập Sao", icon: Icons.Badge },
    [ChildTab.POINTS]: { label: "Kho Báu Điểm Con", icon: Icons.Points },
    [ChildTab.GAMES]: { label: "Vui Chơi Có Thưởng", icon: Icons.Game }, 
};

export const ChildDashboardPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<ChildTab>(ChildTab.DAILY);
  const { themeName } = useTheme();
  const isGameTheme = themeName === 'game';
  const isCartoonTheme = themeName === 'cartoon';

  const renderTabContent = () => {
    switch (activeTab) {
      case ChildTab.DAILY:
        return <DailyTasks />;
      case ChildTab.WEEKLY:
        return <WeeklyPlanner />;
      case ChildTab.JOURNAL:
        return <JournalTabContent />; // Render new component
      case ChildTab.REWARDS:
        return <RewardStore />;
      case ChildTab.BADGES:
        return <MyBadges />;
      case ChildTab.POINTS:
        return <PointHistory />;
      case ChildTab.GAMES: 
        return <GameCenter />;
      default:
        return <DailyTasks />;
    }
  };
  
  const TabButton: React.FC<{tab: ChildTab, currentTab: ChildTab, onClick: () => void}> = ({tab, currentTab, onClick}) => {
    const isActive = tab === currentTab;
    const config = tabConfig[tab];
    let activeClasses = 'app-button text-white shadow-lg';
    let inactiveClasses = 'hover:bg-[var(--theme-bg-secondary)] text-[var(--theme-text-primary)] opacity-80 hover:opacity-100';

    if (isGameTheme) {
        activeClasses = 'bg-gameSecondary text-gameButtonText shadow-interactive-md tab-button-active';
        inactiveClasses = 'bg-white/70 text-gameTextPrimary/80 hover:bg-white';
    } else if (isCartoonTheme) {
        activeClasses = 'bg-cartoonSecondary text-cartoonTextPrimary shadow-lg tab-button-active ring-2 ring-cartoonAccent';
        inactiveClasses = 'bg-cartoonPrimary/80 text-white hover:bg-cartoonPrimary';
    }

    return (
        <button 
            onClick={onClick}
            className={`
                flex-grow sm:flex-none flex flex-col sm:flex-row items-center justify-center p-2 sm:px-4 sm:py-3 
                font-bold text-xs sm:text-sm rounded-xl transition-all duration-200 ease-out
                transform hover:scale-105
                ${isActive ? activeClasses : inactiveClasses}
            `}
            aria-current={isActive ? "page" : undefined}
        >
            <span className="text-xl sm:text-base sm:mr-2">{config.icon}</span>
            {config.label}
        </button>
    );
  };

  return (
    <MainLayout>
      <FamilyIntroDisplay />
      <DailyQuoteDisplay />
      
      <div className="mb-6">
        <Card className={`${isGameTheme ? "bg-gamePrimary/10" : isCartoonTheme ? "bg-cartoonPrimary/10" : ""} p-3`}>
            <div className={`flex flex-wrap ${isGameTheme || isCartoonTheme ? 'gap-3 justify-center' : 'gap-2'}`}>
                {Object.values(ChildTab).map(tabKey => (
                     <TabButton 
                        key={tabKey} 
                        tab={tabKey as ChildTab} 
                        currentTab={activeTab} 
                        onClick={() => setActiveTab(tabKey as ChildTab)} 
                    />
                ))}
            </div>
        </Card>
      </div>
      
      {renderTabContent()}
    </MainLayout>
  );
};

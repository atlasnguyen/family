
import React, { useState } from 'react';
import { MainLayout } from '../components/layout/MainLayout';
import { ChildAccountManagement } from '../components/parent/ChildAccountManagement';
import { TaskManagement } from '../components/parent/TaskManagement';
import { RewardManagement } from '../components/parent/RewardManagement';
import { TaskApproval } from '../components/parent/TaskApproval';
import { RewardApproval } from '../components/parent/RewardApproval';
import { BadgeManagement } from '../components/parent/BadgeManagement';
import { FamilyIntroManagement } from '../components/parent/FamilyIntroManagement';
import { DailyQuoteDisplay } from '../components/shared/DailyQuoteDisplay';
import { Card } from '../components/shared/Card';
import { useTheme } from '../hooks/useTheme';
import { Icons } from '../constants';
import { StatisticsView } from '../components/parent/StatisticsView';
import { GameManagement } from '../components/parent/GameManagement';
import { ContentCustomizationPanel } from '../components/parent/ContentCustomizationPanel'; // Import new panel

enum ParentTab {
  CHILDREN = "CHILDREN",
  TASKS = "TASKS",
  REWARDS = "REWARDS",
  APPROVALS = "APPROVALS",
  BADGES = "BADGES",
  GAMES = "GAMES", 
  FAMILY = "FAMILY",
  STATS = "STATS",
  CUSTOMIZATION = "CUSTOMIZATION" // New tab
}

const tabConfig = {
    [ParentTab.CHILDREN]: { label: "Các Bé Yêu", icon: Icons.Child },
    [ParentTab.TASKS]: { label: "Thử Thách Vui", icon: Icons.Task },
    [ParentTab.REWARDS]: { label: "Phần Thưởng", icon: Icons.Reward },
    [ParentTab.APPROVALS]: { label: "Xem Con Hoàn Thành", icon: Icons.Approve },
    [ParentTab.BADGES]: { label: "Ngôi Sao Thành Tích", icon: Icons.Badge },
    [ParentTab.GAMES]: { label: "Trò Chơi Giáo Dục", icon: Icons.Game }, 
    [ParentTab.FAMILY]: { label: "Về Gia Đình", icon: Icons.Family },
    [ParentTab.STATS]: { label: "Hành Trình Của Con", icon: Icons.Statistics },
    [ParentTab.CUSTOMIZATION]: { label: "Tùy Chỉnh Chung", icon: Icons.Settings }, // Config for new tab
};


export const ParentDashboardPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<ParentTab>(ParentTab.CHILDREN);
  const { themeName } = useTheme();
  const isGameTheme = themeName === 'game';
  const isCartoonTheme = themeName === 'cartoon';

  const renderTabContent = () => {
    switch (activeTab) {
      case ParentTab.CHILDREN:
        return <ChildAccountManagement />;
      case ParentTab.TASKS:
        return <TaskManagement />;
      case ParentTab.REWARDS:
        return <RewardManagement />;
      case ParentTab.APPROVALS:
        return (
          <div className="space-y-6">
            <TaskApproval />
            <RewardApproval />
          </div>
        );
      case ParentTab.BADGES:
        return <BadgeManagement />;
      case ParentTab.GAMES: 
        return <GameManagement />;
      case ParentTab.FAMILY:
        return <FamilyIntroManagement />;
      case ParentTab.STATS:
        return <StatisticsView />;
      case ParentTab.CUSTOMIZATION:
        return <ContentCustomizationPanel />; // Render new panel
      default:
        return <ChildAccountManagement />;
    }
  };
  
  const TabButton: React.FC<{tab: ParentTab, currentTab: ParentTab, onClick: () => void}> = ({tab, currentTab, onClick}) => {
    const isActive = tab === currentTab;
    const config = tabConfig[tab];
    let activeClasses = 'app-button text-white shadow-lg';
    let inactiveClasses = 'hover:bg-[var(--theme-bg-secondary)] text-[var(--theme-text-primary)] opacity-80 hover:opacity-100';

    if (isGameTheme) {
        activeClasses = 'bg-gameSecondary text-gameButtonText shadow-interactive-md tab-button-active';
        inactiveClasses = 'bg-white/70 text-gameTextPrimary/80 hover:bg-white';
    } else if (isCartoonTheme) {
        activeClasses = 'bg-cartoonSecondary text-cartoonTextPrimary shadow-lg tab-button-active ring-2 ring-cartoonAccent'; 
        inactiveClasses = 'bg-cartoonPrimary/80 text-white hover:bg-cartoonPrimary';
    }


    return (
        <button 
            onClick={onClick}
            className={`
                flex-grow sm:flex-none flex flex-col sm:flex-row items-center justify-center p-2 sm:px-4 sm:py-3 
                font-bold text-xs sm:text-sm rounded-xl transition-all duration-200 ease-out
                transform hover:scale-105
                ${isActive ? activeClasses : inactiveClasses}
            `}
            aria-current={isActive ? "page" : undefined}
        >
            <span className="text-xl sm:text-base sm:mr-2">{config.icon}</span>
            {config.label}
        </button>
    );
  };


  return (
    <MainLayout>
      <DailyQuoteDisplay />
      <div className="mb-6">
          <Card className={`${isGameTheme ? "bg-gamePrimary/10" : isCartoonTheme ? "bg-cartoonPrimary/10" : ""} p-3`}>
            <div className={`flex flex-wrap ${isGameTheme || isCartoonTheme ? 'gap-3 justify-center' : 'gap-2'}`}>
                {Object.values(ParentTab).map(tabKey => (
                     <TabButton 
                        key={tabKey} 
                        tab={tabKey as ParentTab} 
                        currentTab={activeTab} 
                        onClick={() => setActiveTab(tabKey as ParentTab)} 
                    />
                ))}
            </div>
          </Card>
      </div>
      
      {renderTabContent()}
    </MainLayout>
  );
};


import React, { useState, FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { UserRole } from '../types';
import { APP_NAME, Icons } from '../constants';
import { Button } from '../components/shared/Button';
import { Input } from '../components/shared/Input';
import { Card } from '../components/shared/Card';
import { useTheme } from '../hooks/useTheme';

export const LoginPage: React.FC = () => {
  const [username, setUsername] = useState('');
  // Password field removed for simplicity, reverting to username-only
  const { login, isLoading, error: authError } = useAuth(); // isLoading might be minimal now
  const [formError, setFormError] = useState<string | null>(null);
  const navigate = useNavigate();
  const { themeName } = useTheme();
  const isGameTheme = themeName === 'game';

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!username.trim()) {
      setFormError("Con ơi, chưa nhập tên kìa!");
      return;
    }

    try {
      await login(username.trim()); // Call synchronous login (still wrapped in async for consistency)
      // Navigation will be handled by AppRoutes based on currentUser update
    } catch (err) {
      if (err instanceof Error) {
        setFormError(err.message || 'Đăng nhập không thành công. Thử lại con nhé!');
      } else {
        setFormError('Có lỗi xảy ra, con thử lại sau nha.');
      }
    }
  };
  
  const iconAnimationClass = isGameTheme ? "animate-bounce-slow" : "";

  return (
    <div className={`min-h-screen flex flex-col items-center justify-center app-bg p-4 ${isGameTheme ? 'game-font' : ''}`}>
      <Card className="w-full max-w-lg shadow-xl" titleIcon={isGameTheme ? '🎮' : undefined}>
        <div className="text-center mb-6 sm:mb-8">
          <span className={`text-6xl sm:text-7xl ${iconAnimationClass}`}>{isGameTheme ? Icons.Home : Icons.Family}</span>
          <h1 className={`text-4xl sm:text-5xl font-extrabold mt-3 ${isGameTheme ? 'text-gamePrimary' : 'app-text-accent'}`}>{APP_NAME}</h1>
          <p className={`mt-2 text-base sm:text-lg ${isGameTheme ? 'text-gameTextSecondary' : 'text-gray-600 dark:text-gray-400'}`}>
            {isGameTheme ? "Cùng nhau khám phá & học hỏi thật vui nào!" : "Kết nối yêu thương, cùng con khôn lớn."}
          </p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-5">
          <Input
            label="Tên đăng nhập của con/bố mẹ"
            id="username"
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
            placeholder={isGameTheme ? "gõ tên đăng nhập ở đây..." : "VD: BoDai, BeNgoan..."}
            className="text-lg"
            disabled={isLoading}
          />
          {/* Password input removed */}
          {(formError || authError) && <p className="text-red-500 text-sm text-center font-semibold bg-red-100 p-2 rounded-lg">{formError || authError}</p>}
          <Button type="submit" className="w-full" size={isGameTheme ? "xl" : "lg"} variant={isGameTheme ? "primary" : "primary"} isLoading={isLoading}>
            {isGameTheme ? (isLoading ? "Đang Vô..." : "Vào Chơi Thôi!") : (isLoading ? "Đang Vào..." : "Bắt Đầu Nào!")}
          </Button>
        </form>
         <div className="mt-8 text-center text-sm">
            <p className={`${isGameTheme ? 'text-gameTextSecondary' : 'text-gray-600 dark:text-gray-400'}`}>Con chưa có tài khoản?</p>
            <p className={`${isGameTheme ? 'text-gameTextPrimary/80' : 'text-gray-500 dark:text-gray-500'}`}>Bố mẹ có thể tạo tài khoản cho con ở mục quản lý nhé!</p>
        </div>
      </Card>
    </div>
  );
};

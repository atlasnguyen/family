
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

let ai: GoogleGenAI | null = null;
let apiKeyPromise: Promise<string | null> | null = null;

// This function can still be used if other AI features are added in the future.
// For now, it won't be actively called if only daily quotes were using it.
const initializeAiClient = async () => {
  if (ai) return ai;
  if (!apiKeyPromise) {
    apiKeyPromise = fetch('/config.json')
      .then(response => {
        if (!response.ok) {
          throw new Error('config.json not found or not accessible.');
        }
        return response.json();
      })
      .then(config => {
        if (!config.API_KEY || config.API_KEY === "YOUR_GEMINI_API_KEY_HERE") {
          throw new Error('API_KEY not found or is a placeholder in config.json.');
        }
        return config.API_KEY;
      })
      .catch(error => {
        console.warn("Attempt to load API_KEY from config.json failed:", error.message);
        console.warn("Gemini AI features (if any are active) might use fallback content or not work. Ensure 'config.json' exists at the root, is valid, and contains your API key.");
        return null;
      });
  }

  const apiKey = await apiKeyPromise;
  if (apiKey) {
    try {
      ai = new GoogleGenAI({ apiKey });
      return ai;
    } catch (error) {
      console.warn("Failed to initialize GoogleGenAI, even with a fetched API key:", error);
      ai = null;
    }
  }
  return null;
};

export const geminiService = {
  // getDailyQuote function removed as per user request to use manual quotes.
  // Add other Gemini API functions here if needed in the future.
  // For example:
  // generateStory: async (prompt: string): Promise<string> => {
  //   const client = await initializeAiClient();
  //   if (!client) return "AI service is unavailable at the moment.";
  //   try {
  //     const response: GenerateContentResponse = await client.models.generateContent({
  //       model: 'gemini-2.5-flash-preview-04-17',
  //       contents: prompt,
  //     });
  //     return response.text;
  //   } catch (error) {
  //     console.warn("Error generating story from Gemini:", error);
  //     return "Could not generate a story right now.";
  //   }
  // },
};

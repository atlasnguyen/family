
import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider } from './contexts/ThemeContext';
import { AuthProvider } from './contexts/AuthContext';
import { DataProvider } from './contexts/DataContext';
import { LoginPage } from './pages/LoginPage';
import { ParentDashboardPage } from './pages/ParentDashboardPage';
import { ChildDashboardPage } from './pages/ChildDashboardPage';
import { useAuth } from './hooks/useAuth'; 
import { UserRole } from './types';
import { Icons } from './constants'; // For loading spinner

// Wrapper for protected routes
const ProtectedRoute: React.FC<{ children: React.ReactElement; role?: UserRole }> = ({ children, role }) => {
  const { currentUser, isLoading: isAuthLoading } = useAuth(); // isLoading is now for initial localStorage check

  if (isAuthLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen app-bg">
        <div className="text-4xl app-text-accent animate-spin">
          {Icons.LoadingSpinner}
        </div>
        <p className="ml-3 text-lg app-text-accent">Đang tải ứng dụng...</p>
      </div>
    );
  }

  if (!currentUser) {
    return <Navigate to="/login" replace />;
  }
  if (role && currentUser.role !== role) {
    // If wrong role, navigate to their correct dashboard or a default page
    // For simplicity, redirecting to their role-specific dashboard.
    // This could also be a navigate to "/" which then redirects based on role.
    const redirectTo = currentUser.role === UserRole.PARENT ? "/parent" : "/child";
    return <Navigate to={redirectTo} replace />;
  }
  return children;
};


const AppRoutes: React.FC = () => {
  const { currentUser, isLoading: isAuthLoading } = useAuth(); 

  if (isAuthLoading && !currentUser) { 
      return (
        <div className="flex items-center justify-center min-h-screen app-bg">
            <div className="text-4xl app-text-accent animate-spin">
              {Icons.LoadingSpinner}
            </div>
             <p className="ml-3 text-lg app-text-accent">Đang kiểm tra...</p>
        </div>
      );
  }

  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route 
        path="/parent" 
        element={
          <ProtectedRoute role={UserRole.PARENT}>
            <ParentDashboardPage />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/child" 
        element={
          <ProtectedRoute role={UserRole.CHILD}>
            <ChildDashboardPage />
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/" 
        element={
          currentUser ? (
            currentUser.role === UserRole.PARENT ? <Navigate to="/parent" replace /> : <Navigate to="/child" replace />
          ) : (
            // If not auth loading and no current user, go to login
            !isAuthLoading ? <Navigate to="/login" replace /> : null // Or a generic loading/splash
          )
        } 
      />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};

const App: React.FC = () => {
  return (
    <ThemeProvider>
      <DataProvider> {/* DataProvider now wraps AuthProvider */}
        <AuthProvider> 
          <HashRouter>
            <div className="app-bg min-h-screen"> 
                <AppRoutes/>
            </div>
          </HashRouter>
        </AuthProvider>
      </DataProvider>
    </ThemeProvider>
  );
};

export default App;

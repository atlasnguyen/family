
export enum UserRole {
  PARENT = 'PARENT',
  CHILD = 'CHILD',
}

export enum Gender {
  MALE = 'MALE',
  FEMALE = 'FEMALE',
  OTHER = 'OTHER',
}

export interface User {
  id: string;
  username: string;
  password?: string; // Password should not be stored in frontend state long-term
  role: UserRole;
  name: string;
  avatarIcon: string; // Emoji or SVG string
  // Child specific
  dob?: string;
  gender?: Gender;
  points?: number;
  parentId?: string; // For child users
}

export enum TaskStatus {
  TODO = 'TODO', // Task created by parent, available for child
  PLANNED = 'PLANNED', // Child added to their weekly plan
  PENDING_APPROVAL = 'PENDING_APPROVAL', // Child marked as complete
  APPROVED = 'APPROVED', // Parent approved completion
  REJECTED = 'REJECTED', // Parent rejected completion
}

export interface Task {
  id: string;
  title: string;
  description: string;
  deadline?: string; // ISO Date string
  rewardPoints: number;
  penaltyPoints?: number;
  status: TaskStatus;
  parentId: string; // ID of the parent who created it
  assignedToChildId?: string; // If specifically assigned, or child picks it
  childSubmissionNotes?: string;
  parentFeedback?: string;
  createdAt: string; // ISO Date string
  updatedAt: string; // ISO Date string
}

// Represents a task instance in a child's weekly plan or daily list
export interface ChildTaskInstance {
  id: string; // Unique instance ID
  taskId: string; // Original task ID from parent's library
  childId: string;
  date: string; // ISO Date string (YYYY-MM-DD for the day it's planned/done)
  status: TaskStatus; // From TODO, PENDING_APPROVAL, APPROVED, REJECTED
  submissionNotes?: string; // Notes from child when completing
  parentFeedback?: string; // Feedback from parent
}


export interface Reward {
  id: string;
  name: string;
  icon: string; // Emoji or SVG string
  pointCost: number;
  category: string;
  description: string;
  quantity: number; // Available quantity
  parentId: string;
}

export enum RedeemedRewardStatus {
  PENDING_APPROVAL = 'PENDING_APPROVAL',
  APPROVED_BY_PARENT = 'APPROVED_BY_PARENT', // Parent approved, ready to be given
  DELIVERED = 'DELIVERED', // Parent has given the reward
  REJECTED_BY_PARENT = 'REJECTED_BY_PARENT',
}

export interface RedeemedReward {
  id: string;
  rewardId: string;
  childId: string;
  dateRedeemed: string; // ISO Date string
  status: RedeemedRewardStatus;
  parentId: string;
}

export interface Badge {
  id: string;
  name: string;
  icon: string; // Emoji or SVG string
  description: string;
  parentId: string;
}

export interface EarnedBadge {
  id:string;
  badgeId: string;
  childId: string;
  dateEarned: string; // ISO Date string
  reason?: string; // Why it was awarded (manual or automatic)
}

export interface FamilyIntro {
  text: string;
  parentId: string; // This might be redundant if FamilyIntro is always part of ParentCustomSettings specific to a parent
}

export interface PointTransaction {
  id: string;
  childId: string;
  amount: number; // Positive for earning, negative for spending
  reason: string; // e.g., "Task: Clean Room", "Redeemed: Toy Car"
  date: string; // ISO Date string
  taskId?: string; // Link to ChildTaskInstance ID
  redeemedRewardId?: string;
  gameId?: string; // Link to Game ID if points spent on a game
}

// For weekly planner
export interface PlannedTask {
  taskId: string;
  dayOfWeek: number; // 0 for Sunday, 1 for Monday, etc. or YYYY-MM-DD
}

export interface WeeklyPlan {
  childId: string;
  weekStartDate: string; // ISO Date string, typically a Monday
  tasks: { [date: string]: string[] }; // date: YYYY-MM-DD -> list of task IDs
}


export type ThemeName = 'ocean' | 'forest' | 'sunset' | 'game' | 'cartoon';

export interface AppTheme {
  name: ThemeName;
  background: string;
  text: string;
  primary: string;
  secondary: string;
  accent: string;
}

export interface ChildTaskStats {
  totalTasksInteracted: number;
  approved: number;
  rejected: number;
  pendingApproval: number;
  planned: number;
  pointsEarned: number;
}

export interface Game {
  id: string;
  parentId: string;
  name: string;
  icon: string; // Emoji or SVG string
  description: string;
  pointCostToPlay: number;
  timeLimitMinutes: number; // Duration of one play session
}

// Optional: For logging game plays if needed in future
export interface PlayedGameSession {
  id: string;
  gameId: string;
  childId: string;
  datePlayed: string; // ISO Date string
  pointsSpent: number;
}

export interface ParentCustomSettings {
  familyIntro?: FamilyIntro; // Added familyIntro here
  dailyQuotes?: string[];
  praiseMessages?: string[];
  avatars?: string[];
  gameIcons?: string[];
  rewardIcons?: string[];
  badgeIcons?: string[];
}

export interface MoodOption {
  emoji: string;
  label: string;
}

export interface JournalEntry {
  id: string;
  childId: string;
  date: string; // ISO YYYY-MM-DD
  title?: string;
  content: string;
  mood: string; // Emoji string from MoodOption.emoji
  createdAt: string; // ISO DateTime
  updatedAt: string; // ISO DateTime
  // Future: isPrivate: boolean (default true), sharedWithParent: boolean, parentFeedback?: string
}

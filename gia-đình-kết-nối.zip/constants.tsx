
import React from 'react';
import { AppTheme, MoodOption, ThemeName, User, UserRole } from './types';

export const APP_NAME = "Gia Đình Kết Nối"; // This name is quite good already.

export const DEFAULT_THEME: ThemeName = 'game'; 

export const THEMES: Record<ThemeName, AppTheme> = {
  ocean: {
    name: 'ocean',
    background: 'bg-blue-50',
    text: 'text-blue-800',
    primary: 'bg-blue-500',
    secondary: 'bg-blue-300',
    accent: 'text-blue-600',
  },
  forest: {
    name: 'forest',
    background: 'bg-green-50',
    text: 'text-green-800',
    primary: 'bg-green-500',
    secondary: 'bg-green-300',
    accent: 'text-green-600',
  },
  sunset: {
    name: 'sunset',
    background: 'bg-yellow-50',
    text: 'text-yellow-800',
    primary: 'bg-orange-500',
    secondary: 'bg-orange-300',
    accent: 'text-orange-600',
  },
  game: { 
    name: 'game',
    background: 'bg-gameBackground', 
    text: 'text-gameTextPrimary',
    primary: 'bg-gamePrimary',
    secondary: 'bg-gameSecondary',
    accent: 'text-gameAccent',
  },
  cartoon: {
    name: 'cartoon',
    background: 'bg-cartoonBackground',
    text: 'text-cartoonTextPrimary',
    primary: 'bg-cartoonPrimary', // Tailwind class for cartoonPrimary
    secondary: 'bg-cartoonSecondary', // Tailwind class for cartoonSecondary
    accent: 'text-cartoonAccent', // Tailwind class for cartoonAccent text
  }
};

// Example Icons (replace with actual SVGs or a library)
export const Icons = {
  DefaultAvatar: '🥳', 
  Task: '🎯', // "Thử Thách Vui"
  Reward: '🎁', // "Phần Quà Bất Ngờ" (Changed from star to gift)
  Badge: '🌟', // "Ngôi Sao Thành Tích" (Changed from trophy to star)
  Points: '✨', 
  Calendar: '🗓️',
  Home: '🏡', 
  Settings: '⚙️',
  Logout: '🚪',
  Add: '➕',
  Edit: '✏️',
  Delete: '🗑️',
  Approve: '👍', 
  Reject: '🤔', // Changed from thumbs down to thinking face, encouraging review
  Clock: '⏰',
  Child: '🧒',
  Parent: '🧑‍🏫',
  Family: '👨‍👩‍👧‍👦',
  Statistics: '📈', // "Hành Trình Phát Triển" (Changed from bar chart to growth chart)
  Game: '🎮', 
  Journal: '✍️', // New icon for Journal
  CheckCircle: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" /></svg>,
  XCircle: <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" /></svg>,
  ChevronDown: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4"><path strokeLinecap="round" strokeLinejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" /></svg>,
  ChevronRight: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4"><path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" /></svg>,
  LoadingSpinner: <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
  </svg>,
  StarSolid: <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-5 h-5"><path fillRule="evenodd" d="M10.868 2.884c-.321-.772-1.415-.772-1.736 0l-1.83 4.401-4.753.381c-.833.067-1.171 1.107-.536 1.651l3.62 3.102-1.106 4.637c-.194.813.691 1.456 1.405 1.02L10 15.591l4.069 2.485c.713.436 1.598-.207 1.404-1.02l-1.106-4.637 3.62-3.102c.635-.544.297-1.584-.536-1.65l-4.752-.382-1.831-4.401z" clipRule="evenodd" /></svg>,
  HeartSolid: <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-5 h-5"><path d="M9.653 16.915l-.005-.003-.019-.01a20.759 20.759 0 01-1.162-.682 22.045 22.045 0 01-2.582-1.9-19.345 19.345 0 01-2.924-2.652C1.055 10.703 0 8.854 0 7.001 0 5.255 1.255 4 2.999 4A2.999 2.999 0 015.999 7v.003l.001.001.001.001L10 11.999l4.001-4.999.001-.001.001-.001V7A2.999 2.999 0 0117.001 4C18.745 4 20 5.255 20 7.001c0 1.853-1.055 3.702-2.947 4.661a19.345 19.345 0 01-2.924 2.652 22.045 22.045 0 01-2.582 1.9 20.753 20.753 0 01-1.162.682l-.019.01-.005.003h-.002a.739.739 0 01-.698 0l-.005-.003z" /></svg>,
  // Task Status Icons (More playful)
  TaskStatusTodo: '🤔', // "Sẵn sàng chinh phục!"
  TaskStatusPending: '⏳', // "Bố mẹ xem nhé!"
  TaskStatusApproved: '🎉', // "Tuyệt vời!"
  TaskStatusRejected: '😥', // "Cố lên nào!" (Visual is sad, text should be encouraging)
};

export const DEFAULT_AVATARS = ['🥳', '🤩', '🚀', '🌟', '🦄', '🦁', '🦊', '🦉', '🦋', '🎉', '🐙', '🦖', '🤖', '👽', '🤠'];

export const GAME_ICONS = ['🎲', '🎮', '🧩', '🕹️', '👾', '🎯', '🎳', '🏹', '🎨', '🧠', '💡', '🧪', '🌍', '🚀', '🛠️'];

// Array of positive feedback messages for approved tasks
export const PRAISE_MESSAGES = [
    `Con giỏi quá!`,
    `Xuất sắc! Bố mẹ tự hào về con!`,
    `Tuyệt vời! Con đã làm rất tốt!`,
    `Hoan hô! Một ngôi sao sáng cho con!`,
    `Con thật tuyệt vời! Tiếp tục phát huy nhé!`,
    `Wow! Con làm được rồi, giỏi lắm!`,
    `Thật đáng khen! Con đã cố gắng hết mình.`
];

// Default daily quotes if not customized by parent
export const DEFAULT_DAILY_QUOTES = [
    `Mỗi ngày là một trang sách mới, hãy viết nên câu chuyện tuyệt vời của con!`,
    `Nụ cười của con thắp sáng cả thế giới.`,
    `Lòng tốt giống như hạt mầm, gieo yêu thương sẽ nhận lại hạnh phúc.`,
    `Hãy luôn tò mò, vì thế giới đầy ắp những điều kỳ diệu chờ con khám phá.`,
    `Con là một ngôi sao độc nhất, hãy tỏa sáng theo cách riêng của mình.`,
    `Đừng sợ mắc lỗi, mỗi lỗi sai là một bài học quý giá.`,
    `Chia sẻ niềm vui, niềm vui nhân đôi. Chia sẻ nỗi buồn, nỗi buồn vơi nửa.`,
    `Hãy lắng nghe trái tim mình, nó sẽ dẫn đường cho con.`,
    `Một cuốn sách hay là một người bạn tốt.`,
    `Ước mơ không có ngày nghỉ, hãy nuôi dưỡng nó mỗi ngày.`,
    `Cố gắng hôm nay, thành công ngày mai.`,
    `Hãy dũng cảm như sư tử, và dịu dàng như một bông hoa.`,
    `Mỗi bước chân nhỏ đều tạo nên hành trình lớn.`,
    `Thế giới thật đẹp khi có con.`,
    `Hãy là phiên bản tốt nhất của chính mình.`,
    `Yêu thương là ngôn ngữ diệu kỳ mà ai cũng hiểu.`,
    `Học hỏi là một hành trình không bao giờ kết thúc.`,
    `Hãy tin vào bản thân, con có thể làm được mọi điều.`,
    `Một lời nói tử tế có thể thay đổi cả một ngày.`,
    `Cảm ơn cuộc đời mỗi sớm mai thức dậy.`,
    `Hãy giúp đỡ người khác khi con có thể.`,
    `Kiên nhẫn là chìa khóa của thành công.`,
    `Gia đình là nơi tình yêu bắt đầu và không bao giờ kết thúc.`,
    `Hãy chơi thật vui và học thật nhiều.`,
    `Đọc sách mở ra những thế giới mới.`,
    `Sự sáng tạo không có giới hạn.`,
    `Hãy trân trọng những điều nhỏ bé quanh con.`,
    `Mỗi ngày đều là một món quà, hãy tận hưởng nó.`,
    `Hãy luôn giữ nụ cười trên môi.`,
    `Lắng nghe nhiều hơn, nói ít lại.`,
    `Trong mỗi chúng ta đều có một siêu anh hùng.`,
    `Hãy biết ơn những gì mình đang có.`,
    `Tình bạn là một kho báu.`,
    `Sức mạnh lớn nhất là sức mạnh của tình yêu thương.`,
    `Hãy đối xử với người khác theo cách con muốn được đối xử.`,
    `Một hành động nhỏ, ý nghĩa lớn.`,
    `Đừng bao giờ từ bỏ ước mơ của mình.`,
    `Hãy khám phá những tài năng ẩn giấu của con.`,
    `Thất bại là mẹ thành công.`,
    `Hãy luôn nhìn về phía mặt trời.`,
    `Thế giới cần những ý tưởng của con.`,
    `Hãy can đảm thử những điều mới.`,
    `Tâm hồn đẹp làm con người trở nên rạng rỡ.`,
    `Hãy chăm sóc hành tinh xanh của chúng ta.`,
    `Âm nhạc làm cuộc sống thêm màu sắc.`,
    `Hãy vui vẻ như những chú chim ca hát.`,
    `Sự thật luôn là điều tốt nhất.`,
    `Hãy học cách tha thứ.`,
    `Mỗi người bạn là một món quà.`,
    `Hãy giữ lời hứa của mình.`,
    `Nghĩ tích cực, sống lạc quan.`,
    `Hãy tự hào về những gì con đã làm được.`,
    `Luôn có điều gì đó để học hỏi.`,
    `Hãy can đảm nói lên suy nghĩ của mình.`,
    `Tôn trọng sự khác biệt.`,
    `Hãy là người bạn tốt của chính mình.`,
    `Thời gian là vàng bạc.`,
    `Sức khỏe là vốn quý nhất.`,
    `Hãy yêu quý thiên nhiên.`,
    `Một khởi đầu mới luôn có thể.`,
    `Hãy chia sẻ đồ chơi với bạn bè.`,
    `Học cách nói lời cảm ơn và xin lỗi.`,
    `Hãy tưởng tượng và sáng tạo không ngừng.`,
    `Mỗi ngày đều có một điều tốt đẹp.`,
    `Hãy tử tế với động vật.`,
    `Biết ơn thầy cô, cha mẹ.`,
    `Hãy giữ gìn vệ sinh cá nhân sạch sẽ.`,
    `Đoàn kết tạo nên sức mạnh.`,
    `Cười thật nhiều mỗi ngày.`,
    `Hãy tìm thấy niềm vui trong những điều giản dị.`,
    `Luôn cố gắng hết mình trong mọi việc.`,
    `Giúp đỡ bố mẹ những việc nhỏ trong nhà.`,
    `Hãy là một người lắng nghe tốt.`,
    `Đừng sợ hãi khi đặt câu hỏi.`,
    `Hãy khám phá vẻ đẹp của nghệ thuật.`,
    `Mỗi bông hoa đều có vẻ đẹp riêng.`,
    `Hãy tin vào phép màu.`,
    `Luôn giữ cho tâm hồn mình trong sáng.`,
    `Hãy can đảm đối mặt với thử thách.`,
    `Học từ quá khứ, sống cho hiện tại, hy vọng vào tương lai.`,
    `Hãy dành thời gian cho những người con yêu thương.`,
    `Một trái tim vui vẻ là liều thuốc tốt nhất.`,
    `Hãy luôn giữ tinh thần lạc quan.`,
    `Biến ước mơ thành hành động.`,
    `Hãy là ánh sáng cho người khác.`,
    `Thế giới rộng lớn, hãy ra ngoài khám phá.`,
    `Hãy luôn giữ lời hứa.`,
    `Sự chăm chỉ sẽ được đền đáp.`,
    `Hãy trân trọng từng khoảnh khắc.`,
    `Yêu thương bản thân mình trước tiên.`,
    `Hãy lan tỏa niềm vui đến mọi người.`,
    `Mỗi ngày mới là một cơ hội để làm điều tốt.`,
    `Hãy học hỏi từ những người xung quanh.`,
    `Nghệ thuật làm cho cuộc sống phong phú hơn.`,
    `Hãy luôn giữ gìn sức khỏe.`,
    `Tình yêu thương có thể chữa lành mọi vết thương.`,
    `Hãy dũng cảm thừa nhận lỗi sai.`,
    `Luôn có một cách tốt hơn.`,
    `Hãy tìm kiếm vẻ đẹp trong mọi thứ.`,
    `Một nụ cười có thể thay đổi thế giới.`,
    `Hãy là chính con, đừng cố gắng giống ai khác.`,
    `Luôn tin rằng những điều tốt đẹp sẽ đến.`,
    `Hãy làm cho hôm nay tốt đẹp hơn hôm qua.`
];

export const MOOD_OPTIONS: MoodOption[] = [
  { emoji: '😊', label: 'Vui vẻ' },
  { emoji: '🥳', label: 'Hào hứng' },
  { emoji: '😢', label: 'Buồn' },
  { emoji: '😠', label: 'Tức giận' },
  { emoji: '🤔', label: 'Suy tư' },
  { emoji: '😴', label: 'Buồn ngủ' },
  { emoji: '🥰', label: 'Yêu thích' },
  { emoji: '😮', label: 'Ngạc nhiên' },
];

/**
 * Example User structure for backend reference.
 * The 'id' should be generated by your backend.
 * The 'password' should be securely hashed and stored by your backend, not in frontend code.
 */
export const NEW_PARENT_CHANQUANGTU: User = {
  id: 'parent_chanquangtu', // Backend should generate this, e.g., UUID
  username: 'chanquangtu',
  // password: '123456', // IMPORTANT: Password should be handled and hashed by the backend. Do NOT store plaintext passwords.
  role: UserRole.PARENT,
  name: 'Bố mẹ', // Updated name
  avatarIcon: Icons.Family, // Example icon
  // Other fields like 'points' or child-specific fields are not applicable or managed by backend.
};


import React, { createContext, useState, useEffect, ReactNode } from 'react';
import { ThemeName, AppTheme } from '../types';
import { THEMES, DEFAULT_THEME } from '../constants';
// import { storageService } from '../services/storageService'; // Removed

interface ThemeContextType {
  themeName: ThemeName;
  theme: AppTheme;
  setThemeName: (name: ThemeName) => void;
}

export const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

interface ThemeProviderProps {
  children: ReactNode;
}

export const ThemeProvider: React.FC<ThemeProviderProps> = ({ children }) => {
  const [themeName, setThemeNameState] = useState<ThemeName>(() => {
    // const storedTheme = storageService.getItem<ThemeName>('app-theme'); // Removed persistence
    // return storedTheme && THEMES[storedTheme] ? storedTheme : DEFAULT_THEME; // Removed persistence
    return DEFAULT_THEME; // Default to DEFAULT_THEME, no persistence
  });

  const setThemeName = (name: ThemeName) => {
    setThemeNameState(name);
    // storageService.setItem('app-theme', name); // Removed persistence
    // For simple non-persistent demo, or if you re-add localStorage directly:
    // localStorage.setItem('app-theme', name); 
  };
  
  useEffect(() => {
    const root = window.document.documentElement;
    // Remove all theme classes first
    Object.keys(THEMES).forEach(name => root.classList.remove(`theme-${name}`));
    // Add the current theme class
    root.classList.add(`theme-${themeName}`);
    
    // Apply theme variables directly if needed, or rely on CSS variables set in index.html
    // const currentTheme = THEMES[themeName];
    // Example: document.body.style.setProperty('--theme-bg-primary', currentTheme.background);
  }, [themeName]);


  const theme = THEMES[themeName];

  return (
    <ThemeContext.Provider value={{ themeName, theme, setThemeName }}>
      {children}
    </ThemeContext.Provider>
  );
};

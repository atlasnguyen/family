
import React, { createContext, useState, ReactNode, useEffect, useCallback } from 'react';
import { User }  from '../types';
import { storageService } from '../services/storageService';
import { DataContext } from './DataContext'; // To access users for login check

interface AuthContextType {
  currentUser: User | null;
  isLoading: boolean; // Simplified loading for initial localStorage check
  error: string | null; // For login errors
  login: (username: string) => Promise<void>; // Password removed for simplicity
  logout: () => Promise<void>;
  updateCurrentUser: (updatedUser: Partial<User>) => void;
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

const CURRENT_USER_STORAGE_KEY = 'currentUser';

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  
  // To access users from DataContext for login validation
  // This introduces a slight complexity if DataContext isn't loaded yet.
  // For simplicity, we'll assume DataContext is available or make login depend on its readiness.
  const dataContext = React.useContext(DataContext);


  useEffect(() => {
    const storedUser = storageService.getItem<User>(CURRENT_USER_STORAGE_KEY);
    if (storedUser) {
      setCurrentUser(storedUser);
    }
    setIsLoading(false);
  }, []);

  const login = useCallback(async (username: string) => {
    setError(null);
    setIsLoading(true);

    if (!dataContext) {
        setError("Lỗi hệ thống: Không thể tải dữ liệu người dùng để đăng nhập.");
        setIsLoading(false);
        throw new Error("DataContext not available for login");
    }
    
    // Simulate fetching users from DataContext (which loads from localStorage)
    // This is a simplified approach. A more robust way might involve DataContext providing a getUserByName function.
    const allUsers = dataContext.users; // Assuming users array is populated
    
    const foundUser = allUsers.find(u => u.username.toLowerCase() === username.toLowerCase());

    if (foundUser) {
      setCurrentUser(foundUser);
      storageService.setItem(CURRENT_USER_STORAGE_KEY, foundUser);
    } else {
      setError('Tên đăng nhập không đúng. Con thử lại nhé!');
      setCurrentUser(null);
      storageService.removeItem(CURRENT_USER_STORAGE_KEY);
      throw new Error('Login failed: User not found');
    }
    setIsLoading(false);
  }, [dataContext]);

  const logout = useCallback(async () => {
    setCurrentUser(null);
    storageService.removeItem(CURRENT_USER_STORAGE_KEY);
    // No API call, so no loading or error state change needed here usually
    // but if you want to signal "logging out" briefly:
    // setIsLoading(true);
    // await new Promise(resolve => setTimeout(resolve, 100)); // Simulate async
    // setIsLoading(false);
  }, []);

  const updateCurrentUser = useCallback((updatedUserData: Partial<User>) => {
    if (currentUser) {
      const updatedUser = { ...currentUser, ...updatedUserData };
      setCurrentUser(updatedUser);
      storageService.setItem(CURRENT_USER_STORAGE_KEY, updatedUser);
      // Also update this user in the main users list in DataContext
      if (dataContext) {
          dataContext.updateUser(updatedUser.id, updatedUserData); // This will also save to localStorage
      }
    }
  }, [currentUser, dataContext]);

  return (
    <AuthContext.Provider value={{ currentUser, isLoading, error, login, logout, updateCurrentUser }}>
      {children}
    </AuthContext.Provider>
  );
};


import React, { createContext, useState, useEffect, ReactNode, useCallback } from 'react';
import { 
  User, Task, Reward, Badge, EarnedBadge, RedeemedReward, FamilyIntro, PointTransaction, Game, JournalEntry,
  UserRole, TaskStatus, Gender, RedeemedRewardStatus, ChildTaskInstance, ParentCustomSettings
} from '../types';
import { storageService } from '../services/storageService';
// import { useAuth } from '../hooks/useAuth'; // REMOVED: To break circular dependency
import { 
    APP_NAME, Icons, DEFAULT_THEME, THEMES, 
    DEFAULT_AVATARS, GAME_ICONS, PRAISE_MESSAGES, DEFAULT_DAILY_QUOTES, MOOD_OPTIONS,
    NEW_PARENT_CHANQUANGTU // For initial data
} from '../constants';

// --- INITIAL MOCK DATA ---
const MOCK_PARENT_ID = NEW_PARENT_CHANQUANGTU.id; // 'parent_chanquangtu'
const MOCK_PARENT: User = {
    ...NEW_PARENT_CHANQUANGTU,
};

const MOCK_CHILDREN: User[] = [
  { id: 'child1', username: 'be_ngoan', role: UserRole.CHILD, name: 'Bé Ngoan', avatarIcon: '🧒', dob: '2016-01-01', gender: Gender.FEMALE, points: 150, parentId: MOCK_PARENT_ID },
  { id: 'child2', username: 'sieu_nhan', role: UserRole.CHILD, name: 'Siêu Nhân Nhí', avatarIcon: '🦸', dob: '2018-05-10', gender: Gender.MALE, points: 90, parentId: MOCK_PARENT_ID },
  { id: 'child_thuyminh', username: 'thuyminh', role: UserRole.CHILD, name: 'Thùy Minh', avatarIcon: '👧', dob: '2017-03-15', gender: Gender.FEMALE, points: 0, parentId: MOCK_PARENT_ID },
  { id: 'child_minhtue', username: 'minhtue', role: UserRole.CHILD, name: 'Minh Tuệ', avatarIcon: '👦', dob: '2019-07-20', gender: Gender.MALE, points: 0, parentId: MOCK_PARENT_ID },
];

const initialUsers: User[] = [MOCK_PARENT, ...MOCK_CHILDREN];

const initialTasks: Task[] = [
  { id: 'task1', parentId: MOCK_PARENT_ID, title: 'Dọn dẹp đồ chơi', description: 'Cất hết đồ chơi vào đúng chỗ sau khi chơi xong.', rewardPoints: 20, status: TaskStatus.TODO, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  { id: 'task2', parentId: MOCK_PARENT_ID, title: 'Đọc sách 15 phút', description: 'Chọn một cuốn sách và đọc trong 15 phút.', rewardPoints: 15, status: TaskStatus.TODO, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
  { id: 'task3', parentId: MOCK_PARENT_ID, title: 'Giúp mẹ việc nhà', description: 'Phụ mẹ một việc nhỏ trong nhà (ví dụ: lau bàn).', rewardPoints: 25, penaltyPoints: 5, deadline: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(), status: TaskStatus.TODO, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() },
];

const initialRewards: Reward[] = [
  { id: 'reward1', parentId: MOCK_PARENT_ID, name: 'Xem hoạt hình 30 phút', icon: '📺', pointCost: 50, category: 'Giải trí', description: 'Được chọn xem chương trình hoạt hình yêu thích trong 30 phút.', quantity: 10 },
  { id: 'reward2', parentId: MOCK_PARENT_ID, name: 'Đi công viên cuối tuần', icon: '🌳', pointCost: 200, category: 'Vui chơi', description: 'Cả nhà cùng đi công viên vào cuối tuần.', quantity: 5 },
  { id: 'reward3', parentId: MOCK_PARENT_ID, name: 'Một món đồ chơi nhỏ', icon: '🎁', pointCost: 150, category: 'Đồ chơi', description: 'Được chọn một món đồ chơi nhỏ trị giá dưới 50k.', quantity: 3 },
];

const initialBadges: Badge[] = [
    { id: 'badge_star', parentId: MOCK_PARENT_ID, name: 'Ngôi Sao Sáng', icon: '🌟', description: 'Dành cho trẻ luôn cố gắng và tỏa sáng trong mọi việc.' },
    { id: 'badge_superhero', parentId: MOCK_PARENT_ID, name: 'Siêu Nhân Học Tập', icon: '🦸‍♂️', description: 'Khuyến khích trẻ học hỏi và khám phá kiến thức mới.' },
    { id: 'badge_braveheart', parentId: MOCK_PARENT_ID, name: 'Trái Tim Dũng Cảm', icon: '💖', description: 'Trao cho trẻ khi vượt qua nỗi sợ hãi hoặc thử thách.' },
    { id: 'badge_effortchamp', parentId: MOCK_PARENT_ID, name: 'Nhà Vô Địch Nỗ Lực', icon: '🏆', description: 'Ghi nhận sự kiên trì và không bỏ cuộc của trẻ.' },
    { id: 'badge_sunsmile', parentId: MOCK_PARENT_ID, name: 'Nụ Cười Rạng Rỡ', icon: '😊', description: 'Dành cho trẻ luôn vui vẻ và lan tỏa năng lượng tích cực.' },
    { id: 'badge_cleverhands', parentId: MOCK_PARENT_ID, name: 'Bàn Tay Khéo Léo', icon: '🖐️', description: 'Khen ngợi trẻ khi hoàn thành công việc thủ công hoặc sáng tạo.' },
    { id: 'badge_goodfriend', parentId: MOCK_PARENT_ID, name: 'Người Bạn Tốt', icon: '🤝', description: 'Trao khi trẻ thể hiện sự chia sẻ, giúp đỡ bạn bè.' },
    { id: 'badge_littleexplorer', parentId: MOCK_PARENT_ID, name: 'Nhà Thám Hiểm Nhí', icon: '🗺️', description: 'Khuyến khích trẻ tò mò, khám phá thế giới xung quanh.' },
    { id: 'badge_steadysteps', parentId: MOCK_PARENT_ID, name: 'Bước Chân Kiên Định', icon: '🚶‍♀️', description: 'Dành cho trẻ kiên nhẫn hoàn thành nhiệm vụ khó.' },
    { id: 'badge_superkind', parentId: MOCK_PARENT_ID, name: 'Siêu Bé Tử Tế', icon: '🥰', description: 'Ghi nhận hành động tử tế, lễ phép của trẻ với mọi người.' },
];

const initialGames: Game[] = [
    { id: 'game1', parentId: MOCK_PARENT_ID, name: 'Đuổi Hình Bắt Chữ', icon: '🖼️', description: 'Nhìn hình đoán chữ, vui và học từ mới!', pointCostToPlay: 5, timeLimitMinutes: 10 },
    { id: 'game2', parentId: MOCK_PARENT_ID, name: 'Ai Là Triệu Phú Nhí', icon: '💡', description: 'Trả lời câu hỏi kiến thức, rinh điểm thưởng!', pointCostToPlay: 10, timeLimitMinutes: 15 },
];


const initialParentSettings: Record<string, ParentCustomSettings> = {
    [MOCK_PARENT_ID]: {
        familyIntro: { parentId: MOCK_PARENT_ID, text: "Chào mừng đến với ngôi nhà nhỏ của chúng mình! Đây là nơi yêu thương ngập tràn và tiếng cười không bao giờ tắt." },
        dailyQuotes: [...DEFAULT_DAILY_QUOTES.slice(0,5), "Hãy luôn là chính mình, con nhé!"],
        praiseMessages: [...PRAISE_MESSAGES.slice(0,3), "Con làm bố mẹ rất bất ngờ!"],
        avatars: [...DEFAULT_AVATARS.slice(0,10)],
        gameIcons: [...GAME_ICONS.slice(0,10)],
        rewardIcons: [Icons.Reward, '🍦', '🎮', '🧸'],
        badgeIcons: [Icons.Badge, '🌟', '🥇', '💡'],
    }
};
// --- END INITIAL MOCK DATA ---

export interface DataProviderProps { // Added to fix implicit any type
  children: ReactNode;
}

interface DataContextType {
  users: User[];
  tasks: Task[];
  childTaskInstances: ChildTaskInstance[];
  rewards: Reward[];
  badges: Badge[];
  earnedBadges: EarnedBadge[];
  redeemedRewards: RedeemedReward[];
  pointTransactions: PointTransaction[];
  games: Game[];
  journalEntries: JournalEntry[];
  // parentSettings and familyIntro removed from direct context value
  // They will be accessed via functions taking currentUser

  error: string | null; // For general app errors if any

  // Functions to manage data (now synchronous)
  addUser: (userData: Omit<User, 'id' | 'role' | 'parentId' | 'points' | 'avatarIcon'> & { avatarIcon?: string }, currentParentUser: User) => User;
  updateUser: (userId: string, userData: Partial<User>) => User;
  getChildren: (parentId: string) => User[];

  getTasks: (parentId: string) => Task[];
  addTask: (taskData: Omit<Task, 'id' | 'createdAt' | 'updatedAt' | 'status' | 'parentId'>, currentParentUser: User) => Task;
  updateTask: (taskId: string, taskData: Partial<Task>) => Task;
  deleteTask: (taskId: string) => void;
  getTaskById: (taskId: string) => Task | undefined;
  
  addChildTaskInstance: (instanceData: Omit<ChildTaskInstance, 'id'>) => ChildTaskInstance;
  updateChildTaskInstance: (instanceId: string, instanceData: Partial<ChildTaskInstance>) => ChildTaskInstance;
  getChildTaskInstances: (childId: string, date?: string) => ChildTaskInstance[];
  getChildTaskInstancesByDateRange: (childId: string, startDate: string, endDate: string) => ChildTaskInstance[];

  getRewards: (parentId: string) => Reward[];
  addReward: (rewardData: Omit<Reward, 'id' | 'parentId'>, currentParentUser: User) => Reward;
  updateReward: (rewardId: string, rewardData: Partial<Reward>) => Reward;
  deleteReward: (rewardId: string) => void;
  redeemReward: (childId: string, rewardId: string) => RedeemedReward | null; 
  approveRedeemedReward: (redeemedRewardId: string, approve: boolean, feedback?: string) => void;
  deliverRedeemedReward: (redeemedRewardId: string) => void;
  getRedeemedRewardsByChild: (childId: string) => RedeemedReward[];
  getRedeemedRewardsByParent: (parentId: string) => RedeemedReward[];
  getRewardById: (rewardId: string) => Reward | undefined;

  getBadges: (parentId: string) => Badge[];
  addBadge: (badgeData: Omit<Badge, 'id' | 'parentId'>, currentParentUser: User) => Badge;
  awardBadge: (childId: string, badgeId: string, reason?: string) => EarnedBadge;
  getEarnedBadges: (childId: string) => EarnedBadge[];

  getFamilyIntro: (currentUser: User | null) => FamilyIntro | null; 
  updateFamilyIntro: (introData: Omit<FamilyIntro, 'parentId'>, currentParentUser: User) => void;
  
  getPointHistory: (childId: string) => PointTransaction[];

  getGames: (parentId: string) => Game[];
  getGameById: (gameId: string) => Game | undefined;
  addGame: (gameData: Omit<Game, 'id' | 'parentId'>, currentParentUser: User) => Game;
  updateGame: (gameId: string, gameData: Partial<Game>) => Game;
  deleteGame: (gameId: string) => void;
  spendPointsForGamePlay: (childId: string, gameId: string) => boolean;

  getJournalEntriesByChild: (childId: string) => JournalEntry[];
  getJournalEntryById: (entryId: string) => JournalEntry | undefined;
  addJournalEntry: (entryData: Omit<JournalEntry, 'id' | 'childId' | 'createdAt' | 'updatedAt' | 'date'>, currentChildUser: User) => JournalEntry;
  updateJournalEntry: (entryId: string, updatedEntryData: Partial<JournalEntry>) => JournalEntry;
  deleteJournalEntry: (entryId: string) => void;

  getParentCustomSettings: (currentUser: User | null) => ParentCustomSettings | null;
  updateParentCustomSettings: (currentUser: User | null, settings: Partial<ParentCustomSettings>) => void;
  getEffectiveDailyQuotes: (currentUser: User | null) => string[]; 
  getEffectivePraiseMessages: (currentUser: User | null) => string[];
  getEffectiveAvatars: (currentUser: User | null) => string[];
  getEffectiveGameIcons: (currentUser: User | null) => string[];
  getEffectiveRewardIcons: (currentUser: User | null) => string[];
  getEffectiveBadgeIcons: (currentUser: User | null) => string[];
}

export const DataContext = createContext<DataContextType | undefined>(undefined);

const generateId = () => Math.random().toString(36).substr(2, 9);

export const DataProvider: React.FC<DataProviderProps> = ({ children }) => {
  // const { currentUser: authCurrentUser, updateCurrentUser: updateAuthUser } = useAuth(); // REMOVED

  const [users, setUsers] = useState<User[]>(() => {
    const stored = storageService.getItem<User[]>('app_users');
    return stored && stored.length > 0 ? stored : initialUsers;
  });
  const [tasks, setTasks] = useState<Task[]>(() => {
    const stored = storageService.getItem<Task[]>('app_tasks');
    return stored && stored.length > 0 ? stored : initialTasks;
  });
  const [childTaskInstances, setChildTaskInstances] = useState<ChildTaskInstance[]>(() => storageService.getItem<ChildTaskInstance[]>('app_childTaskInstances', []));
  const [rewards, setRewards] = useState<Reward[]>(() => {
    const stored = storageService.getItem<Reward[]>('app_rewards');
    return stored && stored.length > 0 ? stored : initialRewards;
  });
  const [badges, setBadges] = useState<Badge[]>(() => {
    const stored = storageService.getItem<Badge[]>('app_badges');
    return stored && stored.length > 0 ? stored : initialBadges;
  });
  const [earnedBadges, setEarnedBadges] = useState<EarnedBadge[]>(() => storageService.getItem<EarnedBadge[]>('app_earnedBadges', []));
  const [redeemedRewards, setRedeemedRewards] = useState<RedeemedReward[]>(() => storageService.getItem<RedeemedReward[]>('app_redeemedRewards', []));
  const [pointTransactions, setPointTransactions] = useState<PointTransaction[]>(() => storageService.getItem<PointTransaction[]>('app_pointTransactions', []));
  const [games, setGames] = useState<Game[]>(() => {
    const stored = storageService.getItem<Game[]>('app_games');
    return stored && stored.length > 0 ? stored : initialGames;
  });
  const [journalEntries, setJournalEntries] = useState<JournalEntry[]>(() => storageService.getItem<JournalEntry[]>('app_journalEntries', []));
  
  const [allParentSettings, setAllParentSettings] = useState<Record<string, ParentCustomSettings>>(() => {
    const stored = storageService.getItem<Record<string, ParentCustomSettings>>('app_allParentSettings');
    if (stored && Object.keys(stored).length > 0) {
        const currentUsers = storageService.getItem<User[]>('app_users') || initialUsers;
        const mockParentExists = currentUsers.some(u => u.id === MOCK_PARENT_ID);
        if (mockParentExists && !stored[MOCK_PARENT_ID] && initialParentSettings[MOCK_PARENT_ID]) {
            return { ...stored, [MOCK_PARENT_ID]: initialParentSettings[MOCK_PARENT_ID] };
        }
        return stored;
    }
    return initialParentSettings;
  });
  
  const [error, setError] = useState<string | null>(null);

  useEffect(() => { storageService.setItem('app_users', users); }, [users]);
  useEffect(() => { storageService.setItem('app_tasks', tasks); }, [tasks]);
  useEffect(() => { storageService.setItem('app_childTaskInstances', childTaskInstances); }, [childTaskInstances]);
  useEffect(() => { storageService.setItem('app_rewards', rewards); }, [rewards]);
  useEffect(() => { storageService.setItem('app_badges', badges); }, [badges]);
  useEffect(() => { storageService.setItem('app_earnedBadges', earnedBadges); }, [earnedBadges]);
  useEffect(() => { storageService.setItem('app_redeemedRewards', redeemedRewards); }, [redeemedRewards]);
  useEffect(() => { storageService.setItem('app_pointTransactions', pointTransactions); }, [pointTransactions]);
  useEffect(() => { storageService.setItem('app_games', games); }, [games]);
  useEffect(() => { storageService.setItem('app_journalEntries', journalEntries); }, [journalEntries]);
  useEffect(() => { storageService.setItem('app_allParentSettings', allParentSettings); }, [allParentSettings]);

  // Removed useEffect that set parentSettings state based on authCurrentUser

  const addUser = (userData: Omit<User, 'id' | 'role' | 'parentId' | 'points' | 'avatarIcon'> & { avatarIcon?: string }, currentParentUser: User): User => {
    if (currentParentUser.role !== UserRole.PARENT) {
      throw new Error("Only parents can add child users.");
    }
    if (users.find(u => u.username === userData.username)) {
      throw new Error("Tên đăng nhập đã tồn tại.");
    }
    const newUser: User = {
      id: generateId(),
      ...userData,
      role: UserRole.CHILD,
      parentId: currentParentUser.id,
      points: 0,
      avatarIcon: userData.avatarIcon || DEFAULT_AVATARS[0],
    };
    setUsers(prev => [...prev, newUser]);
    return newUser;
  };

  const updateUser = (userId: string, userData: Partial<User>): User => {
    let updatedUser: User | undefined;
    setUsers(prevUsers => prevUsers.map(u => {
      if (u.id === userId) {
        updatedUser = { ...u, ...userData };
        return updatedUser;
      }
      return u;
    }));
    // AuthContext's updateCurrentUser will handle updating its own state.
    if (!updatedUser) throw new Error("User not found for update");
    return updatedUser;
  };

  const getChildren = (parentId: string) => users.filter(u => u.role === UserRole.CHILD && u.parentId === parentId);
  const getTasks = (parentId: string) => tasks.filter(t => t.parentId === parentId);
  const getTaskById = (taskId: string) => tasks.find(t => t.id === taskId);

  const addTask = (taskData: Omit<Task, 'id' | 'createdAt' | 'updatedAt' | 'status' | 'parentId'>, currentParentUser: User): Task => {
    if (currentParentUser.role !== UserRole.PARENT) throw new Error("Only parents can add tasks");
    const newTask: Task = {
      id: generateId(),
      ...taskData,
      parentId: currentParentUser.id,
      status: TaskStatus.TODO,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setTasks(prev => [...prev, newTask]);
    return newTask;
  };

  const updateTask = (taskId: string, taskData: Partial<Task>): Task => {
    let updatedTask: Task | undefined;
    setTasks(prev => prev.map(t => {
      if (t.id === taskId) {
        updatedTask = { ...t, ...taskData, updatedAt: new Date().toISOString() };
        return updatedTask;
      }
      return t;
    }));
    if (!updatedTask) throw new Error("Task not found for update");
    return updatedTask;
  };

  const deleteTask = (taskId: string): void => {
    setTasks(prev => prev.filter(t => t.id !== taskId));
    setChildTaskInstances(prev => prev.filter(cti => cti.taskId !== taskId));
  };

  const addChildTaskInstance = (instanceData: Omit<ChildTaskInstance, 'id'>): ChildTaskInstance => {
    const newInstance: ChildTaskInstance = { id: generateId(), ...instanceData };
    setChildTaskInstances(prev => [...prev, newInstance]);
    return newInstance;
  };

  const updateChildTaskInstance = (instanceId: string, instanceData: Partial<ChildTaskInstance>): ChildTaskInstance => {
    let updatedInstance: ChildTaskInstance | undefined;
    setChildTaskInstances(prev => prev.map(cti => {
      if (cti.id === instanceId) {
        updatedInstance = { ...cti, ...instanceData };
        return updatedInstance;
      }
      return cti;
    }));

    if (!updatedInstance) throw new Error("ChildTaskInstance not found for update");

    if (updatedInstance.status === TaskStatus.APPROVED) {
      const taskDetails = getTaskById(updatedInstance.taskId);
      const childUser = users.find(u => u.id === updatedInstance.childId);
      if (taskDetails && childUser) {
        const newPoints = (childUser.points || 0) + taskDetails.rewardPoints;
        updateUser(childUser.id, { points: newPoints });
        const transaction: PointTransaction = {
          id: generateId(),
          childId: childUser.id,
          amount: taskDetails.rewardPoints,
          reason: `Hoàn thành: ${taskDetails.title}`,
          date: new Date().toISOString(),
          taskId: updatedInstance.id,
        };
        setPointTransactions(prev => [transaction, ...prev]);
      }
    }
    return updatedInstance;
  };
  
  const getChildTaskInstances = (childId: string, date?: string) => {
    return childTaskInstances.filter(cti => 
      cti.childId === childId && 
      (!date || cti.date === date)
    );
  };
  
  const getChildTaskInstancesByDateRange = (childId: string, startDate: string, endDate: string) => {
    const start = new Date(startDate).getTime();
    const end = new Date(endDate).getTime();
    return childTaskInstances.filter(cti => {
        if (cti.childId !== childId) return false;
        if (!cti.date || typeof cti.date !== 'string' || !cti.date.match(/^\d{4}-\d{2}-\d{2}$/)) {
            console.warn(`Invalid date format for ChildTaskInstance ${cti.id}: ${cti.date}`);
            return false;
        }
        const instanceDate = new Date(cti.date + 'T00:00:00').getTime();
        return instanceDate >= start && instanceDate <= end;
    });
  };

  const getRewards = (parentId: string) => rewards.filter(r => r.parentId === parentId);
  const getRewardById = (rewardId: string) => rewards.find(r => r.id === rewardId);
  
  const addReward = (rewardData: Omit<Reward, 'id' | 'parentId'>, currentParentUser: User): Reward => {
    if (currentParentUser.role !== UserRole.PARENT) throw new Error("Only parents can add rewards");
    const newReward: Reward = { id: generateId(), ...rewardData, parentId: currentParentUser.id };
    setRewards(prev => [...prev, newReward]);
    return newReward;
  };

  const updateReward = (rewardId: string, rewardData: Partial<Reward>): Reward => {
    let updatedReward: Reward | undefined;
    setRewards(prev => prev.map(r => {
      if (r.id === rewardId) {
        updatedReward = { ...r, ...rewardData };
        return updatedReward;
      }
      return r;
    }));
    if (!updatedReward) throw new Error("Reward not found for update");
    return updatedReward;
  };

  const deleteReward = (rewardId: string): void => {
    setRewards(prev => prev.filter(r => r.id !== rewardId));
  };

  const redeemReward = (childId: string, rewardId: string): RedeemedReward | null => {
    const child = users.find(u => u.id === childId);
    const reward = rewards.find(r => r.id === rewardId);
    if (!child || !reward) {
      setError("Không tìm thấy thông tin con hoặc quà.");
      return null;
    }
    if ((child.points || 0) < reward.pointCost) {
      setError("Con không đủ điểm để đổi quà này.");
      return null;
    }
    if (reward.quantity <= 0) {
      setError("Quà này đã hết mất rồi!");
      return null;
    }

    updateUser(childId, { points: (child.points || 0) - reward.pointCost });
    updateReward(rewardId, { quantity: reward.quantity - 1 });

    const newRedeemed: RedeemedReward = {
      id: generateId(),
      rewardId,
      childId,
      dateRedeemed: new Date().toISOString(),
      status: RedeemedRewardStatus.PENDING_APPROVAL,
      parentId: reward.parentId,
    };
    setRedeemedRewards(prev => [...prev, newRedeemed]);
    
    const transaction: PointTransaction = {
      id: generateId(),
      childId,
      amount: -reward.pointCost,
      reason: `Đổi quà: ${reward.name}`,
      date: new Date().toISOString(),
      redeemedRewardId: newRedeemed.id,
    };
    setPointTransactions(prev => [transaction, ...prev]);
    return newRedeemed;
  };

  const approveRedeemedReward = (redeemedRewardId: string, approve: boolean, feedback?: string): void => {
    let updatedRedeemed: RedeemedReward | undefined;
    setRedeemedRewards(prev => prev.map(rr => {
      if (rr.id === redeemedRewardId) {
        updatedRedeemed = { ...rr, status: approve ? RedeemedRewardStatus.APPROVED_BY_PARENT : RedeemedRewardStatus.REJECTED_BY_PARENT };
        return updatedRedeemed;
      }
      return rr;
    }));
    if (!updatedRedeemed) throw new Error("RedeemedReward not found");

    if (!approve) { 
      const child = users.find(u => u.id === updatedRedeemed!.childId);
      const reward = rewards.find(r => r.id === updatedRedeemed!.rewardId);
      if (child && reward) {
        updateUser(child.id, { points: (child.points || 0) + reward.pointCost });
        updateReward(reward.id, { quantity: reward.quantity + 1 });
        const transaction: PointTransaction = {
          id: generateId(),
          childId: child.id,
          amount: reward.pointCost,
          reason: `Từ chối đổi quà: ${reward.name}`,
          date: new Date().toISOString(),
          redeemedRewardId: redeemedRewardId,
        };
        setPointTransactions(prev => [transaction, ...prev]);
      }
    }
  };

  const deliverRedeemedReward = (redeemedRewardId: string): void => {
    setRedeemedRewards(prev => prev.map(rr => 
      rr.id === redeemedRewardId ? { ...rr, status: RedeemedRewardStatus.DELIVERED } : rr
    ));
  };
  
  const getRedeemedRewardsByChild = (childId: string) => redeemedRewards.filter(rr => rr.childId === childId);
  const getRedeemedRewardsByParent = (parentId: string) => redeemedRewards.filter(rr => rr.parentId === parentId);

  const getBadges = (parentId: string) => badges.filter(b => b.parentId === parentId);
  const addBadge = (badgeData: Omit<Badge, 'id' | 'parentId'>, currentParentUser: User): Badge => {
    if (currentParentUser.role !== UserRole.PARENT) throw new Error("Only parents can add badges");
    const newBadge: Badge = { id: generateId(), ...badgeData, parentId: currentParentUser.id };
    setBadges(prev => [...prev, newBadge]);
    return newBadge;
  };

  const awardBadge = (childId: string, badgeId: string, reason?: string): EarnedBadge => {
    const newEarnedBadge: EarnedBadge = {
      id: generateId(),
      badgeId,
      childId,
      dateEarned: new Date().toISOString(),
      reason,
    };
    setEarnedBadges(prev => [...prev, newEarnedBadge]);
    return newEarnedBadge;
  };
  const getEarnedBadges = (childId: string) => earnedBadges.filter(eb => eb.childId === childId).sort((a,b) => new Date(b.dateEarned).getTime() - new Date(a.dateEarned).getTime());

  const getParentCustomSettings = useCallback((currentUser: User | null): ParentCustomSettings | null => {
    if (currentUser) {
        const targetParentId = currentUser.role === UserRole.PARENT ? currentUser.id : currentUser.parentId;
        if (!targetParentId) return null;

        // Ensure initial settings for mock parent are consistently available if allParentSettings is somehow empty for them
        if (targetParentId === MOCK_PARENT_ID && !allParentSettings[targetParentId]) {
            return initialParentSettings[MOCK_PARENT_ID] || null;
        }
        return allParentSettings[targetParentId] || null;
    }
    return null;
  }, [allParentSettings]);

  const updateParentCustomSettings = useCallback((currentUser: User | null, settingsUpdate: Partial<ParentCustomSettings>) => {
    if (!currentUser) throw new Error("User not logged in.");
    const targetParentId = currentUser.role === UserRole.PARENT ? currentUser.id : currentUser.parentId;
    if (!targetParentId) throw new Error("Parent ID not found for settings update.");

    setAllParentSettings(prevAll => {
        const currentParentSpecificSettings = prevAll[targetParentId] || (targetParentId === MOCK_PARENT_ID ? initialParentSettings[MOCK_PARENT_ID] : {});
        const updatedSettings = { ...currentParentSpecificSettings, ...settingsUpdate };
        
        // Ensure that if a field is explicitly set to an empty array by user, it's saved as such.
        // Otherwise, if a field in settingsUpdate is undefined, keep the existing value.
        // This logic might need refinement based on how "clearing" a custom setting should work.
        // For now, simple merge.

        return {
            ...prevAll,
            [targetParentId]: updatedSettings
        };
    });
  }, []);
  
  const getFamilyIntro = useCallback((currentUser: User | null): FamilyIntro | null => {
    const currentSettings = getParentCustomSettings(currentUser);
    return currentSettings?.familyIntro || null;
  }, [getParentCustomSettings]);

  const updateFamilyIntro = useCallback((introData: Omit<FamilyIntro, 'parentId'>, currentParentUser: User) => {
    if (currentParentUser.role !== UserRole.PARENT) throw new Error("Only parents can update family intro");
    const newFamilyIntro: FamilyIntro = { ...introData, parentId: currentParentUser.id };
    updateParentCustomSettings(currentParentUser, { familyIntro: newFamilyIntro });
  }, [updateParentCustomSettings]);

  const getPointHistory = (childId: string) => pointTransactions.filter(pt => pt.childId === childId).sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const getGames = (parentId: string) => games.filter(g => g.parentId === parentId);
  const getGameById = (gameId: string) => games.find(g => g.id === gameId);
  const addGame = (gameData: Omit<Game, 'id' | 'parentId'>, currentParentUser: User): Game => {
     if (currentParentUser.role !== UserRole.PARENT) throw new Error("Only parents can add games");
     const newGame: Game = { id: generateId(), ...gameData, parentId: currentParentUser.id };
     setGames(prev => [...prev, newGame]);
     return newGame;
  };
  const updateGame = (gameId: string, gameData: Partial<Game>): Game => {
    let updatedGame: Game | undefined;
    setGames(prev => prev.map(g => {
        if(g.id === gameId) {
            updatedGame = { ...g, ...gameData };
            return updatedGame;
        }
        return g;
    }));
    if(!updatedGame) throw new Error("Game not found for update");
    return updatedGame;
  };
  const deleteGame = (gameId: string): void => {
     setGames(prev => prev.filter(g => g.id !== gameId));
  };
  
  const spendPointsForGamePlay = (childId: string, gameId: string): boolean => {
    const child = users.find(u => u.id === childId);
    const game = games.find(g => g.id === gameId);

    if (!child || !game) {
        setError("Không tìm thấy thông tin con hoặc trò chơi.");
        return false;
    }
    if ((child.points || 0) < game.pointCostToPlay) {
        setError("Con không đủ điểm để chơi trò này.");
        return false;
    }
    updateUser(childId, { points: (child.points || 0) - game.pointCostToPlay });
    const transaction: PointTransaction = {
      id: generateId(),
      childId,
      amount: -game.pointCostToPlay,
      reason: `Chơi game: ${game.name}`,
      date: new Date().toISOString(),
      gameId: game.id,
    };
    setPointTransactions(prev => [transaction, ...prev]);
    return true;
  };

  const getJournalEntriesByChild = useCallback((childId: string): JournalEntry[] => {
    return journalEntries.filter(entry => entry.childId === childId).sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [journalEntries]);

  const getJournalEntryById = useCallback((entryId: string): JournalEntry | undefined => {
    return journalEntries.find(entry => entry.id === entryId);
  }, [journalEntries]);

  const addJournalEntry = (entryData: Omit<JournalEntry, 'id' | 'childId' | 'createdAt' | 'updatedAt' | 'date'>, currentChildUser: User): JournalEntry => {
    if (currentChildUser.role !== UserRole.CHILD) throw new Error("Only children can add journal entries");
    const now = new Date();
    const newEntry: JournalEntry = { 
      id: generateId(),
      ...entryData, 
      childId: currentChildUser.id,
      date: now.toISOString().split('T')[0], 
      createdAt: now.toISOString(),
      updatedAt: now.toISOString(),
    };
    setJournalEntries(prev => [newEntry, ...prev].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
    return newEntry;
  };

  const updateJournalEntry = (entryId: string, updatedEntryData: Partial<JournalEntry>): JournalEntry => {
    let finalEntry: JournalEntry | undefined;
    setJournalEntries(prev => 
      prev.map(entry => {
        if (entry.id === entryId) {
          finalEntry = { ...entry, ...updatedEntryData, updatedAt: new Date().toISOString() };
          return finalEntry;
        }
        return entry;
      }).sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    );
    if (!finalEntry) throw new Error("Journal entry not found for update");
    return finalEntry;
  };

  const deleteJournalEntry = (entryId: string): void => {
    setJournalEntries(prev => prev.filter(entry => entry.id !== entryId));
  };
  
  const getEffectiveDailyQuotes = useCallback((currentUser: User | null): string[] => {
    const settings = getParentCustomSettings(currentUser);
    return settings?.dailyQuotes && settings.dailyQuotes.length > 0 ? settings.dailyQuotes : DEFAULT_DAILY_QUOTES;
  }, [getParentCustomSettings]);

  const getEffectivePraiseMessages = useCallback((currentUser: User | null): string[] => {
    const settings = getParentCustomSettings(currentUser);
    return settings?.praiseMessages && settings.praiseMessages.length > 0 ? settings.praiseMessages : PRAISE_MESSAGES;
  }, [getParentCustomSettings]);

  const getEffectiveAvatars = useCallback((currentUser: User | null): string[] => {
    const settings = getParentCustomSettings(currentUser);
    return settings?.avatars && settings.avatars.length > 0 ? settings.avatars : DEFAULT_AVATARS;
  }, [getParentCustomSettings]);
  
  const getEffectiveGameIcons = useCallback((currentUser: User | null): string[] => {
    const settings = getParentCustomSettings(currentUser);
    return settings?.gameIcons && settings.gameIcons.length > 0 ? settings.gameIcons : GAME_ICONS;
  }, [getParentCustomSettings]);

  const getEffectiveRewardIcons = useCallback((currentUser: User | null): string[] => {
    const settings = getParentCustomSettings(currentUser);
    const defaultRewardIcons = [Icons.Reward, '🍦', '🎮', '🧸', '🚲', '🎨', '🚀', ...(settings?.avatars || DEFAULT_AVATARS).slice(0,5)];
    return settings?.rewardIcons && settings.rewardIcons.length > 0 ? settings.rewardIcons : defaultRewardIcons;
  }, [getParentCustomSettings]);

  const getEffectiveBadgeIcons = useCallback((currentUser: User | null): string[] => {
    const settings = getParentCustomSettings(currentUser);
    const defaultBadgeIcons = [Icons.Badge, '🌟', '🥇', '💡', '💖', '👍', ...(settings?.avatars || DEFAULT_AVATARS).slice(0,5)];
    return settings?.badgeIcons && settings.badgeIcons.length > 0 ? settings.badgeIcons : defaultBadgeIcons;
  }, [getParentCustomSettings]);


  return (
    <DataContext.Provider value={{
      users, tasks, childTaskInstances, rewards, badges, earnedBadges, redeemedRewards, 
      pointTransactions, games, journalEntries, 
      error,
      addUser, updateUser, getChildren,
      getTasks, addTask, updateTask, deleteTask, getTaskById,
      addChildTaskInstance, updateChildTaskInstance, getChildTaskInstances, getChildTaskInstancesByDateRange,
      getRewards, addReward, updateReward, deleteReward, redeemReward, approveRedeemedReward, deliverRedeemedReward, getRedeemedRewardsByChild, getRedeemedRewardsByParent, getRewardById,
      getBadges, addBadge, awardBadge, getEarnedBadges,
      getFamilyIntro, updateFamilyIntro,
      getPointHistory,
      getGames, getGameById, addGame, updateGame, deleteGame, spendPointsForGamePlay,
      getJournalEntriesByChild, getJournalEntryById, addJournalEntry, updateJournalEntry, deleteJournalEntry,
      getParentCustomSettings, updateParentCustomSettings,
      getEffectiveDailyQuotes, getEffectivePraiseMessages, getEffectiveAvatars, getEffectiveGameIcons, getEffectiveRewardIcons, getEffectiveBadgeIcons,
    }}>
      {children}
    </DataContext.Provider>
  );
};
